"""
Sweep-M2-Separation.py

Separation sweep for two emitters, the one configuration in which the
stratification variable is unambiguous.

For M = 2 the radius of gyration of the emitter pair is exactly half their
separation,

    R_g = d / 2

so sweeping d sweeps global compactness with no ambiguity, unlike M >= 3 where
the minimum pairwise distance and the radius of gyration are nearly
independent. Every separation examined also lies inside the support of the
training distribution, i.e. two emitters drawn independently and uniformly in
the central 3x3 pixel block realise every separation from 0 to the block
diagonal, so conditioning on d selects a slice of the training distribution
rather than leaving it. The networks therefore interpolate at every point of
the sweep and no extrapolation confound arises.

For each separation the script generates N frames whose emitter pair has
exactly that separation, with the pair midpoint drawn uniformly and the pair
orientation drawn uniformly, then evaluates

    UGIA-F      unbiased, Fisher information of the frame, oracle parameters
    EM-Near-1   EM from a single near-true start, +-NEAR_HALF_NEAR nm
    EM-GML    multi-start EM, K wide starts, highest log-likelihood kept
    APL, CNN-APL, KAN, CNN-KAN, ViT     frame-trained networks

and reports ARMSMD-H against d. The frozen non-uniform noise field of
Dataset-Random is used throughout so the results are directly comparable with
the other benchmarks.

Outputs
    Benchmark-Random/Sweep-M2/sweep_m2.csv      ARMSMD-H vs d, all estimators
    Benchmark-Random/Sweep-M2/sweep_m2.png      the corresponding curves
    Benchmark-Random/Sweep-M2/d=<d>_perframe.csv   per-frame squared RMSMD-H

Yi Sun
"""

import sys
import os
import time
import math
import numpy as np
import torch
import matplotlib.pyplot as plt

ROOT = r"K:\Research_KB"   # <- change to your actual path
sys.path.append(ROOT)


# ----------------------------------------------------------------------
# Console logging: duplicate all stdout to a log file in the Benchmark folder
# ----------------------------------------------------------------------
class _Tee:
    """Write everything printed to the console AND to a log file."""
    def __init__(self, *streams):
        self.streams = streams
    def write(self, data):
        for s in self.streams:
            try:
                s.write(data)
            except UnicodeEncodeError:
                s.write(data.encode("ascii", "replace").decode("ascii"))
            s.flush()
    def flush(self):
        for s in self.streams:
            s.flush()


from SMLM_Lib import (
    SystemConfig,
    EmitterData,
    Gaussian2DPSF,
    Camera,
    Noise,
    gauss2d_frame_torch,
    gauss2d_ugia_f_batch_torch,
    gauss2d_em_batch_torch,
    print_device_info,
)
from SMLM_Lib.Gauss2D import gauss2d_loglike_batch_torch
from SMLM_Lib.metrics import rmsmd_h_per_frame
from SMLM_Lib.APL import APLLocalizer, CNNAPLLocalizer
from SMLM_Lib.KAN import KANLocalizer, CNNKANLocalizer
from SMLM_Lib.ViT import ViTLocalizer


# ============ configuration ============
M           = 2
N           = 1000          # frames per separation
Noise_src   = "Dataset-Random"   # folder holding the frozen b_map / G_map
OutDir      = "Benchmark-Random/Sweep-M2"

# Separations in nm, finer where the crossovers are expected.
D_LIST = [10, 15, 20, 25, 30, 40, 50, 60, 75, 100, 125, 150, 200, 250]

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

camera = Camera(Kx=7, Ky=7, Dx=100.0, Dy=100.0, Dt=0.01)
Kx, Ky = camera.Kx, camera.Ky
Dx, Dy = camera.Dx, camera.Dy

psf = Gaussian2DPSF(sigma=108.81)

b_map = torch.tensor(np.loadtxt(os.path.join(Noise_src, "b_map.txt"),
                                dtype=np.float32), device=device)
G_map = torch.tensor(np.loadtxt(os.path.join(Noise_src, "G_map.txt"),
                                dtype=np.float32), device=device)
noise = Noise(b=b_map, mu=G_map, G=G_map)   # mu_k = G_k

Im0 = 300000.0

# Emitter placement region, matching sample_emitters_batch with margin_px = 2,
# i.e. the central 3x3 pixel block spans [200, 500) nm in x and in y.
MARGIN_PX = 2
LO = MARGIN_PX * Dx
HI = (Kx - MARGIN_PX) * Dx

# EM settings, matching EM-GML-Random.py
NEAR_HALF_NEAR = 10.0
NEAR_HALF_WIDE = 100.0
K              = 250

# Number of starts evaluated in one call. The batch presented to the
# graphics processor is BATCH_STARTS times the number of frames, so a
# larger value uses the device more fully at the cost of more memory.
# The result does not depend on it.
BATCH_STARTS   = 5
N_ITER         = 300
GN             = 'N'
SEED           = 20260719

NET_FOLDERS = {
    'APL':     ("APL-Trained",     "apl_localizer_M={}.pth"),
    'CNN-APL': ("CNN-APL-Trained", "cnnapl_localizer_M={}.pth"),
    'KAN':     ("KAN-Trained",     "kan_localizer_M={}.pth"),
    'CNN-KAN': ("CNN-KAN-Trained", "cnnkan_localizer_M={}.pth"),
    'ViT':     ("ViT-Trained",     "vit_localizer_M={}.pth"),
}
NETWORKS   = ['APL', 'CNN-APL', 'KAN', 'CNN-KAN', 'ViT']
ESTIMATORS = ['UGIA-F', 'EM-Near-1', 'EM-GML'] + NETWORKS

STYLE = {
    'UGIA-F':    dict(color='k',       ls='--', marker='s', lw=2.0),
    'EM-Near-1': dict(color='0.55',    ls=':',  marker='v', lw=1.6),
    'EM-GML':  dict(color='crimson', ls='-',  marker='o', lw=2.2),
    'APL':       dict(color='tab:blue',   ls='-', marker='^', lw=1.4),
    'CNN-APL':   dict(color='tab:cyan',   ls='-', marker='^', lw=1.4),
    'KAN':       dict(color='tab:green',  ls='-', marker='D', lw=1.4),
    'CNN-KAN':   dict(color='tab:olive',  ls='-', marker='D', lw=1.4),
    'ViT':       dict(color='tab:purple', ls='-', marker='*', lw=1.6),
}


# ============ emitter pair sampling ============

def sample_pairs(d_nm, n_frames, gen):
    """Sample n_frames emitter pairs with exact separation d_nm.

    The pair midpoint is drawn uniformly and the pair orientation is drawn
    uniformly, then the two emitters are placed at the midpoint plus and minus
    d/2 along that direction. A pair is accepted only if both emitters fall in
    the central 3x3 pixel block, which is the region the networks were trained
    on, so the returned configurations are a conditional slice of the training
    distribution.

    Returns
    -------
    xy : (n_frames, 2, 2) tensor in nm
    acc : float, acceptance rate of the rejection sampler
    """
    got = []
    tried = 0
    accepted = 0
    half = 0.5 * float(d_nm)
    while sum(x.shape[0] for x in got) < n_frames:
        B = 4 * n_frames
        mid = LO + (HI - LO) * torch.rand(B, 2, device=device, generator=gen)
        th  = 2.0 * math.pi * torch.rand(B, device=device, generator=gen)
        off = torch.stack([half * torch.cos(th), half * torch.sin(th)], dim=1)
        p1, p2 = mid + off, mid - off
        ok = ((p1 >= LO) & (p1 < HI) & (p2 >= LO) & (p2 < HI)).all(dim=1)
        tried += B
        accepted += int(ok.sum().item())
        if ok.any():
            got.append(torch.stack([p1[ok], p2[ok]], dim=1))   # (n_ok, 2, 2)
    xy = torch.cat(got, dim=0)[:n_frames].contiguous()
    return xy, accepted / float(tried)


def make_frames(xy):
    """Generate one noisy frame per configuration under the frozen noise."""
    B = xy.shape[0]
    Im = torch.full((B, M), Im0, dtype=torch.float32, device=device)
    emitter = EmitterData(xy=xy, Im=Im)
    system  = SystemConfig(emitter=emitter, psf=psf, camera=camera, noise=noise)
    with torch.no_grad():
        return gauss2d_frame_torch(system)          # (B, Ky, Kx)


# ============ helpers ============

def load_net(name):
    folder, pat = NET_FOLDERS[name]
    if name == 'APL':
        model = APLLocalizer(Kx=Kx, Ky=Ky, M=M)
    elif name == 'CNN-APL':
        model = CNNAPLLocalizer(Kx=Kx, Ky=Ky, M=M)
    elif name == 'KAN':
        model = KANLocalizer(Kx=Kx, Ky=Ky, M=M)
    elif name == 'CNN-KAN':
        model = CNNKANLocalizer(Kx=Kx, Ky=Ky, M=M)
    else:
        model = ViTLocalizer(Kx=Kx, Ky=Ky, M=M)
    model = model.to(device)
    model.load_state_dict(
        torch.load(os.path.join(folder, pat.format(M)), map_location=device))
    model.eval()
    return model


def prepare_input(frames):
    x = frames.view(frames.shape[0], -1)
    return x / (x.amax(dim=1, keepdim=True) + 1e-8)


def per_frame_D2h(xy_est, xy_ref):
    """(N,) squared RMSMD-H per frame, i.e. under the Hungarian assignment.

    The number of estimates equals the number of emitters, so the
    correspondence of maximum likelihood is the assignment minimising the
    total squared distance. A stratum or sweep value is obtained as
    sqrt(mean(D2h)), i.e. the squared distances are averaged and the square
    root taken once at the end.
    """
    _, D2 = rmsmd_h_per_frame(xy_est, xy_ref)
    return D2.cpu().numpy().astype(np.float64)


def armsmd_h(D2h):
    return float(np.sqrt(np.mean(D2h)))


# ============ sweep ============

def run():
    os.makedirs(OutDir, exist_ok=True)

    nets = {name: load_net(name) for name in NETWORKS}
    print(f"Loaded {len(nets)} networks for M={M}.\n")

    results = {e: [] for e in ESTIMATORS}
    acc_rates = []

    for d_nm in D_LIST:
        t_d = time.perf_counter()
        gen = torch.Generator(device=device).manual_seed(SEED + int(d_nm))

        xy_true, acc = sample_pairs(d_nm, N, gen)
        acc_rates.append(acc)
        frames = make_frames(xy_true)

        Im_tensor = torch.full((1, M), Im0, dtype=torch.float32, device=device)
        emitter = EmitterData(xy=xy_true[0:1], Im=Im_tensor)
        system  = SystemConfig(emitter=emitter, psf=psf, camera=camera, noise=noise)

        D2h = {}

        # ---- UGIA-F --------------------------------------------------
        with torch.no_grad():
            xyF = gauss2d_ugia_f_batch_torch(xy_true, Im0, psf, camera, noise,
                                             ImType='KI')
        D2h['UGIA-F'] = per_frame_D2h(xyF, xy_true)

        # ---- EM-Near-1, single near-true start -----------------------
        xyi = xy_true + NEAR_HALF_NEAR * (
            2 * torch.rand(N, M, 2, device=device, generator=gen) - 1)
        with torch.no_grad():
            xy_near = gauss2d_em_batch_torch(frames, xyi, system,
                                             GN=GN, n_iter=N_ITER)
            ll_near = gauss2d_loglike_batch_torch(frames, xy_near, system)
        D2h['EM-Near-1'] = per_frame_D2h(xy_near, xy_true)

        # ---- EM-GML, multi-start -----------------------------------
        best_ll, best_xy = ll_near.clone(), xy_near.clone()
        # The K starts are evaluated BATCH_STARTS at a time. Stacking the
        # starts along the batch dimension presents the graphics processor
        # with S * N frames per call instead of N, which is much faster for
        # frames of this size, and leaves the result unchanged since the
        # starts are independent and the selection is a maximum over them.
        done = 0
        while done < K:
            S = min(BATCH_STARTS, K - done)
            jitter = NEAR_HALF_WIDE * (
                2 * torch.rand(S, N, M, 2, device=device, generator=gen) - 1)
            xyi_s = (xy_true.unsqueeze(0) + jitter).reshape(S * N, M, 2)
            frames_rep = frames.repeat(S, 1, 1)
            with torch.no_grad():
                xy_s = gauss2d_em_batch_torch(frames_rep, xyi_s, system,
                                              GN=GN, n_iter=N_ITER)
                ll_s = gauss2d_loglike_batch_torch(frames_rep, xy_s, system)
            ll_s = ll_s.reshape(S, N)
            xy_s = xy_s.reshape(S, N, M, 2)
            ll_max, idx = ll_s.max(dim=0)
            xy_max = xy_s[idx, torch.arange(N, device=device)]
            better = ll_max > best_ll
            best_ll = torch.where(better, ll_max, best_ll)
            best_xy = torch.where(better.view(N, 1, 1), xy_max, best_xy)
            done += S
        D2h['EM-GML'] = per_frame_D2h(best_xy, xy_true)

        # ---- networks -------------------------------------------------
        x_in = prepare_input(frames)
        for name in NETWORKS:
            with torch.no_grad():
                pred = nets[name](x_in).view(N, M, 2)
            D2h[name] = per_frame_D2h(pred, xy_true)

        for e in ESTIMATORS:
            results[e].append(armsmd_h(D2h[e]))

        # ---- report and save ------------------------------------------
        line = f"d={d_nm:4d} nm (R_g={d_nm/2:5.1f} nm, accept={acc*100:4.1f}%)  "
        line += "  ".join(f"{e}={armsmd_h(D2h[e]):7.2f}" for e in ESTIMATORS)
        print(line + f"   [{time.perf_counter()-t_d:.1f}s]")

        csv_path = os.path.join(OutDir, f"d={d_nm}_perframe.csv")
        with open(csv_path, "w") as f:
            print("frame," + ",".join(f"D2h_{e}" for e in ESTIMATORS), file=f)
            for n in range(N):
                print(f"{n}," + ",".join(f"{D2h[e][n]:.6f}" for e in ESTIMATORS),
                      file=f)

    # ---- summary table ------------------------------------------------
    print(f"\n{'='*100}")
    print(f"ARMSMD-H (nm) versus emitter separation, M = {M}, N = {N} frames per point")
    print(f"{'='*100}")
    hdr = f"{'d (nm)':>8}" + "".join(f"{e:>11}" for e in ESTIMATORS)
    print(hdr)
    print('-' * len(hdr))
    for i, d_nm in enumerate(D_LIST):
        print(f"{d_nm:>8}" + "".join(f"{results[e][i]:>11.2f}" for e in ESTIMATORS))

    csv_path = os.path.join(OutDir, "sweep_m2.csv")
    with open(csv_path, "w") as f:
        print("d_nm,R_g_nm,accept_rate," + ",".join(ESTIMATORS), file=f)
        for i, d_nm in enumerate(D_LIST):
            print(f"{d_nm},{d_nm/2.0},{acc_rates[i]:.6f}," +
                  ",".join(f"{results[e][i]:.6f}" for e in ESTIMATORS), file=f)
    print(f"\nSaved -> {csv_path}")

    # ---- crossovers ---------------------------------------------------
    print("\nSeparations at which each network is better than the reference:")
    for name in NETWORKS:
        for ref in ['EM-GML', 'UGIA-F']:
            wins = [D_LIST[i] for i in range(len(D_LIST))
                    if results[name][i] < results[ref][i]]
            print(f"  {name:<8} < {ref:<9} at d = "
                  + (", ".join(str(w) for w in wins) if wins else "none"))

    # ---- plot ----------------------------------------------------------
    fig, ax = plt.subplots(figsize=(7, 4.8))
    for e in ESTIMATORS:
        ax.plot(D_LIST, results[e], label=e, markersize=5, **STYLE[e])
    ax.set_xlabel('emitter separation  d  (nm)')
    ax.set_ylabel('ARMSMD-H  (nm)')
    ax.set_xscale('log')
    ax.set_yscale('log')
    ax.set_title(f'Accuracy versus emitter separation, M = {M}')
    ax.grid(True, which='both', alpha=0.3)
    ax.legend(fontsize=8, ncol=2)
    fig.tight_layout()
    png = os.path.join(OutDir, "sweep_m2.png")
    fig.savefig(png, dpi=200)
    plt.close(fig)
    print(f"Saved -> {png}")


# ======================================================================
# Main
# ======================================================================

if __name__ == "__main__":
    import atexit
    os.makedirs("Benchmark-Random", exist_ok=True)
    _log_path = os.path.join(
        "Benchmark-Random",
        f"inference_log_Sweep-M2_{time.strftime('%Y%m%d_%H%M%S')}.txt")
    _logf = open(_log_path, "w", encoding="utf-8")
    _orig_stdout = sys.stdout
    while type(_orig_stdout).__name__ == "_Tee":
        _orig_stdout = _orig_stdout.streams[0]
    sys.stdout = _Tee(_orig_stdout, _logf)

    @atexit.register
    def _close_log(_o=_orig_stdout, _f=_logf):
        sys.stdout = _o
        _f.close()

    print(f"[Log] Writing run log -> {_log_path}")

    torch.set_float32_matmul_precision('high')
    print_device_info()
    plt.close('all')

    t0 = time.perf_counter()
    run()
    t1 = time.perf_counter()
    mins, sec = divmod(t1 - t0, 60)
    print(f"\n[Timing] Sweep-M2-Separation: {int(mins)}m {sec:.1f}s")
