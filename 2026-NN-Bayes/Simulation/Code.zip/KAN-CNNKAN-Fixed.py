"""
KAN-CNNKAN-Fixed.py

Evaluate trained KAN and CNN-KAN models on Dataset-Fixed.
For each (d, M) pair, N=25 frames are processed and the
accumulated N*M estimated locations are compared with the
M true locations via RMSMD — same metric as UGIA-EM-Fixed.py.

Trained models are loaded from:
    KAN-Trained/kan_localizer_M=<M>.pth
    CNN-KAN-Trained/cnnkan_localizer_M=<M>.pth

Yi Sun
"""

import sys
import os
import time
import math

# ----------------------------------------------------------------------
# Console logging: duplicate all stdout to a log file in the Benchmark folder
# ----------------------------------------------------------------------
class _Tee:
    """Write everything printed to the console AND to a log file."""
    def __init__(self, *streams):
        self.streams = streams
    def write(self, data):
        for s in self.streams:
            try:
                s.write(data)
            except UnicodeEncodeError:
                s.write(data.encode("ascii", "replace").decode("ascii"))
            s.flush()
    def flush(self):
        for s in self.streams:
            s.flush()

import numpy as np
import torch
import tifffile
import matplotlib.pyplot as plt

ROOT = r"K:\Research_KB"
sys.path.append(ROOT)

from SMLM_Lib import Camera, Gaussian2DPSF, Noise
from SMLM_Lib import print_device_info
from SMLM_Lib.KAN import KANLocalizer, CNNKANLocalizer
from SMLM_Lib.metrics import (rmsmd_per_frame, rmsmd_h_per_frame)

# ----------------------------------------------------------------------
# Metric note. This paper estimates the emitter locations from a single data
# frame, so every frame is an independent estimation problem with M estimates
# and M emitters. The metric is therefore RMSMD-H, i.e. the error under the
# Hungarian assignment, computed frame by frame and averaged over the frames
# as ARMSMD-H. The N estimates of one emitter obtained from N frames are not
# pooled into a reconstructed image, so the partition metrics RMSMD-P and
# RMSE-P of Sun (2022), which are intended for a reconstruction in which one
# emitter carries many estimates, are not used here.
# ----------------------------------------------------------------------



# ======================================================================
# Global configuration
# ======================================================================

N             = 25
Data_folder   = "Dataset-Fixed"
KAN_folder    = "KAN-Trained"
CNNKAN_folder = "CNN-KAN-Trained"

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

camera = Camera(Kx=7, Ky=7, Dx=100.0, Dy=100.0, Dt=0.01)
Kx, Ky = camera.Kx, camera.Ky
Dx, Dy = camera.Dx, camera.Dy


# ======================================================================
# Helpers
# ======================================================================

def load_xy_file(path):
    arr = np.loadtxt(path, dtype=np.float32)
    if arr.ndim == 1:
        arr = arr.reshape(1, 2)
    return torch.tensor(arr, dtype=torch.float32, device=device)


def load_frames(path):
    arr = tifffile.imread(path).astype(np.float32)
    return torch.tensor(arr, dtype=torch.float32, device=device)


def load_kan(M):
    model = KANLocalizer(Kx=camera.Kx, Ky=camera.Ky, M=M).to(device)
    path  = os.path.join(KAN_folder, f"kan_localizer_M={M}.pth")
    model.load_state_dict(torch.load(path, map_location=device))
    model.eval()
    return model


def load_cnnkan(M):
    model = CNNKANLocalizer(Kx=camera.Kx, Ky=camera.Ky, M=M).to(device)
    path  = os.path.join(CNNKAN_folder, f"cnnkan_localizer_M={M}.pth")
    model.load_state_dict(torch.load(path, map_location=device))
    model.eval()
    return model


def prepare_input(frames):
    """(N, Ky, Kx) -> (N, Kx*Ky) normalised."""
    x = frames.view(frames.shape[0], -1)
    x = x / (x.amax(dim=1, keepdim=True) + 1e-8)
    return x


# ======================================================================
# Benchmark
# ======================================================================

def run_model_fixed(alg_name, outdir):
    os.makedirs(outdir, exist_ok=True)

    for d_nm in [25, 50, 75, 100, 125, 150]:
        for M in range(1, 6):

            xy_path  = os.path.join(Data_folder, f"d={d_nm}_M={M}_xy.txt")
            tif_path = os.path.join(Data_folder, f"d={d_nm}_M={M}_Frames.tif")
            if not os.path.exists(xy_path) or not os.path.exists(tif_path):
                print(f"d={d_nm:3d}  M={M}  [skip — dataset not found]")
                continue

            xy_true    = load_xy_file(xy_path)    # (M, 2)
            frames_all = load_frames(tif_path)    # (N, Ky, Kx)

            model = load_kan(M) if alg_name == 'KAN' else load_cnnkan(M)

            x = prepare_input(frames_all)         # (N, Kx*Ky)

            with torch.no_grad():
                pred = model(x)                   # (N, M, 2)

            # Accumulate all N*M estimates into (N*M, 2)
            # Every frame is an independent estimation problem with M
            # estimates and M emitters, so the metric is RMSMD-H computed
            # frame by frame and averaged over the N frames.
            true_all = xy_true.unsqueeze(0).expand(N, M, 2)
            _, D2_all  = rmsmd_per_frame(pred, true_all)
            _, D2h_all = rmsmd_h_per_frame(pred, true_all)
            D_rmsmd   = math.sqrt(D2_all.mean().item())
            D_rmsmd_h = math.sqrt(D2h_all.mean().item())
            xy_est = pred.reshape(N * M, 2)

            print(f"d={d_nm:3d}  M={M}  {alg_name}  "
                  f"ARMSMD = {D_rmsmd:.2f} nm  ARMSMD-H = {D_rmsmd_h:.2f} nm")

            # Visualization — show ARMSMD-H in legend
            fig, ax = plt.subplots(figsize=(4, 4))
            ax.imshow(np.zeros((Ky, Kx), dtype=np.float32),
                      cmap="gray", origin="upper")
            ax.set_xlim(-0.5, Kx-0.5);  ax.set_ylim(Ky-0.5, -0.5)
            ax.set_aspect("equal");  ax.axis("off")

            xy_est_np  = xy_est.cpu().numpy()
            xy_true_np = xy_true.cpu().numpy()

            ax.scatter(xy_est_np[:,0]/Dx-0.5,  xy_est_np[:,1]/Dy-0.5,
                       c="white", s=10,
                       label=f"{alg_name}  ARMSMD-H = {D_rmsmd_h:.2f} nm")
            ax.scatter(xy_true_np[:,0]/Dx-0.5, xy_true_np[:,1]/Dy-0.5,
                       c="red", s=10, label="Ground Truth")
            ax.legend(loc="upper left", framealpha=1.0, labelcolor="white",
                      frameon=True, edgecolor="white", facecolor="none", fontsize=9)

            outfile = os.path.join(outdir, f"d={d_nm}_M={M}_{alg_name}.png")
            fig.savefig(outfile, dpi=150, bbox_inches="tight")
            plt.show(block=False);  plt.close(fig)


# ======================================================================
# Main
# ======================================================================

if __name__ == "__main__":
    # ---- start run log (saved in the Benchmark folder) ----
    import atexit
    os.makedirs("Benchmark-Fixed", exist_ok=True)
    _log_path = os.path.join(
        "Benchmark-Fixed", f"inference_log_KAN-CNNKAN_Fixed_{time.strftime('%Y%m%d_%H%M%S')}.txt")
    _logf = open(_log_path, "w", encoding="utf-8")
    _orig_stdout = sys.stdout
    while type(_orig_stdout).__name__ == "_Tee":  # unwrap a leftover Tee
        _orig_stdout = _orig_stdout.streams[0]
    sys.stdout = _Tee(_orig_stdout, _logf)

    @atexit.register
    def _close_log(_o=_orig_stdout, _f=_logf):
        sys.stdout = _o
        _f.close()

    print(f"[Log] Writing run log -> {_log_path}")
    torch.set_float32_matmul_precision('high')
    print_device_info()
    plt.close('all')

    def timed_run(fn, label, *args, **kwargs):
        t0 = time.perf_counter()
        fn(*args, **kwargs)
        t1 = time.perf_counter()
        mins, sec = divmod(t1 - t0, 60)
        print(f"[Timing] {label}: {int(mins)}m {sec:.1f}s")

    print("\n=== KAN Benchmark (Fixed) ===")
    timed_run(run_model_fixed, "KAN     (Fixed)", 'KAN',     "Benchmark-Fixed/KAN")

    print("\n=== CNN-KAN Benchmark (Fixed) ===")
    timed_run(run_model_fixed, "CNN-KAN (Fixed)", 'CNN-KAN', "Benchmark-Fixed/CNN-KAN")
