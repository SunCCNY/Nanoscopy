"""
Stratified-Random.py
 
Per-frame evaluation of all seven estimators on Dataset-Random, saved with the
per-frame minimum emitter separation so the results can be stratified by
overlap severity.
 
Every frame of Dataset-Random is drawn from the same distribution the networks
were trained on, so training coverage is adequate in every stratum by
construction and the only quantity varying across strata is the overlap
severity d_min. This isolates the effect of emitter overlap from the effect of
train/test distribution mismatch, which the fixed circle constellations cannot
do because their overlap and their training coverage vary together.
 
For each M and each frame the script records
 
    d_min      minimum pairwise distance between the true emitter positions,
    D2h        squared RMSMD-H of every estimator on that frame,
 
for the estimators
 
    UGIA-F         unbiased, Fisher information of the frame, oracle parameters
    EM-Near-1         EM from a near-true start, +-NEAR_HALF_NEAR nm
    EM-GML       multi-start EM, K wide starts, highest log-likelihood kept
    APL, CNN-APL, KAN, CNN-KAN, ViT      frame-trained networks
 
Results are written to Benchmark-Random/Stratified/M=<M>_perframe.csv and are
consumed by Stratified-Analysis.py, which does the binning and plotting.
 
Aggregate ARMSMD-H over all frames is also printed, which should reproduce the
values from the individual benchmark scripts and so serves as a consistency
check.
 
Yi Sun
"""
 
import sys
import os
import time
import math
import numpy as np
import torch
import tifffile
import matplotlib.pyplot as plt
 
ROOT = r"K:\Research_KB"   # <- change to your actual path
sys.path.append(ROOT)
 
 
# ----------------------------------------------------------------------
# Console logging: duplicate all stdout to a log file in the Benchmark folder
# ----------------------------------------------------------------------
class _Tee:
    """Write everything printed to the console AND to a log file."""
    def __init__(self, *streams):
        self.streams = streams
    def write(self, data):
        for s in self.streams:
            try:
                s.write(data)
            except UnicodeEncodeError:
                s.write(data.encode("ascii", "replace").decode("ascii"))
            s.flush()
    def flush(self):
        for s in self.streams:
            s.flush()
 
 
from SMLM_Lib import (
    SystemConfig,
    EmitterData,
    Gaussian2DPSF,
    Camera,
    Noise,
    gauss2d_ugia_f_batch_torch,
    gauss2d_em_batch_torch,
    print_device_info,
)
from SMLM_Lib.Gauss2D import gauss2d_loglike_batch_torch
from SMLM_Lib.metrics import rmsmd_h_per_frame
from SMLM_Lib.APL import APLLocalizer, CNNAPLLocalizer
from SMLM_Lib.KAN import KANLocalizer, CNNKANLocalizer
from SMLM_Lib.ViT import ViTLocalizer
 
 
# ============ configuration ============
N           = 1000
Data_folder = "Dataset-Random"
OutDir      = "Benchmark-Random/Stratified"
 
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
 
camera = Camera(Kx=7, Ky=7, Dx=100.0, Dy=100.0, Dt=0.01)
Kx, Ky = camera.Kx, camera.Ky
 
psf = Gaussian2DPSF(sigma=108.81)
 
# Frozen non-uniform noise field saved with the dataset.
b_map = torch.tensor(np.loadtxt(os.path.join(Data_folder, "b_map.txt"),
                                dtype=np.float32), device=device)
G_map = torch.tensor(np.loadtxt(os.path.join(Data_folder, "G_map.txt"),
                                dtype=np.float32), device=device)
noise = Noise(b=b_map, mu=G_map, G=G_map)   # mu_k = G_k
 
Im0 = 300000.0   # photons / s
 
# EM settings, matching EM-GML-Random.py
NEAR_HALF_NEAR = 10.0
NEAR_HALF_WIDE = 100.0
K              = 250
 
# Number of starts evaluated in one call. The batch presented to the
# graphics processor is BATCH_STARTS times the number of frames, so a
# larger value uses the device more fully at the cost of more memory.
# The result does not depend on it.
BATCH_STARTS   = 5
SEED           = 0
N_ITER         = 300
GN             = 'N'
 
NET_FOLDERS = {
    'APL':     ("APL-Trained",     "apl_localizer_M={}.pth"),
    'CNN-APL': ("CNN-APL-Trained", "cnnapl_localizer_M={}.pth"),
    'KAN':     ("KAN-Trained",     "kan_localizer_M={}.pth"),
    'CNN-KAN': ("CNN-KAN-Trained", "cnnkan_localizer_M={}.pth"),
    'ViT':     ("ViT-Trained",     "vit_localizer_M={}.pth"),
}
 
ESTIMATORS = ['UGIA-F', 'EM-Near-1', 'EM-GML',
              'APL', 'CNN-APL', 'KAN', 'CNN-KAN', 'ViT']
 
 
# ============ helpers ============
 
def load_frames(M):
    path = os.path.join(Data_folder, f"M={M}_Frames.tif")
    arr  = tifffile.imread(path).astype(np.float32)
    return torch.tensor(arr, dtype=torch.float32, device=device)
 
 
def load_xy_all(M):
    path = os.path.join(Data_folder, f"M={M}_xy.txt")
    arr  = np.loadtxt(path, dtype=np.float32, skiprows=1)
    return torch.tensor(arr, dtype=torch.float32, device=device).reshape(N, M, 2)
 
 
def load_net(name, M):
    folder, pat = NET_FOLDERS[name]
    if name == 'APL':
        model = APLLocalizer(Kx=Kx, Ky=Ky, M=M)
    elif name == 'CNN-APL':
        model = CNNAPLLocalizer(Kx=Kx, Ky=Ky, M=M)
    elif name == 'KAN':
        model = KANLocalizer(Kx=Kx, Ky=Ky, M=M)
    elif name == 'CNN-KAN':
        model = CNNKANLocalizer(Kx=Kx, Ky=Ky, M=M)
    else:
        model = ViTLocalizer(Kx=Kx, Ky=Ky, M=M)
    model = model.to(device)
    model.load_state_dict(
        torch.load(os.path.join(folder, pat.format(M)), map_location=device))
    model.eval()
    return model
 
 
def prepare_input(frames):
    x = frames.view(frames.shape[0], -1)
    return x / (x.amax(dim=1, keepdim=True) + 1e-8)
 
 
def per_frame_d_min(xy_all, M):
    """(N,) minimum pairwise true separation per frame; inf when M == 1."""
    if M == 1:
        return torch.full((N,), float('inf'))
    D = torch.cdist(xy_all, xy_all)                       # (N, M, M)
    D = D + torch.eye(M, device=xy_all.device) * 1e9      # mask self-pairs
    return D.amin(dim=(1, 2)).cpu()
 
 
def per_frame_D2h(xy_est, xy_ref):
    """(N,) squared RMSMD-H per frame, i.e. under the Hungarian assignment.
 
    The number of estimates equals the number of emitters, so the
    correspondence of maximum likelihood is the assignment minimising the
    total squared distance. A stratum or sweep value is obtained as
    sqrt(mean(D2h)), i.e. the squared distances are averaged and the square
    root taken once at the end.
    """
    _, D2 = rmsmd_h_per_frame(xy_est, xy_ref)
    return D2.cpu().numpy().astype(np.float64)
 
 
def armsmd_h(D2h):
    return float(np.sqrt(np.mean(D2h)))
 
 
# ============ main evaluation ============
 
def run():
    os.makedirs(OutDir, exist_ok=True)
    gen = torch.Generator(device=device).manual_seed(SEED)
 
    for M in range(1, 6):
        print(f"\n{'='*66}\nM = {M}\n{'='*66}")
        t_M = time.perf_counter()
 
        frames_all = load_frames(M)          # (N, Ky, Kx)
        xy_all     = load_xy_all(M)          # (N, M, 2)
        dmin       = per_frame_d_min(xy_all, M)
 
        Im_tensor = torch.full((1, M), Im0, dtype=torch.float32, device=device)
        emitter = EmitterData(xy=xy_all[0:1], Im=Im_tensor)
        system  = SystemConfig(emitter=emitter, psf=psf, camera=camera, noise=noise)
 
        D2h = {}
 
        # ---- UGIA-F -------------------------------------------------
        t0 = time.perf_counter()
        with torch.no_grad():
            xyF = gauss2d_ugia_f_batch_torch(xy_all, Im0, psf, camera, noise,
                                             ImType='KI')
        D2h['UGIA-F'] = per_frame_D2h(xyF, xy_all)
        print(f"  UGIA-F     ARMSMD-H = {armsmd_h(D2h['UGIA-F']):7.2f} nm "
              f"[{time.perf_counter()-t0:.1f}s]")
 
        # ---- EM-Near-1, near-true start --------------------------------
        t0 = time.perf_counter()
        xyi_near = xy_all + NEAR_HALF_NEAR * (
            2 * torch.rand(N, M, 2, device=device, generator=gen) - 1)
        with torch.no_grad():
            xy_near = gauss2d_em_batch_torch(frames_all, xyi_near, system,
                                             GN=GN, n_iter=N_ITER)
            ll_near = gauss2d_loglike_batch_torch(frames_all, xy_near, system)
        D2h['EM-Near-1'] = per_frame_D2h(xy_near, xy_all)
        print(f"  EM-Near-1  ARMSMD-H = {armsmd_h(D2h['EM-Near-1']):7.2f} nm "
              f"[{time.perf_counter()-t0:.1f}s]")
 
        # ---- EM-GML, multi-start ----------------------------------
        t0 = time.perf_counter()
        best_ll = ll_near.clone()
        best_xy = xy_near.clone()
        # The K starts are evaluated BATCH_STARTS at a time. Stacking the
        # starts along the batch dimension presents the graphics processor
        # with S * N frames per call instead of N, which is much faster for
        # frames of this size, and leaves the result unchanged since the
        # starts are independent and the selection is a maximum over them.
        done = 0
        while done < K:
            S = min(BATCH_STARTS, K - done)
            jitter = NEAR_HALF_WIDE * (
                2 * torch.rand(S, N, M, 2, device=device, generator=gen) - 1)
            xyi_s = (xy_all.unsqueeze(0) + jitter).reshape(S * N, M, 2)
            frames_rep = frames_all.repeat(S, 1, 1)
            with torch.no_grad():
                xy_s = gauss2d_em_batch_torch(frames_rep, xyi_s, system,
                                              GN=GN, n_iter=N_ITER)
                ll_s = gauss2d_loglike_batch_torch(frames_rep, xy_s, system)
            ll_s = ll_s.reshape(S, N)
            xy_s = xy_s.reshape(S, N, M, 2)
            ll_max, idx = ll_s.max(dim=0)
            xy_max = xy_s[idx, torch.arange(N, device=device)]
            better = ll_max > best_ll
            best_ll = torch.where(better, ll_max, best_ll)
            best_xy = torch.where(better.view(N, 1, 1), xy_max, best_xy)
            done += S
        D2h['EM-GML'] = per_frame_D2h(best_xy, xy_all)
        print(f"  EM-GML     ARMSMD-H = {armsmd_h(D2h['EM-GML']):7.2f} nm "
              f"[{time.perf_counter()-t0:.1f}s, K={K}]")
 
        # ---- networks -----------------------------------------------
        x_in = prepare_input(frames_all)
        for name in ['APL', 'CNN-APL', 'KAN', 'CNN-KAN', 'ViT']:
            t0 = time.perf_counter()
            model = load_net(name, M)
            with torch.no_grad():
                pred = model(x_in).view(N, M, 2)
            D2h[name] = per_frame_D2h(pred, xy_all)
            print(f"  {name:10s} ARMSMD-H = {armsmd_h(D2h[name]):7.2f} nm "
                  f"[{time.perf_counter()-t0:.1f}s]")
            del model
 
        # ---- save per-frame table -----------------------------------
        csv_path = os.path.join(OutDir, f"M={M}_perframe.csv")
        with open(csv_path, "w") as f:
            print("frame,d_min," + ",".join(f"D2h_{e}" for e in ESTIMATORS),
                  file=f)
            dm = dmin.numpy()
            for n in range(N):
                vals = ",".join(f"{D2h[e][n]:.6f}" for e in ESTIMATORS)
                print(f"{n},{dm[n]:.6f},{vals}", file=f)
        print(f"  Saved -> {csv_path}")
 
        mins, sec = divmod(time.perf_counter() - t_M, 60)
        print(f"  [M={M} total {int(mins)}m {sec:.1f}s]")
 
 
# ======================================================================
# Main
# ======================================================================
 
if __name__ == "__main__":
    import atexit
    os.makedirs("Benchmark-Random", exist_ok=True)
    _log_path = os.path.join(
        "Benchmark-Random",
        f"inference_log_Stratified_Random_{time.strftime('%Y%m%d_%H%M%S')}.txt")
    _logf = open(_log_path, "w", encoding="utf-8")
    _orig_stdout = sys.stdout
    while type(_orig_stdout).__name__ == "_Tee":
        _orig_stdout = _orig_stdout.streams[0]
    sys.stdout = _Tee(_orig_stdout, _logf)
 
    @atexit.register
    def _close_log(_o=_orig_stdout, _f=_logf):
        sys.stdout = _o
        _f.close()
 
    print(f"[Log] Writing run log -> {_log_path}")
 
    # Seed the global RNG so the UGIA-F Gaussian draw of Eq. (33) is
    # reproducible. UGIA-F uses the default generator, whereas the EM starts
    # use their own seeded Generator, so this fixes UGIA-F only and leaves the
    # EM and network results unchanged.
    torch.manual_seed(SEED)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(SEED)
 
    torch.set_float32_matmul_precision('high')
    print_device_info()
    plt.close('all')
 
    t0 = time.perf_counter()
    run()
    t1 = time.perf_counter()
    mins, sec = divmod(t1 - t0, 60)
    print(f"\n[Timing] Stratified-Random: {int(mins)}m {sec:.1f}s")
 

