"""
profile_vit_scaling.py

Isolate why ViT training time grows fast with M while the plain networks
stay nearly flat. Times three components separately as a function of M on
the real GPU, using the same shapes as ViT-Training.py (batch 256, 7x7
frame, d_model=128, 6 layers), so the dominant term can be identified and
reported in the paper.

Components timed per training step:
  (1) transformer forward+backward  -- M enters only via the 2M-wide head
  (2) hungarian_loss                -- M enters via the matching solver
  (3) output head width 2M          -- isolated, negligible expected

Also reports which Hungarian solver is active (gpu / scipy / brute-force),
since that determines how the loss scales with M.

Run:
    python profile_vit_scaling.py
"""

import time
import torch

# Reuse the real loss + solver selection from the library.
import sys
sys.path.append(r"K:\Research_KB")
from SMLM_Lib.train_utils import hungarian_loss
import SMLM_Lib.train_utils as tu
from SMLM_Lib.ViT import ViTLocalizer


DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
Kx = Ky = 7
BATCH = 256
N_ITERS = 50          # timed iterations per M (after warmup)
WARMUP = 10
M_LIST = [1, 2, 3, 4, 5]


def sync():
    if DEVICE.type == "cuda":
        torch.cuda.synchronize()


def time_call(fn, n_iters=N_ITERS, warmup=WARMUP):
    """Median per-call time in milliseconds."""
    for _ in range(warmup):
        fn()
    sync()
    ts = []
    for _ in range(n_iters):
        sync(); t0 = time.perf_counter()
        fn()
        sync(); t1 = time.perf_counter()
        ts.append((t1 - t0) * 1e3)
    ts.sort()
    return ts[len(ts) // 2]


def bench_full_step(M):
    """Full ViT forward + Hungarian loss + backward, as in training."""
    model = ViTLocalizer(Kx=Kx, Ky=Ky, M=M).to(DEVICE)
    opt = torch.optim.Adam(model.parameters(), lr=1e-4)
    x = torch.rand(BATCH, Kx * Ky, device=DEVICE)
    y = torch.rand(BATCH, M, 2, device=DEVICE) * 700.0

    def step():
        opt.zero_grad()
        pred = model(x)
        loss = hungarian_loss(pred, y)
        loss.backward()
        opt.step()

    return time_call(step)


def bench_forward_only(M):
    """ViT forward+backward with a fixed-order MSE (no matching)."""
    model = ViTLocalizer(Kx=Kx, Ky=Ky, M=M).to(DEVICE)
    opt = torch.optim.Adam(model.parameters(), lr=1e-4)
    x = torch.rand(BATCH, Kx * Ky, device=DEVICE)
    y = torch.rand(BATCH, M, 2, device=DEVICE) * 700.0

    def step():
        opt.zero_grad()
        pred = model(x)
        loss = torch.nn.functional.mse_loss(pred, y)   # no permutation search
        loss.backward()
        opt.step()

    return time_call(step)


def bench_loss_only(M):
    """Hungarian loss alone on random predictions (no network).

    A fresh prediction tensor is built inside the timed step so each
    backward traverses a new graph, i.e. no retain_graph needed. This
    isolates the solver cost, which for the scipy branch is a CPU loop
    over the batch and is expected to grow with M.
    """
    y = torch.rand(BATCH, M, 2, device=DEVICE) * 700.0
    base = torch.rand(BATCH, M, 2, device=DEVICE) * 700.0

    def step():
        pred = base.detach().clone().requires_grad_(True)
        loss = hungarian_loss(pred, y)
        loss.backward()

    return time_call(step)


def bench_real_step(M):
    """One full training step INCLUDING on-the-fly frame generation, i.e.
    generate_batch -> forward -> hungarian_loss -> backward -> opt.step,
    exactly as ViT-Training.py does. This is the only bench that contains
    the data pipeline, so comparing it to bench_full_step isolates the cost
    of frame generation, which renders M PSFs per frame and runs on each step.
    Returns (ms, None) if SMLM_Lib generation is unavailable.
    """
    try:
        from SMLM_Lib import Camera, Gaussian2DPSF, Noise
        from SMLM_Lib.train_utils import generate_batch
    except Exception as e:
        print(f"  [real step] generate_batch unavailable: {e}")
        return None

    import os, numpy as np
    camera = Camera(Kx=Kx, Ky=Ky, Dx=100.0, Dy=100.0, Dt=0.01)
    psf = Gaussian2DPSF(sigma=108.81)
    # Frozen field if present, else a plain uniform field just for timing.
    folder = "Dataset-Random"
    try:
        b_map = torch.tensor(np.loadtxt(os.path.join(folder, "b_map.txt"),
                                        dtype=np.float32))
        G_map = torch.tensor(np.loadtxt(os.path.join(folder, "G_map.txt"),
                                        dtype=np.float32))
        noise = Noise(b=b_map, mu=G_map, G=G_map)
    except Exception:
        b_map = torch.full((Ky, Kx), 5.0)
        noise = Noise(b=b_map, mu=5.0, G=3.0)
    Im0 = 300000.0

    model = ViTLocalizer(Kx=Kx, Ky=Ky, M=M).to(DEVICE)
    opt = torch.optim.Adam(model.parameters(), lr=1e-4)

    def step():
        x, y = generate_batch(BATCH, M, camera, psf, noise, Im0)
        x = x.to(DEVICE); y = y.to(DEVICE)
        opt.zero_grad()
        pred = model(x)
        loss = hungarian_loss(pred, y)
        loss.backward()
        opt.step()

    return time_call(step)


if __name__ == "__main__":
    print("=== ViT scaling profiler ===")
    print(f"Device       : {torch.cuda.get_device_name(0) if DEVICE.type=='cuda' else 'CPU'}")
    print(f"Hungarian solver active: {tu._SOLVER}")
    print(f"Batch={BATCH}  frame={Kx}x{Ky}  timed_iters={N_ITERS}\n")

    print(f"{'M':>3} | {'full step':>10} | {'fwd+MSE':>10} | {'loss only':>10} | "
          f"{'real step':>10} | {'match share':>11}")
    print("-" * 74)

    rows = []
    for M in M_LIST:
        full = bench_full_step(M)
        fwd  = bench_forward_only(M)
        loss = bench_loss_only(M)
        real = bench_real_step(M)
        real_str = f"{real:>8.2f}ms" if real is not None else f"{'n/a':>10}"
        # Time attributable to matching = full step - (fwd+MSE step).
        match = max(full - fwd, 0.0)
        share = 100.0 * match / full if full > 0 else 0.0
        rows.append((M, full, fwd, loss, share, real))
        print(f"{M:>3} | {full:>8.2f}ms | {fwd:>8.2f}ms | {loss:>8.2f}ms | "
              f"{real_str} | {share:>9.1f}%")

    print("\nInterpretation:")
    print("  - If 'fwd+MSE' grows fast with M   -> transformer/head + GPU saturation is the driver.")
    print("  - If 'match share' grows fast with M -> the Hungarian solver is the driver.")
    print("  - If 'real step' grows fast with M but 'full step' does NOT")
    print("    -> on-the-fly frame generation (M PSFs/frame) is the driver.")
    print("  - 'loss only' shows the solver cost in isolation (no network).")

    # Growth factors M=1 -> M=5.
    if len(rows) >= 2:
        f1, fwd1 = rows[0][1], rows[0][2]
        f5, fwd5 = rows[-1][1], rows[-1][2]
        print(f"\n  full step  M1->M5 growth : {f5/f1:0.2f}x")
        print(f"  fwd+MSE    M1->M5 growth : {fwd5/fwd1:0.2f}x")
        r1, r5 = rows[0][5], rows[-1][5]
        if r1 is not None and r5 is not None and r1 > 0:
            print(f"  real step  M1->M5 growth : {r5/r1:0.2f}x")