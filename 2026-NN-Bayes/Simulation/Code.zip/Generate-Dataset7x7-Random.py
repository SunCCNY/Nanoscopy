import os
import sys
import time
import torch
import numpy as np
import tifffile
import matplotlib.pyplot as plt
import matplotlib.patches as patches

sys.path.append(r"K:\Research_KB")

from SMLM_Lib import (
    SystemConfig,
    EmitterData,
    Gaussian2DPSF,
    Camera,
    Noise,
    gauss2d_frame_torch,
    print_device_info,
)
from SMLM_Lib.position import sample_emitters_batch, background_cloud


# ============================================================
# Non-uniform frozen noise field
# ============================================================

def build_frozen_noise(
    camera,
    b_min=4.0, b_max=6.0, corr_px=2.0,
    g_min=2.0, g_max=4.0,
    folder=".",
    seed_b=0, seed_g=1,
    device=None,
):
    """Build one non-uniform noise field, frozen for the whole dataset.

    The Poisson background b_k is a smooth spatial cloud on [b_min, b_max]
    with correlation length corr_px pixels, i.e. autofluorescence that
    varies slowly across the frame. The Gaussian readout G_k = mu_k is
    drawn i.i.d. uniform per pixel on [g_min, g_max], i.e. the pixel-variant
    readout of an sCMOS camera, with the mean set equal to the variance so
    the Poisson approximation applies. Both maps are (Ky, Kx) and are shared
    by every M and every frame of the dataset. They are saved to disk so
    the UGIA-F, EM-GML, and network estimators all consume the identical
    field that generated the frames.

    Returns
    -------
    noise : Noise built from the frozen b_k and G_k maps.
    """
    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    b_map = background_cloud(camera, b_min, b_max, corr_px=corr_px,
                             seed=seed_b, device=device, dtype=torch.float32)

    g_gen = torch.Generator(device="cpu").manual_seed(int(seed_g))
    g_unit = torch.rand(camera.Ky, camera.Kx, generator=g_gen, dtype=torch.float32)
    G_map = (g_min + (g_max - g_min) * g_unit).to(device=device)   # mu_k = G_k
    mu_map = G_map.clone()

    os.makedirs(folder, exist_ok=True)
    np.savetxt(os.path.join(folder, "b_map.txt"),
               b_map.cpu().numpy(), fmt="%.6f")
    np.savetxt(os.path.join(folder, "G_map.txt"),
               G_map.cpu().numpy(), fmt="%.6f")
    print(f"  Saved noise maps -> {folder}/b_map.txt, {folder}/G_map.txt")
    print(f"  b_k in [{b_map.min():.3f}, {b_map.max():.3f}]  "
          f"G_k=mu_k in [{G_map.min():.3f}, {G_map.max():.3f}]  "
          f"(corr_px={corr_px})")

    return Noise(b=b_map, mu=mu_map, G=G_map)


# ============================================================
# Visualization — show frame 1 with emitter locations
# ============================================================

def show_and_save_one_frame(frame, xy_nm, camera, save_path=None):
    """Show the first frame with true emitter locations overlaid.

    Parameters
    ----------
    frame     : (Ky, Kx) float32 array — pixel photon counts
    xy_nm     : (M, 2) float32 array  — emitter (x, y) in nm for this frame
    camera    : Camera
    save_path : str or None — if given, save as TIFF
    """
    xy_pix = xy_nm / np.array([camera.Dx, camera.Dy], dtype=np.float32) - 0.5

    fig, ax = plt.subplots(figsize=(4, 4))
    ax.imshow(frame, cmap='gray', origin='upper')
    ax.scatter(xy_pix[:, 0], xy_pix[:, 1], c='red', s=40, zorder=5)

    # Outline the central 3×3 pixel block in green
    # Pixels 2,3,4 (0-indexed) → rectangle from (1.5,1.5) of size 3×3
    rect = patches.Rectangle(
        (1.5, 1.5), 3, 3,
        linewidth=1, edgecolor='lime', facecolor='none', zorder=6,
    )
    ax.add_patch(rect)

    ax.set_title(f"Frame 1  |  M={len(xy_nm)} emitters")
    ax.axis('off')
    plt.tight_layout()

    if save_path is not None:
        os.makedirs(os.path.dirname(save_path) or '.', exist_ok=True)
        fig.savefig(save_path, format='tiff', dpi=300, bbox_inches='tight')
        print(f"  Saved shown figure -> {save_path}")

    plt.show()
    plt.close(fig)


# ============================================================
# Noise mean maps (Poisson and Gaussian)
# ============================================================

def save_noise_mean_figure(camera, noise, Dataset_folder):
    """Save the two per-pixel noise mean maps for the dataset.

    The mean photon count in pixel k contributed by each noise source is
        Poisson background : Dt * Dx * Dy * b_k
        Gaussian readout   : Dt * Dx * Dy * G_k
    where mu_k = G_k in this model. Shown as two grayscale panels so the
    smooth background cloud b_k and the pixel-independent readout G_k are
    directly visible. These are deterministic means of the frozen field
    shared by the whole dataset, not random samples.

    Output file
    -----------
    Dataset_folder/
        Noise_MeanMaps.tif  -- two-panel figure, Poisson mean | Gaussian mean
    """
    os.makedirs(Dataset_folder, exist_ok=True)

    print(f"\n--- Noise mean maps (Poisson and Gaussian) ---")

    factor = camera.Dt * camera.Dx * camera.Dy          # Dt * Dx * Dy
    poisson_mean  = (factor * noise.b).cpu().numpy()     # Dt*Dx*Dy*b_k
    gaussian_mean = (factor * noise.G).cpu().numpy()     # Dt*Dx*Dy*G_k
    print(f"  Poisson  mean Dt*Dx*Dy*b_k in [{poisson_mean.min():.1f}, "
          f"{poisson_mean.max():.1f}] photons")
    print(f"  Gaussian mean Dt*Dx*Dy*G_k in [{gaussian_mean.min():.1f}, "
          f"{gaussian_mean.max():.1f}] photons")

    fig, axes = plt.subplots(1, 2, figsize=(8, 4))
    for ax, img, title in (
        (axes[0], poisson_mean,  r"Poisson mean  $\Delta t\,\Delta x\,\Delta y\,b_k$"),
        (axes[1], gaussian_mean, r"Gaussian mean  $\Delta t\,\Delta x\,\Delta y\,G_k$"),
    ):
        im = ax.imshow(img, cmap='gray', origin='upper')
        ax.set_title(title)
        ax.axis('off')
        fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label="photons")
    plt.tight_layout()
    fig_path = os.path.join(Dataset_folder, "Noise_MeanMaps.tif")
    fig.savefig(fig_path, format='tiff', dpi=300, bbox_inches='tight')
    print(f"  Saved noise mean maps   -> {fig_path}")
    plt.show()
    plt.close(fig)

def generate_dataset_random(
    M,
    N_frames,
    camera,
    psf,
    noise,
    Dataset_folder,
    Im0=300000.0,
    save_fig=True,
):
    """Generate N_frames random frames for M emitters and save to disk.

    Emitter positions are drawn using sample_emitters_batch() with
    margin_px=2, which places all emitters uniformly inside the central
    3×3 pixel block (pixels 2,3,4 on a 7×7 frame → [200,500] nm). The
    noise field carried by ``noise`` is the frozen non-uniform field shared
    by every M of the dataset.

    Output files
    ------------
    Dataset_folder/
        M=<M>_Frames.tif        — (N_frames, Ky, Kx) uint16 multi-page TIFF
        M=<M>_xy.txt            — (N_frames*M, 2) float, rows = (x, y) in nm
        M=<M>_ShownFigure.tif   — frame 1 with emitter locations overlaid
    """
    os.makedirs(Dataset_folder, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print(f"\n--- M={M}  ({N_frames} frames) ---")

    # ----------------------------------------------------------
    # 1. Sample ALL N_frames emitter configurations at once.
    #    xy_all : (N_frames, M, 2) in nm
    # ----------------------------------------------------------
    xy_all = sample_emitters_batch(N_frames, M, camera, margin_px=2)

    # ----------------------------------------------------------
    # 2. Build SystemConfig with all N_frames positions at once
    #    so gauss2d_frame_torch generates all frames in one batched call.
    #    The frozen non-uniform noise is fixed for all frames; only the
    #    Poisson and Gaussian samples vary frame to frame.
    # ----------------------------------------------------------
    Im_tensor = torch.full((N_frames, M), float(Im0), dtype=torch.float32, device=device)

    emitter = EmitterData(xy=xy_all, Im=Im_tensor)
    system  = SystemConfig(
        emitter = emitter,
        psf     = psf,
        camera  = camera,
        noise   = noise,
    )

    # ----------------------------------------------------------
    # 3. Generate all N_frames in one batched GPU call
    # ----------------------------------------------------------
    t0 = time.perf_counter()
    with torch.no_grad():
        frames_torch = gauss2d_frame_torch(system)   # (N_frames, Ky, Kx)
    t1 = time.perf_counter()
    frames_np = frames_torch.cpu().numpy().astype(np.float32)
    print(f"  Generated {N_frames} frames in {t1-t0:.3f}s")

    # ----------------------------------------------------------
    # 4. Save multi-page TIFF (uint16)
    # ----------------------------------------------------------
    tif_path = os.path.join(Dataset_folder, f"M={M}_Frames.tif")
    tifffile.imwrite(tif_path, frames_np.astype(np.uint16), photometric='minisblack')
    print(f"  Saved frames    -> {tif_path}")

    # ----------------------------------------------------------
    # 5. Save all emitter locations — (N_frames*M, 2) rows.
    #    Row order: frame 1 emitters (M rows), frame 2, ..., frame N.
    # ----------------------------------------------------------
    xy_np  = xy_all.cpu().numpy().reshape(N_frames * M, 2)  # (N_frames*M, 2)
    xy_path = os.path.join(Dataset_folder, f"M={M}_xy.txt")
    np.savetxt(xy_path, xy_np, fmt="%.6f", header="x_nm  y_nm", comments="")
    print(f"  Saved xy        -> {xy_path}  ({xy_np.shape[0]} rows)")

    # ----------------------------------------------------------
    # 6. Show frame 1 with its emitter locations
    # ----------------------------------------------------------
    fig_path = (
        os.path.join(Dataset_folder, f"M={M}_ShownFigure.tif")
        if save_fig else None
    )
    show_and_save_one_frame(
        frames_np[0],
        xy_all[0].cpu().numpy(),    # (M, 2) for frame 1
        camera,
        save_path=fig_path,
    )


# ============================================================
# Main
# ============================================================

if __name__ == "__main__":
    torch.manual_seed(0)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(0)

    torch.set_float32_matmul_precision('high')
    print("\n=== Generate-Dataset7x7-Random (non-uniform noise) ===")
    print_device_info()

    camera = Camera(Kx=7, Ky=7, Dx=100.0, Dy=100.0, Dt=0.01)
    psf    = Gaussian2DPSF(sigma=108.81)

    N_frames = 1000
    Im0      = 300000.0
    Dataset_folder = "Dataset-Random"

    # One frozen non-uniform noise field for the whole dataset (all M).
    noise = build_frozen_noise(
        camera,
        b_min=4.0, b_max=6.0, corr_px=2.0,
        g_min=2.0, g_max=4.0,
        folder=Dataset_folder,
        seed_b=0, seed_g=1,
    )

    # Noise mean maps for the whole dataset, since the field is shared.
    save_noise_mean_figure(camera, noise, Dataset_folder)

    t_total = time.perf_counter()
    for M in [1, 2, 3, 4, 5]:
        generate_dataset_random(
            M              = M,
            N_frames       = N_frames,
            camera         = camera,
            psf            = psf,
            noise          = noise,
            Dataset_folder = Dataset_folder,
            Im0            = Im0,
            save_fig       = True,
        )
    t_end = time.perf_counter()
    mins, sec = divmod(t_end - t_total, 60)
    print(f"\n[Timing] Total: {int(mins)}m {sec:.1f}s")

    print("\nDataset-Random generation complete.")
    print(f"Output structure:")
    print(f"  {Dataset_folder}/")
    print(f"    b_map.txt               (Ky x Kx background density map)")
    print(f"    G_map.txt               (Ky x Kx readout density map)")
    print(f"    Noise_MeanMaps.tif      (Poisson mean | Gaussian mean, photons)")
    for M in [1, 2, 3, 4, 5]:
        print(f"    M={M}_Frames.tif        (1000 frames, uint16)")
        print(f"    M={M}_xy.txt            ({1000*M} rows, x y in nm)")
        print(f"    M={M}_ShownFigure.tif   (frame 1 with emitters)")