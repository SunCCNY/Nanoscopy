"""
UGIA-Random.py
 
Benchmark the UGIA-F estimator (unbiased, Fisher information of a frame)
on Dataset-Random.  Metric: ARMSMD and ARMSMD-H over N=1000 frames per M.
 
Yi Sun
"""
 
import sys
import os
import time
 
# ----------------------------------------------------------------------
# Console logging: duplicate all stdout to a log file in the Benchmark folder
# ----------------------------------------------------------------------
class _Tee:
    """Write everything printed to the console AND to a log file."""
    def __init__(self, *streams):
        self.streams = streams
    def write(self, data):
        for s in self.streams:
            try:
                s.write(data)
            except UnicodeEncodeError:
                s.write(data.encode("ascii", "replace").decode("ascii"))
            s.flush()
    def flush(self):
        for s in self.streams:
            s.flush()
 
import numpy as np
import torch
import tifffile
import matplotlib.pyplot as plt
import matplotlib.patches as patches
 
ROOT = r"K:\Research_KB"   # <- change to your actual path
sys.path.append(ROOT)
 
from SMLM_Lib import (
    SystemConfig,
    EmitterData,
    Gaussian2DPSF,
    Camera,
    Noise,
    gauss2d_ugia_f_batch_torch,
    gauss2d_em_batch_torch,
    print_device_info,
)
from SMLM_Lib.metrics import rmsmd, rmsmd_h, rmsmd_h_per_frame
from SMLM_Lib.position import sample_emitters_batch
 
 
# ============ configuration ============
N           = 1000
Data_folder = "Dataset-Random"
SEED        = 0     # global RNG seed; UGIA-F draws its Gaussian vector of
                    # Eq. (33) from the default generator, so this fixes the
                    # UGIA-F realisation and makes the run reproducible.
 
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
 
camera = Camera(Kx=7, Ky=7, Dx=100.0, Dy=100.0, Dt=0.01)
Kx, Ky = camera.Kx, camera.Ky
Dx, Dy = camera.Dx, camera.Dy
 
psf = Gaussian2DPSF(sigma=108.81)
 
# Load the frozen non-uniform noise field saved with the dataset, so the FIM
# and UGIA-F consume the identical b_k and G_k that generated the frames.
b_map = torch.tensor(np.loadtxt(os.path.join(Data_folder, "b_map.txt"),
                                dtype=np.float32), device=device)
G_map = torch.tensor(np.loadtxt(os.path.join(Data_folder, "G_map.txt"),
                                dtype=np.float32), device=device)
noise = Noise(b=b_map, mu=G_map, G=G_map)   # mu_k = G_k
 
Im0 = 300000.0   # photons / s
 
 
# ============ helpers ============
 
def load_frames(M):
    path = os.path.join(Data_folder, f"M={M}_Frames.tif")
    arr  = tifffile.imread(path).astype(np.float32)
    return torch.tensor(arr, dtype=torch.float32, device=device)
 
 
def load_xy_all(M):
    path = os.path.join(Data_folder, f"M={M}_xy.txt")
    arr  = np.loadtxt(path, dtype=np.float32, skiprows=1)
    return torch.tensor(arr, dtype=torch.float32, device=device).reshape(N, M, 2)
 
 
def armsmd(D2_sum, n_frames):
    return float(np.sqrt(D2_sum / n_frames))
 
 
def armsmd_h_val(D2h_sum, n_frames):
    return float(np.sqrt(D2h_sum / n_frames))
 
 
def per_frame_rmsmd_h(xy_est_n, xy_true_n, M):
    """Squared RMSMD-H of one frame, i.e. under the Hungarian assignment.
 
    The number of estimates equals the number of emitters here, so the
    correspondence of maximum likelihood is the assignment minimising the
    total squared distance, which is what rmsmd_h evaluates.
    """
    _, D2_n = rmsmd_h(xy_est_n, xy_true_n)
    return D2_n.item()
 
 
def show_frame1(xy_est_n, xy_true_n, label_est, armsmd_val, armsmd_h_value, outfile):
    fig, ax = plt.subplots(figsize=(4, 4))
    ax.imshow(np.zeros((Ky, Kx), dtype=np.float32), cmap="gray", origin="upper")
    ax.set_xlim(-0.5, Kx - 0.5); ax.set_ylim(Ky - 0.5, -0.5)
    ax.set_aspect("equal"); ax.axis("off")
    ax.scatter(xy_est_n[:, 0] / Dx - 0.5, xy_est_n[:, 1] / Dy - 0.5,
               c="white", s=10, zorder=5,
               label=f"{label_est}  ARMSMD-H = {armsmd_h_value:.2f} nm")
    ax.scatter(xy_true_n[:, 0] / Dx - 0.5, xy_true_n[:, 1] / Dy - 0.5,
               c="red", s=10, zorder=5, label="Ground Truth")
    ax.legend(loc="upper left", framealpha=1.0, labelcolor="white",
              frameon=True, edgecolor="white", facecolor="none", fontsize=9)
    os.makedirs(os.path.dirname(outfile) or '.', exist_ok=True)
    fig.savefig(outfile, dpi=150, bbox_inches="tight")
    plt.show(block=False); plt.close(fig)
 
 
# ============ benchmark ============
 
def run_ugia_f():
    print("\n=== UGIA-F Benchmark (Random) ===")
    outdir = "Benchmark-Random/UGIA-F"
    os.makedirs(outdir, exist_ok=True)
    for M in range(1, 6):
        xy_all = load_xy_all(M)
        with torch.no_grad():
            xyF_all = gauss2d_ugia_f_batch_torch(xy_all, Im0, psf, camera, noise, ImType='KI')
        D2_sum = 0.0; D2h_sum = 0.0
        for n in range(N):
            _, D2_n = rmsmd(xyF_all[n], xy_all[n]); D2_sum += D2_n.item()
            D2h_sum += per_frame_rmsmd_h(xyF_all[n], xy_all[n], M)
        armsmd_val = armsmd(D2_sum, N); armsmd_h_value = armsmd_h_val(D2h_sum, N)
        print(f"M={M}  UGIA-F  ARMSMD = {armsmd_val:.2f} nm  ARMSMD-H = {armsmd_h_value:.2f} nm")
        outfile = os.path.join(outdir, f"M={M}_UGIA-F.png")
        show_frame1(xyF_all[0].cpu().numpy(), xy_all[0].cpu().numpy(),
                    "UGIA-F", armsmd_val, armsmd_h_value, outfile)
 
 
# ======================================================================
# Main
# ======================================================================
 
if __name__ == "__main__":
    # ---- start run log (saved in the Benchmark folder) ----
    import atexit
    os.makedirs("Benchmark-Random", exist_ok=True)
    _log_path = os.path.join(
        "Benchmark-Random", f"inference_log_UGIA-F_Random_{time.strftime('%Y%m%d_%H%M%S')}.txt")
    _logf = open(_log_path, "w", encoding="utf-8")
    _orig_stdout = sys.stdout
    while type(_orig_stdout).__name__ == "_Tee":  # unwrap a leftover Tee
        _orig_stdout = _orig_stdout.streams[0]
    sys.stdout = _Tee(_orig_stdout, _logf)
 
    @atexit.register
    def _close_log(_o=_orig_stdout, _f=_logf):
        sys.stdout = _o
        _f.close()
 
    print(f"[Log] Writing run log -> {_log_path}")
    # Seed the global RNG so the UGIA-F Gaussian draw of Eq. (33) is reproducible.
    torch.manual_seed(SEED)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(SEED)
    torch.set_float32_matmul_precision('high')
    print_device_info()
    plt.close('all')
 
    def timed_run(fn, label, **kwargs):
        t0 = time.perf_counter()
        fn(**kwargs)
        t1 = time.perf_counter()
        mins, sec = divmod(t1 - t0, 60)
        print(f"[Timing] {label}: {int(mins)}m {sec:.1f}s")
 
    timed_run(run_ugia_f, "UGIA-F (Random)")
 

