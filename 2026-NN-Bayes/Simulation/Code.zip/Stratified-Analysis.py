"""
Stratified-Analysis.py

Bins the per-frame results written by Stratified-Random.py according to the
minimum emitter separation d_min of each frame and reports the conditional
ARMSMD-H of every estimator within each stratum.

Because all frames come from the emitter distribution the networks were trained
on, training coverage in a stratum is proportional to the size of that stratum,
so coverage is adequate throughout and the only quantity varying across strata
is the overlap severity. Any crossover between the network curves and the
EM-GML curve is therefore attributable to overlap alone.

Within a stratum the ARMSMD-H is

    ARMSMD-H = sqrt( mean_n D2h_n )

with the mean taken over the frames of that stratum, i.e. the squared
distances are averaged and the square root taken once at the end.

Outputs
    Benchmark-Random/Stratified/stratified_M=<M>.csv    table per M
    Benchmark-Random/Stratified/stratified_M=<M>.png    curves per M
    Benchmark-Random/Stratified/crossover_summary.txt   where curves cross

Run Stratified-Random.py first.

Yi Sun
"""

import os
import sys
import math
import numpy as np
import matplotlib.pyplot as plt

OutDir = "Benchmark-Random/Stratified"

ESTIMATORS = ['UGIA-F', 'EM-Near-1', 'EM-GML',
              'APL', 'CNN-APL', 'KAN', 'CNN-KAN', 'ViT']

NETWORKS = ['APL', 'CNN-APL', 'KAN', 'CNN-KAN', 'ViT']

# Stratum edges in nm. The last stratum is open ended and also collects the
# M = 1 frames, whose d_min is undefined and stored as inf.
EDGES = [0.0, 25.0, 50.0, 75.0, 100.0, 150.0, float('inf')]

STYLE = {
    'UGIA-F':   dict(color='k',       ls='--', marker='s', lw=2.0),
    'EM-Near-1':   dict(color='0.55',    ls=':',  marker='v', lw=1.6),
    'EM-GML': dict(color='crimson', ls='-',  marker='o', lw=2.2),
    'APL':      dict(color='tab:blue',   ls='-', marker='^', lw=1.4),
    'CNN-APL':  dict(color='tab:cyan',   ls='-', marker='^', lw=1.4),
    'KAN':      dict(color='tab:green',  ls='-', marker='D', lw=1.4),
    'CNN-KAN':  dict(color='tab:olive',  ls='-', marker='D', lw=1.4),
    'ViT':      dict(color='tab:purple', ls='-', marker='*', lw=1.6),
}


def stratum_labels(edges):
    lab = []
    for i in range(len(edges) - 1):
        lo, hi = edges[i], edges[i + 1]
        lab.append(f"[{lo:.0f},{hi:.0f})" if math.isfinite(hi)
                   else f">={lo:.0f}")
    return lab


def load_perframe(M):
    """Read the per-frame CSV into {column_name: ndarray}.

    Parsed manually rather than with numpy's names=True, which strips
    characters such as '-' from field names and so mangles 'D2h_UGIA-F'.
    """
    path = os.path.join(OutDir, f"M={M}_perframe.csv")
    if not os.path.exists(path):
        return None
    with open(path) as f:
        header = f.readline().strip().split(',')
        rows = [line.strip().split(',') for line in f if line.strip()]
    cols = {}
    for j, name in enumerate(header):
        cols[name] = np.array([float(r[j]) for r in rows], dtype=np.float64)
    return cols


def analyse(M, edges):
    data = load_perframe(M)
    if data is None:
        print(f"M={M}  [skip - {OutDir}/M={M}_perframe.csv not found]")
        return None

    dmin = data['d_min']
    labels = stratum_labels(edges)
    nb = len(labels)

    counts = np.zeros(nb, dtype=int)
    table = {e: np.full(nb, np.nan) for e in ESTIMATORS}

    for b in range(nb):
        lo, hi = edges[b], edges[b + 1]
        sel = (dmin >= lo) & (dmin < hi) if math.isfinite(hi) else (dmin >= lo)
        counts[b] = int(sel.sum())
        if counts[b] == 0:
            continue
        for e in ESTIMATORS:
            col = data[f'D2h_{e}']
            table[e][b] = math.sqrt(float(np.mean(col[sel])))

    # ---- print ------------------------------------------------------
    print(f"\n{'='*88}")
    print(f"M = {M}   ARMSMD-H (nm) by minimum emitter separation d_min")
    print(f"{'='*88}")
    hdr = f"{'estimator':<11}" + ''.join(f"{l:>12}" for l in labels)
    print(hdr)
    print(f"{'n frames':<11}" + ''.join(f"{c:>12d}" for c in counts))
    print('-' * len(hdr))
    for e in ESTIMATORS:
        row = f"{e:<11}"
        for b in range(nb):
            v = table[e][b]
            row += f"{v:>12.2f}" if np.isfinite(v) else f"{'-':>12}"
        print(row)

    # ---- crossovers -------------------------------------------------
    lines = []
    for e in NETWORKS:
        for ref in ['EM-GML', 'UGIA-F']:
            wins = [labels[b] for b in range(nb)
                    if counts[b] > 0 and np.isfinite(table[e][b])
                    and np.isfinite(table[ref][b]) and table[e][b] < table[ref][b]]
            lines.append(f"  M={M}  {e:<8} beats {ref:<9} in strata: "
                         + (", ".join(wins) if wins else "none"))
    print()
    for l in lines:
        print(l)

    # ---- save table -------------------------------------------------
    csv_path = os.path.join(OutDir, f"stratified_M={M}.csv")
    with open(csv_path, 'w') as f:
        print("stratum,n_frames," + ",".join(ESTIMATORS), file=f)
        for b in range(nb):
            vals = ",".join('' if not np.isfinite(table[e][b])
                            else f"{table[e][b]:.6f}" for e in ESTIMATORS)
            print(f"{labels[b]},{counts[b]},{vals}", file=f)
    print(f"\n  Saved -> {csv_path}")

    # ---- plot -------------------------------------------------------
    xs = np.arange(nb)
    fig, ax = plt.subplots(figsize=(7, 4.5))
    for e in ESTIMATORS:
        y = table[e]
        ok = np.isfinite(y)
        if ok.sum() == 0:
            continue
        ax.plot(xs[ok], y[ok], label=e, markersize=5, **STYLE[e])
    ax.set_xticks(xs)
    ax.set_xticklabels(labels)
    ax.set_xlabel(r'minimum emitter separation $d_{\min}$  (nm)')
    ax.set_ylabel('ARMSMD-H  (nm)')
    ax.set_yscale('log')
    ax.set_title(f'Accuracy vs emitter overlap, M = {M}')
    ax.grid(True, which='both', alpha=0.3)
    ax.legend(fontsize=8, ncol=2)
    fig.tight_layout()
    png = os.path.join(OutDir, f"stratified_M={M}.png")
    fig.savefig(png, dpi=200)
    plt.close(fig)
    print(f"  Saved -> {png}")

    return labels, counts, table, lines


# ======================================================================
# Main
# ======================================================================

if __name__ == "__main__":
    print("Stratified analysis of Dataset-Random by minimum emitter separation")
    print(f"strata edges (nm): {EDGES}")

    all_lines = []
    for M in range(1, 6):
        res = analyse(M, EDGES)
        if res is not None:
            all_lines.extend(res[3])

    if all_lines:
        path = os.path.join(OutDir, "crossover_summary.txt")
        with open(path, 'w') as f:
            print("Strata in which each network beats the reference estimator",
                  file=f)
            print(f"strata edges (nm): {EDGES}\n", file=f)
            for l in all_lines:
                print(l, file=f)
        print(f"\nSaved -> {path}")
