"""
Bayes-M2-Validate.py

Validation of the M = 2 pipeline against the Bayes optimum, on frames whose
emitter positions are drawn from exactly the prior used in the quadrature, and
measurement of how closely each estimator approximates the matched Bayes
estimator as a function of the frame.

Dataset Random satisfies the prior matching condition by construction, i.e.
both emitters are drawn independently and uniformly from the central 3x3 pixel
block, which is the region the quadrature integrates over and the region the
networks were trained on. On these frames the matched Bayes estimator theta_B
is the exact minimiser of the expected permutation matched squared error and
RMSMD-P is the Monte Carlo estimate of that expectation, so no estimator may
have a smaller RMSMD-P than theta_B.

Two distinct quantities are reported for every estimator.

  Accuracy      D_P(theta_e, theta), the distance from the true locations,
                which is the quantity reported everywhere else in the study.

  Agreement     D_P(theta_e, theta_B), the distance from the Bayes estimate on
                the same frame. This is the direct measure of whether an
                estimator approximates theta_B as a function of the frame,
                rather than merely attaining a similar average accuracy. An
                estimator may be close in accuracy while being far in
                agreement, i.e. arriving at a similar average error by a
                different route.

If the estimation error of theta_B were orthogonal to every function of the
frame, as it is for the plain squared error loss, the two would satisfy

    D_P^2(theta_e, theta) = D_P^2(theta_e, theta_B) + D_P^2(theta_B, theta) ,

so that the excess risk of an estimator over the Bayes optimum would equal its
squared distance from the Bayes estimate. The minimisation over permutations
in the loss makes the orthogonality approximate rather than exact, so both
sides are reported and their ratio is given as a diagnostic.

The per-frame correlation of the squared errors is also reported. It measures
whether two estimators find the same frames difficult, which is a weaker
statement than agreement since it compares error magnitudes and not locations.

The assignment between estimated and true locations is made by minimising over
the permutations, i.e. by the Hungarian assignment, which is the rule the
matched loss and the matched Bayes estimator are defined by. The partition
algorithm of Sun 2022 assigns greedily and so returns a bijection that is not
always the minimising one, hence a value that is never smaller. Both are
computed and compared, and the Hungarian value is the one reported.

Yi Sun
"""

import sys
import os
import time
import math

import numpy as np
import torch
import tifffile
import matplotlib.pyplot as plt

ROOT = r"K:\Research_KB"   # <- change to your actual path
sys.path.append(ROOT)


# ----------------------------------------------------------------------
# Console logging: duplicate all stdout to a log file in the Benchmark folder
# ----------------------------------------------------------------------
class _Tee:
    """Write everything printed to the console AND to a log file."""
    def __init__(self, *streams):
        self.streams = streams
    def write(self, data):
        for s in self.streams:
            try:
                s.write(data)
            except UnicodeEncodeError:
                s.write(data.encode("ascii", "replace").decode("ascii"))
            s.flush()
    def flush(self):
        for s in self.streams:
            s.flush()


from SMLM_Lib import (
    SystemConfig,
    EmitterData,
    Gaussian2DPSF,
    Camera,
    Noise,
    gauss2d_ugia_f_batch_torch,
    gauss2d_em_batch_torch,
    print_device_info,
)
from SMLM_Lib.Gauss2D import Qfunc_torch, gauss2d_loglike_batch_torch
from SMLM_Lib.metrics import partition_x, rmsmd_p, rmsmd_h_per_frame
from SMLM_Lib.APL import APLLocalizer, CNNAPLLocalizer
from SMLM_Lib.KAN import KANLocalizer, CNNKANLocalizer
from SMLM_Lib.ViT import ViTLocalizer


# ============ configuration ============
M           = 2
N           = 1000
Data_folder = "Dataset-Random"
OutDir      = "Benchmark-Random/Bayes-M2"

GRID_STEP  = 5.0        # nm; quadrature bias falls as GRID_STEP^2
A_CHUNK    = 32
N_LLOYD    = 30
N_RESTART  = 4

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

camera = Camera(Kx=7, Ky=7, Dx=100.0, Dy=100.0, Dt=0.01)
Kx, Ky = camera.Kx, camera.Ky
Dx, Dy, Dt = camera.Dx, camera.Dy, camera.Dt
DxDyDt = Dx * Dy * Dt

psf   = Gaussian2DPSF(sigma=108.81)
sigma = psf.sigma

b_map = torch.tensor(np.loadtxt(os.path.join(Data_folder, "b_map.txt"),
                                dtype=np.float32), device=device)
G_map = torch.tensor(np.loadtxt(os.path.join(Data_folder, "G_map.txt"),
                                dtype=np.float32), device=device)
noise = Noise(b=b_map, mu=G_map, G=G_map)

Im0 = 300000.0

MARGIN_PX = 2
LO = MARGIN_PX * Dx
HI = (Kx - MARGIN_PX) * Dx

NEAR_HALF_NEAR = 10.0
NEAR_HALF_WIDE = 100.0
K_EM           = 250

# Number of starts evaluated in one call. The batch presented to the
# graphics processor is BATCH_STARTS times the number of frames, so a
# larger value uses the device more fully at the cost of more memory.
# The result does not depend on it.
BATCH_STARTS   = 5
N_ITER         = 300
GN             = 'N'
SEED           = 0

NET_FOLDERS = {
    'APL':     ("APL-Trained",     "apl_localizer_M={}.pth"),
    'CNN-APL': ("CNN-APL-Trained", "cnnapl_localizer_M={}.pth"),
    'KAN':     ("KAN-Trained",     "kan_localizer_M={}.pth"),
    'CNN-KAN': ("CNN-KAN-Trained", "cnnkan_localizer_M={}.pth"),
    'ViT':     ("ViT-Trained",     "vit_localizer_M={}.pth"),
}
NETWORKS   = ['APL', 'CNN-APL', 'KAN', 'CNN-KAN', 'ViT']
OTHERS     = ['UGIA-F', 'EM-GML', 'MMSE'] + NETWORKS
ESTIMATORS = ['Bayes-M'] + OTHERS


# ============ quadrature ============

def build_grid():
    g = torch.arange(LO, HI + 1e-6, GRID_STEP, dtype=torch.float32, device=device)
    G = g.numel()
    kx = torch.arange(Kx, dtype=torch.float32, device=device).view(1, Kx)
    ky = torch.arange(Ky, dtype=torch.float32, device=device).view(1, Ky)
    gx = g.view(G, 1)
    qx = (Qfunc_torch(-(Dx * (kx + 1) - gx) / sigma)
          - Qfunc_torch(-(Dx * kx - gx) / sigma))
    qy = (Qfunc_torch(-(Dy * (ky + 1) - gx) / sigma)
          - Qfunc_torch(-(Dy * ky - gx) / sigma))
    q = qy.view(G, 1, Ky, 1) * qx.view(1, G, 1, Kx)
    sig_map = (Dt * Im0 * q).reshape(G * G, Ky * Kx).contiguous()
    X = g.view(1, G).expand(G, G).reshape(-1)
    Y = g.view(G, 1).expand(G, G).reshape(-1)
    pos = torch.stack([X, Y], dim=1).contiguous()
    return pos, sig_map, G


def log_posterior_pairs(U_corr, sig_map, bg):
    S = sig_map.shape[0]
    out = torch.empty(S, S, device=device, dtype=torch.float32)
    for a0 in range(0, S, A_CHUNK):
        a1 = min(a0 + A_CHUNK, S)
        w = sig_map[a0:a1].unsqueeze(1) + sig_map.unsqueeze(0) + bg
        w = torch.clamp(w, min=1e-12)
        out[a0:a1] = (U_corr * torch.log(w) - w).sum(dim=-1)
    return out


def bayes_estimates(logP, pos, gen):
    S = pos.shape[0]
    flat = logP.reshape(-1)
    P = torch.softmax(flat, dim=0).reshape(S, S)

    Pa = P.sum(dim=1)
    Pb = P.sum(dim=0)
    m1 = (Pa.unsqueeze(1) * pos).sum(dim=0)
    m2 = (Pb.unsqueeze(1) * pos).sum(dim=0)
    xy_mmse = torch.stack([m1, m2], dim=0)

    def objective(y1, y2):
        d1 = ((pos - y1) ** 2).sum(1)
        d2 = ((pos - y2) ** 2).sum(1)
        c_id = d1.unsqueeze(1) + d2.unsqueeze(0)
        c_sw = d2.unsqueeze(1) + d1.unsqueeze(0)
        return (P * torch.minimum(c_id, c_sw)).sum()

    def lloyd(y1, y2):
        for _ in range(N_LLOYD):
            d1 = ((pos - y1) ** 2).sum(1)
            d2 = ((pos - y2) ** 2).sum(1)
            ident = (d1.unsqueeze(1) + d2.unsqueeze(0)) <= (d2.unsqueeze(1) + d1.unsqueeze(0))
            Pi = P * ident
            Ps = P - Pi
            w1a, w1b = Pi.sum(dim=1), Ps.sum(dim=0)
            w2b, w2a = Pi.sum(dim=0), Ps.sum(dim=1)
            t1 = w1a.sum() + w1b.sum()
            t2 = w2b.sum() + w2a.sum()
            y1n = ((w1a.unsqueeze(1) * pos).sum(0)
                   + (w1b.unsqueeze(1) * pos).sum(0)) / torch.clamp(t1, min=1e-12)
            y2n = ((w2b.unsqueeze(1) * pos).sum(0)
                   + (w2a.unsqueeze(1) * pos).sum(0)) / torch.clamp(t2, min=1e-12)
            done = torch.allclose(y1n, y1, atol=1e-4) and torch.allclose(y2n, y2, atol=1e-4)
            y1, y2 = y1n, y2n
            if done:
                break
        return y1, y2

    idx = int(torch.argmax(flat).item())
    starts = [(pos[idx // S].clone(), pos[idx % S].clone())]
    for _ in range(N_RESTART):
        ia = int(torch.randint(0, S, (1,), device=device, generator=gen).item())
        ib = int(torch.randint(0, S, (1,), device=device, generator=gen).item())
        starts.append((pos[ia].clone(), pos[ib].clone()))

    best, best_obj = None, None
    for y1, y2 in starts:
        y1, y2 = lloyd(y1, y2)
        o = objective(y1, y2)
        if best_obj is None or o < best_obj:
            best_obj, best = o, (y1, y2)
    return xy_mmse, torch.stack([best[0], best[1]], dim=0)


# ============ helpers ============

def load_frames():
    path = os.path.join(Data_folder, f"M={M}_Frames.tif")
    arr  = tifffile.imread(path).astype(np.float32)
    return torch.tensor(arr, dtype=torch.float32, device=device)


def load_xy_all():
    path = os.path.join(Data_folder, f"M={M}_xy.txt")
    arr  = np.loadtxt(path, dtype=np.float32, skiprows=1)
    return torch.tensor(arr, dtype=torch.float32, device=device).reshape(N, M, 2)


def load_net(name):
    folder, pat = NET_FOLDERS[name]
    cls = {'APL': APLLocalizer, 'CNN-APL': CNNAPLLocalizer,
           'KAN': KANLocalizer, 'CNN-KAN': CNNKANLocalizer,
           'ViT': ViTLocalizer}[name]
    model = cls(Kx=Kx, Ky=Ky, M=M).to(device)
    model.load_state_dict(
        torch.load(os.path.join(folder, pat.format(M)), map_location=device))
    model.eval()
    return model


def prepare_input(frames):
    x = frames.view(frames.shape[0], -1)
    return x / (x.amax(dim=1, keepdim=True) + 1e-8)


def per_frame_D2_hungarian(xy_est, xy_ref):
    """(N,) squared RMSMD-H per frame, i.e. Eq. (34).

    This is the quantity the matched Bayes estimator minimises and the quantity
    the Hungarian training loss evaluates. Computed by SMLM_Lib.metrics.
    """
    _, D2 = rmsmd_h_per_frame(xy_est, xy_ref)
    return D2.cpu().numpy().astype(np.float64)


def per_frame_D2_partition(xy_est, xy_ref):
    """(N,) squared RMSMD-P per frame, via the partition algorithm of Sun 2022.

    The partition assigns estimates to true locations greedily, i.e. it
    repeatedly takes the globally smallest distance and removes that estimate
    and, once its quota is filled, that emitter. For the case treated here the
    quota is one estimate per emitter, so the assignment is a bijection,
    whereas a greedy bijection is not always the minimising one. The value is
    therefore not smaller than the Hungarian value of Eq. (34) and is computed
    only so that the two can be compared.
    """
    Kai = torch.ones(M, dtype=torch.long)
    est, ref = xy_est.cpu(), xy_ref.cpu()
    out = np.empty(est.shape[0], dtype=np.float64)
    for n in range(est.shape[0]):
        Xp, Ki, _ = partition_x(ref[n], est[n], Kai)
        _, D2p_n  = rmsmd_p(ref[n], Xp, Ki)
        out[n] = D2p_n.item()
    return out


def armsmd_p(D2):
    return float(np.sqrt(np.mean(D2)))


# ============ main ============

def run():
    os.makedirs(OutDir, exist_ok=True)
    gen = torch.Generator(device=device).manual_seed(SEED)

    pos, sig_map, G = build_grid()
    S = pos.shape[0]
    print(f"Quadrature grid: step {GRID_STEP:.1f} nm, {G} points per axis, "
          f"{S} single-emitter positions, {S*S:,} ordered pairs per frame.")
    print(f"Grid quantisation standard deviation = {GRID_STEP/math.sqrt(12):.2f} nm.")
    print(f"Frames: {N} from {Data_folder}, prior matched to the quadrature.\n")

    frames  = load_frames()
    xy_true = load_xy_all()

    sep = (xy_true[:, 0] - xy_true[:, 1]).norm(dim=1)
    print(f"True separation over the {N} frames: mean {sep.mean():.1f} nm, "
          f"median {sep.median():.1f} nm, min {sep.min():.1f} nm, "
          f"max {sep.max():.1f} nm\n")

    bg   = (DxDyDt * (noise.b + noise.G)).reshape(-1)
    corr = (DxDyDt * (noise.G - noise.mu)).reshape(-1)

    Im_tensor = torch.full((1, M), Im0, dtype=torch.float32, device=device)
    emitter = EmitterData(xy=xy_true[0:1], Im=Im_tensor)
    system  = SystemConfig(emitter=emitter, psf=psf, camera=camera, noise=noise)

    est_xy = {}        # estimated locations of every estimator
    D2p    = {}        # squared matched distance against the true locations
    D2part = {}        # the same under the greedy partition, for comparison

    # ---- quadrature Bayes estimators --------------------------------
    t0 = time.perf_counter()
    xy_mmse = torch.empty(N, M, 2, device=device)
    xy_bay  = torch.empty(N, M, 2, device=device)
    max_split = 0.0
    for n in range(N):
        U_corr = torch.clamp(frames[n].reshape(-1) + corr, min=0.0)
        logP = log_posterior_pairs(U_corr, sig_map, bg)
        e_mmse, e_bay = bayes_estimates(logP, pos, gen)
        xy_mmse[n], xy_bay[n] = e_mmse, e_bay
        max_split = max(max_split,
                        float((e_mmse[0] - e_mmse[1]).norm().item()))
        if (n + 1) % 100 == 0:
            print(f"  quadrature {n+1}/{N} frames "
                  f"[{time.perf_counter()-t0:.0f}s]")
    est_xy['MMSE'], est_xy['Bayes-M'] = xy_mmse, xy_bay
    print(f"  quadrature done [{time.perf_counter()-t0:.0f}s]")
    print(f"  max separation of the two MMSE estimates over all frames "
          f"= {max_split:.3e} nm, i.e. degenerate as predicted\n")

    # ---- UGIA-F ------------------------------------------------------
    with torch.no_grad():
        est_xy['UGIA-F'] = gauss2d_ugia_f_batch_torch(
            xy_true, Im0, psf, camera, noise, ImType='KI')

    # ---- EM-GML ------------------------------------------------------
    t0 = time.perf_counter()
    xyi = xy_true + NEAR_HALF_NEAR * (
        2 * torch.rand(N, M, 2, device=device, generator=gen) - 1)
    with torch.no_grad():
        xy_b = gauss2d_em_batch_torch(frames, xyi, system, GN=GN, n_iter=N_ITER)
        ll_b = gauss2d_loglike_batch_torch(frames, xy_b, system)
    # The K starts are evaluated BATCH_STARTS at a time. Stacking the
    # starts along the batch dimension presents the graphics processor
    # with S * N frames per call instead of N, which is much faster for
    # frames of this size, and leaves the result unchanged since the
    # starts are independent and the selection is a maximum over them.
    done = 0
    while done < K_EM:
        S = min(BATCH_STARTS, K_EM - done)
        jitter = NEAR_HALF_WIDE * (
            2 * torch.rand(S, N, M, 2, device=device, generator=gen) - 1)
        xyi_s = (xy_true.unsqueeze(0) + jitter).reshape(S * N, M, 2)
        frames_rep = frames.repeat(S, 1, 1)
        with torch.no_grad():
            xy_s = gauss2d_em_batch_torch(frames_rep, xyi_s, system,
                                          GN=GN, n_iter=N_ITER)
            ll_s = gauss2d_loglike_batch_torch(frames_rep, xy_s, system)
        ll_s = ll_s.reshape(S, N)
        xy_s = xy_s.reshape(S, N, M, 2)
        ll_max, idx = ll_s.max(dim=0)
        xy_max = xy_s[idx, torch.arange(N, device=device)]
        better = ll_max > ll_b
        ll_b = torch.where(better, ll_max, ll_b)
        xy_b = torch.where(better.view(N, 1, 1), xy_max, xy_b)
        done += S
    est_xy['EM-GML'] = xy_b
    print(f"  EM-GML done, K={K_EM} [{time.perf_counter()-t0:.0f}s]")

    # ---- networks ----------------------------------------------------
    x_in = prepare_input(frames)
    for name in NETWORKS:
        model = load_net(name)
        with torch.no_grad():
            est_xy[name] = model(x_in).view(N, M, 2)
        del model

    # ---- accuracy against the true locations -------------------------
    for e in ESTIMATORS:
        D2p[e]    = per_frame_D2_hungarian(est_xy[e], xy_true)
        D2part[e] = per_frame_D2_partition(est_xy[e], xy_true)

    # ---- agreement with the Bayes estimate ---------------------------
    D2b = {e: per_frame_D2_hungarian(est_xy[e], est_xy['Bayes-M'])
           for e in OTHERS}

    # ---- the two assignment rules compared ---------------------------
    print(f"{'='*78}")
    print("Assignment rule, Hungarian of Eq. (34) against the greedy partition")
    print("The partition is a bijection here but a greedy one, so it is never")
    print("smaller than the Hungarian value. Both are reported so the size of")
    print("the difference is on record. The Hungarian value is used throughout.")
    print(f"{'='*78}")
    hdr = (f"{'estimator':<10}{'Hungarian':>11}{'partition':>11}"
           f"{'excess %':>10}{'frames differ':>15}{'max excess':>12}")
    print(hdr)
    print('-' * len(hdr))
    for e in ESTIMATORS:
        h, g = D2p[e], D2part[e]
        ndiff = int(np.sum(g > h + 1e-6))
        print(f"{e:<10}{armsmd_p(h):>11.3f}{armsmd_p(g):>11.3f}"
              f"{100*(armsmd_p(g)/armsmd_p(h)-1):>10.3f}"
              f"{ndiff:>10} /{N:<4}{np.max(g-h):>12.2f}")
    print()

    # ---- table 1, accuracy -------------------------------------------
    print(f"{'='*74}")
    print(f"ARMSMD-P (nm), M = 2, {N} frames drawn from the quadrature prior")
    print(f"{'='*74}")
    for e in sorted(ESTIMATORS, key=lambda e: armsmd_p(D2p[e])):
        mark = "   <-- Bayes optimum" if e == 'Bayes-M' else ""
        print(f"  {e:<10} {armsmd_p(D2p[e]):8.3f}{mark}")

    # ---- table 2, agreement with the Bayes estimator ------------------
    a_bayes = armsmd_p(D2p['Bayes-M'])
    mean_bayes = float(np.mean(D2p['Bayes-M']))
    print(f"\n{'='*96}")
    print("Agreement with the matched Bayes estimator, on the same frames")
    print("accuracy = distance from the true locations, "
          "agreement = distance from the Bayes estimate")
    print(f"{'='*96}")
    hdr = (f"{'estimator':<10}{'accuracy':>10}{'agreement':>11}"
           f"{'agree/acc':>11}{'Pythag lhs':>12}{'Pythag rhs':>12}{'ratio':>8}")
    print(hdr)
    print('-' * len(hdr))
    rows2 = []
    for e in OTHERS:
        acc = armsmd_p(D2p[e])
        agr = armsmd_p(D2b[e])
        lhs = float(np.mean(D2p[e]))
        rhs = float(np.mean(D2b[e])) + mean_bayes
        rows2.append((e, acc, agr, agr / acc, lhs, rhs, lhs / rhs))
        print(f"{e:<10}{acc:>10.3f}{agr:>11.3f}{agr/acc:>11.3f}"
              f"{lhs:>12.1f}{rhs:>12.1f}{lhs/rhs:>8.3f}")
    print()
    print(f"  Bayes optimum accuracy = {a_bayes:.3f} nm, "
          f"mean squared value = {mean_bayes:.1f} nm^2")
    print("  The Pythagorean columns test whether the excess risk of an estimator")
    print("  equals its squared distance from the Bayes estimate, i.e. whether")
    print("  lhs = mean D_P^2(e, truth) equals rhs = mean D_P^2(e, Bayes) plus")
    print("  mean D_P^2(Bayes, truth). A ratio near one supports the reading of")
    print("  the excess risk as pure approximation error.")

    # ---- table 3, paired comparison and error correlation --------------
    base = D2p['Bayes-M']
    print(f"\n{'='*94}")
    print("Paired comparison of accuracy against the Bayes optimum")
    print("Delta_n = D2p_estimator(n) - D2p_Bayes(n); Delta > 0 means Bayes-M is better")
    print("corr is the correlation of the per-frame squared errors, i.e. whether the")
    print("two estimators find the same frames difficult, which is weaker than agreement")
    print(f"{'='*94}")
    hdr = (f"{'estimator':<10}{'accuracy':>10}{'mean Delta':>13}{'SE':>10}"
           f"{'t':>9}{'corr':>8}{'verdict':>16}")
    print(hdr)
    print('-' * len(hdr))
    rows = []
    violations = []
    for e in OTHERS:
        delta = D2p[e] - base
        md = float(np.mean(delta))
        se = float(np.std(delta, ddof=1) / math.sqrt(N))
        t  = md / se if se > 0 else float('inf')
        r  = float(np.corrcoef(D2p[e], base)[0, 1])
        if md > 0 and t > 3:
            verdict = "Bayes better"
        elif md < 0 and t < -3:
            verdict = "VIOLATION"
            violations.append(e)
        else:
            verdict = "indistinguishable"
        rows.append((e, armsmd_p(D2p[e]), md, se, t, r, verdict))
        print(f"{e:<10}{armsmd_p(D2p[e]):>10.3f}{md:>13.2f}{se:>10.2f}"
              f"{t:>9.2f}{r:>8.3f}{verdict:>16}")

    print()
    if not violations:
        print("PASS: no estimator is significantly below the Bayes optimum.")
    else:
        print("FAIL: the following are significantly below the Bayes optimum, "
              "which indicates an error rather than a result:")
        for e in violations:
            print(f"        {e}")

    # ---- save ---------------------------------------------------------
    csv_path = os.path.join(OutDir, "validate_m2.csv")
    with open(csv_path, "w") as f:
        print("estimator,accuracy_nm,agreement_nm,agree_over_acc,"
              "pythag_lhs,pythag_rhs,pythag_ratio,"
              "mean_delta_nm2,se_nm2,t_stat,corr,verdict", file=f)
        print(f"Bayes-M,{a_bayes:.6f},0,0,"
              f"{mean_bayes:.6f},{mean_bayes:.6f},1,0,0,0,1,reference", file=f)
        for (e, acc, agr, ra, lhs, rhs, pr), (_, _, md, se, t, r, v) in zip(rows2, rows):
            print(f"{e},{acc:.6f},{agr:.6f},{ra:.6f},{lhs:.6f},{rhs:.6f},"
                  f"{pr:.6f},{md:.6f},{se:.6f},{t:.6f},{r:.6f},{v}", file=f)
    print(f"\nSaved -> {csv_path}")

    pf_path = os.path.join(OutDir, "validate_m2_perframe.csv")
    with open(pf_path, "w") as f:
        cols = ([f"D2p_{e}" for e in ESTIMATORS]
                + [f"D2bayes_{e}" for e in OTHERS])
        print("frame,separation_nm," + ",".join(cols), file=f)
        s = sep.cpu().numpy()
        for n in range(N):
            vals = ([f"{D2p[e][n]:.6f}" for e in ESTIMATORS]
                    + [f"{D2b[e][n]:.6f}" for e in OTHERS])
            print(f"{n},{s[n]:.6f}," + ",".join(vals), file=f)
    print(f"Saved -> {pf_path}")

    xy_path = os.path.join(OutDir, "validate_m2_positions.csv")
    with open(xy_path, "w") as f:
        cols = ["true"] + ESTIMATORS
        hdr = "frame," + ",".join(
            f"{c}_x{m+1},{c}_y{m+1}" for c in cols for m in range(M))
        print(hdr, file=f)
        arrs = {'true': xy_true.cpu().numpy()}
        for e in ESTIMATORS:
            arrs[e] = est_xy[e].cpu().numpy()
        for n in range(N):
            vals = []
            for c in cols:
                for m in range(M):
                    vals.append(f"{arrs[c][n, m, 0]:.4f}")
                    vals.append(f"{arrs[c][n, m, 1]:.4f}")
            print(f"{n}," + ",".join(vals), file=f)
    print(f"Saved -> {xy_path}")

    # ---- plot, accuracy against agreement ------------------------------
    fig, ax = plt.subplots(figsize=(6.6, 4.8))
    for e, acc, agr, _, _, _, _ in rows2:
        ax.scatter(agr, acc, s=60)
        ax.annotate(e, (agr, acc), textcoords="offset points",
                    xytext=(6, 4), fontsize=9)
    ax.axhline(a_bayes, ls='--', color='crimson', lw=1.5,
               label=f'Bayes optimum, {a_bayes:.2f} nm')
    ax.set_xlabel(r'agreement, $\overline{D}_\mathrm{P}$ from the Bayes estimate (nm)')
    ax.set_ylabel(r'accuracy, $\overline{D}_\mathrm{P}$ from the true locations (nm)')
    ax.set_title(f'Accuracy and agreement with the Bayes estimator, M = {M}')
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=9)
    fig.tight_layout()
    png = os.path.join(OutDir, "validate_m2_agreement.png")
    fig.savefig(png, dpi=200)
    plt.close(fig)
    print(f"Saved -> {png}")


if __name__ == "__main__":
    import atexit
    os.makedirs("Benchmark-Random", exist_ok=True)
    _log_path = os.path.join(
        "Benchmark-Random",
        f"inference_log_Bayes-M2-Validate_{time.strftime('%Y%m%d_%H%M%S')}.txt")
    _logf = open(_log_path, "w", encoding="utf-8")
    _orig_stdout = sys.stdout
    while type(_orig_stdout).__name__ == "_Tee":
        _orig_stdout = _orig_stdout.streams[0]
    sys.stdout = _Tee(_orig_stdout, _logf)

    @atexit.register
    def _close_log(_o=_orig_stdout, _f=_logf):
        sys.stdout = _o
        _f.close()

    print(f"[Log] Writing run log -> {_log_path}")

    # UGIA-F draws its Gaussian vector g of Eq. (33) from the global generator,
    # so the global seed must be fixed for the run to be reproducible.
    torch.manual_seed(SEED)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(SEED)

    torch.set_float32_matmul_precision('high')
    print_device_info()
    plt.close('all')

    t0 = time.perf_counter()
    run()
    mins, sec = divmod(time.perf_counter() - t0, 60)
    print(f"\n[Timing] Bayes-M2-Validate: {int(mins)}m {sec:.1f}s")
