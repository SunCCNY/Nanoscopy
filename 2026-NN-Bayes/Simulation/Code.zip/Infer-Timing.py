"""
Infer-Timing.py

Measure the inference time of the five trained networks, i.e. the cost of the
single forward pass that maps a frame to the M estimated positions, and, for a
direct comparison, the per-frame time of the multi-start EM that realizes the
EM-GML benchmark. This is the quantity behind the claim that a trained network
estimates far faster than the iterative EM of EM-GML, so it must be measured
properly rather than read off a saturated benchmark timer.

Why a dedicated script
----------------------
A forward pass on a 7 x 7 frame is far below the resolution of a wall-clock
timer wrapped around one call, and a GPU call is asynchronous, so a CPU timer
can return before the device has finished. This script therefore

  * runs a warm-up and discards it, so one-time CUDA context creation, cuDNN
    autotuning and lazy initialization are not counted,
  * calls torch.cuda.synchronize() immediately before and after every timed
    region, so the measured interval is the real device time, and
  * repeats each measurement many times and reports the mean and the standard
    deviation.

Network timing, two regimes
---------------------------
  * Latency, at batch size 1, i.e. the time to estimate one frame on its own,
    which is the real-time per-frame number.
  * Throughput, at a large batch, i.e. the frames processed per second when the
    device is kept busy, which is the number that matters for a high-throughput
    pipeline, since a graphics processor is far more efficient on a large batch
    than on one small frame at a time.

The network timing is of the forward pass alone. It excludes the host-to-device
copy, the frame normalization, which is a single reduction, and the metric
computation, none of which is part of the estimator's arithmetic. The result
depends only on the network, the batch size and the device, not on the frame
content, so random inputs of the correct shape are used and no dataset is
required for this part.

EM-GML timing
-------------
The EM-GML per-frame time is measured by running the same multi-start EM used
to produce the reported benchmark, i.e. K wide starts of a fixed number of EM
iterations with the highest-log-likelihood point kept, on a block of real
Dataset-Random frames, and dividing the total device time by the number of
frames. This is the amortized per-frame cost under the same batching the
benchmark uses, so it is directly comparable to the network's amortized
per-frame time. The Dataset-Random frames and the frozen noise maps are
therefore required for this part.

Outputs
    Benchmark-Random/Timing/inference_timing.csv        network timing
    Benchmark-Random/Timing/inference_timing_em.csv     EM-GML timing
    Benchmark-Random/Timing/inference_timing_log_<timestamp>.txt

Yi Sun
"""

import sys
import os
import time
import numpy as np
import torch

ROOT = r"K:\Research_KB"   # <- change to your actual path
sys.path.append(ROOT)


# ----------------------------------------------------------------------
# Console logging: duplicate all stdout to a log file
# ----------------------------------------------------------------------
class _Tee:
    """Write everything printed to the console AND to a log file."""
    def __init__(self, *streams):
        self.streams = streams
    def write(self, data):
        for s in self.streams:
            try:
                s.write(data)
            except UnicodeEncodeError:
                s.write(data.encode("ascii", "replace").decode("ascii"))
            s.flush()
    def flush(self):
        for s in self.streams:
            s.flush()


from SMLM_Lib import (Camera, Gaussian2DPSF, Noise, EmitterData, SystemConfig,
                      gauss2d_em_batch_torch, print_device_info)
from SMLM_Lib.Gauss2D import gauss2d_loglike_batch_torch
from SMLM_Lib.APL import APLLocalizer, CNNAPLLocalizer
from SMLM_Lib.KAN import KANLocalizer, CNNKANLocalizer
from SMLM_Lib.ViT import ViTLocalizer
import tifffile


# ============ configuration ============
OutDir = "Benchmark-Random/Timing"

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

camera = Camera(Kx=7, Ky=7, Dx=100.0, Dy=100.0, Dt=0.01)
Kx, Ky = camera.Kx, camera.Ky
D_IN = Kx * Ky                      # flattened frame length fed to the networks

Ms = [1, 2, 3, 4, 5]
SEED = 0

# ---- network timing ----
TIME_NETS = True
# Batch sizes to time. Batch 1 gives the single-frame latency, the large
# batches give the throughput. Add or remove sizes freely.
BATCH_SIZES = [1, 64, 1024, 10000]
WARMUP  = 50       # forward passes run and discarded before timing
REPEATS = 100      # timed forward passes per (network, M, batch size)

NET_FOLDERS = {
    'APL':     ("APL-Trained",     "apl_localizer_M={}.pth",    APLLocalizer),
    'CNN-APL': ("CNN-APL-Trained", "cnnapl_localizer_M={}.pth", CNNAPLLocalizer),
    'KAN':     ("KAN-Trained",     "kan_localizer_M={}.pth",    KANLocalizer),
    'CNN-KAN': ("CNN-KAN-Trained", "cnnkan_localizer_M={}.pth", CNNKANLocalizer),
    'ViT':     ("ViT-Trained",     "vit_localizer_M={}.pth",    ViTLocalizer),
}
NAMES = ['APL', 'CNN-APL', 'KAN', 'CNN-KAN', 'ViT']

# ---- EM-GML timing (the multi-start EM that realizes the EM-GML benchmark) ----
TIME_EM     = True
Data_folder = "Dataset-Random"
EM_M_LIST   = [1, 2, 3, 4, 5]
EM_N_TIME   = 100         # frames used to measure the per-frame time
EM_REPEATS  = 3
EM_K              = 250   # starts, as in the reported EM-GML
EM_N_ITER         = 300   # EM iterations per start
EM_BATCH_STARTS   = 5     # starts evaluated per call (device utilization only)
EM_NEAR_HALF_WIDE = 100.0 # half-width of the uniform start jitter, nm
EM_GN = 'N'
Im0   = 300000.0          # photons / s per emitter

psf = Gaussian2DPSF(sigma=108.81)


# ============ network helpers ============

def load_net(name, M):
    folder, pat, cls = NET_FOLDERS[name]
    model = cls(Kx=Kx, Ky=Ky, M=M).to(device)
    model.load_state_dict(
        torch.load(os.path.join(folder, pat.format(M)), map_location=device))
    model.eval()
    return model


def time_forward(model, x):
    """Return an array of REPEATS per-batch forward-pass times in seconds.

    A warm-up is run and discarded, then every timed region is bracketed by a
    device synchronization so the interval is the real device time and not an
    early return of an asynchronous call.
    """
    use_cuda = (device.type == "cuda")
    with torch.no_grad():
        for _ in range(WARMUP):
            model(x)
        if use_cuda:
            torch.cuda.synchronize()
        times = np.empty(REPEATS, dtype=np.float64)
        for r in range(REPEATS):
            if use_cuda:
                torch.cuda.synchronize()
            t0 = time.perf_counter()
            model(x)
            if use_cuda:
                torch.cuda.synchronize()
            times[r] = time.perf_counter() - t0
    return times


# ============ EM-GML helpers ============

def _load_frames_M(M, n):
    arr = tifffile.imread(
        os.path.join(Data_folder, f"M={M}_Frames.tif")).astype(np.float32)
    return torch.tensor(arr[:n], dtype=torch.float32, device=device)


def _load_xy_M(M, n):
    arr = np.loadtxt(os.path.join(Data_folder, f"M={M}_xy.txt"),
                     dtype=np.float32, skiprows=1).reshape(-1, M, 2)
    return torch.tensor(arr[:n], dtype=torch.float32, device=device)


def _multistart_em(frames_all, xy_all, system, M, K, gen):
    """One EM-GML estimate over all frames, i.e. K wide starts of EM_N_ITER
    iterations with the highest-log-likelihood point kept, exactly as the
    reported EM-GML. The K starts are evaluated EM_BATCH_STARTS at a time."""
    N = frames_all.shape[0]
    best_ll = torch.full((N,), float('-inf'), device=device)
    best_xy = torch.zeros(N, M, 2, device=device)
    done = 0
    while done < K:
        S = min(EM_BATCH_STARTS, K - done)
        jitter = EM_NEAR_HALF_WIDE * (
            2 * torch.rand(S, N, M, 2, device=device, generator=gen) - 1)
        xyi_s = (xy_all.unsqueeze(0) + jitter).reshape(S * N, M, 2)
        frames_rep = frames_all.repeat(S, 1, 1)
        with torch.no_grad():
            xy_s = gauss2d_em_batch_torch(frames_rep, xyi_s, system,
                                          GN=EM_GN, n_iter=EM_N_ITER)
            ll_s = gauss2d_loglike_batch_torch(frames_rep, xy_s, system)
        ll_s = ll_s.reshape(S, N)
        xy_s = xy_s.reshape(S, N, M, 2)
        ll_max, idx = ll_s.max(dim=0)
        xy_max = xy_s[idx, torch.arange(N, device=device)]
        better = ll_max > best_ll
        best_ll = torch.where(better, ll_max, best_ll)
        best_xy = torch.where(better.view(N, 1, 1), xy_max, best_xy)
        done += S
    return best_xy


def time_em_gml(M, noise):
    """Return an array of EM_REPEATS per-frame EM-GML times in seconds."""
    frames_all = _load_frames_M(M, EM_N_TIME)
    xy_all     = _load_xy_M(M, EM_N_TIME)
    N = frames_all.shape[0]

    Im_t = torch.full((1, M), Im0, dtype=torch.float32, device=device)
    emitter = EmitterData(xy=xy_all[0:1], Im=Im_t)
    system  = SystemConfig(emitter=emitter, psf=psf, camera=camera, noise=noise)

    use_cuda = (device.type == "cuda")
    # warm-up: one batch of starts, discarded
    gen = torch.Generator(device=device).manual_seed(SEED)
    _ = _multistart_em(frames_all, xy_all, system, M, EM_BATCH_STARTS, gen)
    if use_cuda:
        torch.cuda.synchronize()

    times = np.empty(EM_REPEATS, dtype=np.float64)
    for r in range(EM_REPEATS):
        gen = torch.Generator(device=device).manual_seed(SEED + r)
        if use_cuda:
            torch.cuda.synchronize()
        t0 = time.perf_counter()
        _ = _multistart_em(frames_all, xy_all, system, M, EM_K, gen)
        if use_cuda:
            torch.cuda.synchronize()
        times[r] = time.perf_counter() - t0
    return times / N                       # seconds per frame


def _best_net_us(net_rows, name, M):
    """Smallest amortized per-frame time (us) of a network at a saturating
    batch, used for the speedup comparison against EM-GML."""
    cands = [r for r in net_rows if r['network'] == name and r['M'] == M
             and r['batch_size'] >= 1024]
    if not cands:
        cands = [r for r in net_rows if r['network'] == name and r['M'] == M]
    if not cands:
        return None
    return min(r['latency_us_per_frame_mean'] for r in cands)


# ============ network timing run ============

def run():
    os.makedirs(OutDir, exist_ok=True)
    torch.manual_seed(SEED)

    rows = []
    header = (f"{'network':<9}{'M':>3}{'batch':>8}"
              f"{'latency/frame':>18}{'throughput':>18}")
    subhdr = (f"{'':<9}{'':>3}{'':>8}{'mean +- std (us)':>18}"
              f"{'mean +- std (fps)':>18}")

    for name in NAMES:
        print(f"\n{'='*72}\n{name}\n{'='*72}")
        print(header)
        print(subhdr)
        print('-' * 72)
        for M in Ms:
            model = load_net(name, M)
            for B in BATCH_SIZES:
                try:
                    x = torch.rand(B, D_IN, device=device)
                    t = time_forward(model, x)                 # (REPEATS,) seconds/batch
                except RuntimeError as e:
                    print(f"  {name} M={M} B={B}: skipped ({str(e).splitlines()[0]})")
                    if device.type == "cuda":
                        torch.cuda.empty_cache()
                    continue

                lat_us  = t / B * 1e6                            # microseconds per frame
                fps     = B / t                                  # frames per second
                lat_m, lat_s = lat_us.mean(), lat_us.std()
                fps_m, fps_s = fps.mean(),   fps.std()

                print(f"{name:<9}{M:>3}{B:>8}"
                      f"{lat_m:>10.3f} +-{lat_s:>5.3f}"
                      f"{fps_m:>13.3e} +-{fps_s:>7.1e}")

                rows.append(dict(network=name, M=M, batch_size=B,
                                 latency_us_per_frame_mean=lat_m,
                                 latency_us_per_frame_std=lat_s,
                                 throughput_fps_mean=fps_m,
                                 throughput_fps_std=fps_s,
                                 batch_ms_mean=t.mean() * 1e3,
                                 batch_ms_std=t.std() * 1e3))
            del model
            if device.type == "cuda":
                torch.cuda.empty_cache()

    # ---- save CSV ----
    csv_path = os.path.join(OutDir, "inference_timing.csv")
    cols = ["network", "M", "batch_size",
            "latency_us_per_frame_mean", "latency_us_per_frame_std",
            "throughput_fps_mean", "throughput_fps_std",
            "batch_ms_mean", "batch_ms_std"]
    with open(csv_path, "w") as f:
        print(",".join(cols), file=f)
        for r in rows:
            print(",".join(
                (f"{r[c]:.6g}" if isinstance(r[c], float) else str(r[c]))
                for c in cols), file=f)
    print(f"\nSaved -> {csv_path}")

    # ---- compact summary for the paper ----
    B_lat = BATCH_SIZES[0]
    B_thr = BATCH_SIZES[-1]
    print(f"\n{'='*72}")
    print(f"Summary: latency at batch {B_lat}, throughput at batch {B_thr}")
    print(f"{'='*72}")
    print(f"{'network':<9}{'M':>3}"
          f"{'latency (us/frame)':>22}{'throughput (fps)':>20}")
    print('-' * 72)
    for name in NAMES:
        for M in Ms:
            rl = next((r for r in rows if r['network'] == name
                       and r['M'] == M and r['batch_size'] == B_lat), None)
            rt = next((r for r in rows if r['network'] == name
                       and r['M'] == M and r['batch_size'] == B_thr), None)
            if rl is None and rt is None:
                continue
            lat = f"{rl['latency_us_per_frame_mean']:.2f}" if rl else "-"
            thr = f"{rt['throughput_fps_mean']:.3e}" if rt else "-"
            print(f"{name:<9}{M:>3}{lat:>22}{thr:>20}")

    return rows


# ============ EM-GML timing run ============

def run_em(net_rows):
    print(f"\n{'#'*72}")
    print(f"EM-GML per-frame timing (multi-start EM, K={EM_K}, "
          f"n_iter={EM_N_ITER}, {EM_N_TIME} frames)")
    print(f"{'#'*72}")

    if not os.path.exists(os.path.join(Data_folder, "b_map.txt")):
        print(f"  [EM] {Data_folder} not found; skip EM-GML timing.")
        return

    b_map = torch.tensor(np.loadtxt(os.path.join(Data_folder, "b_map.txt"),
                                    dtype=np.float32), device=device)
    G_map = torch.tensor(np.loadtxt(os.path.join(Data_folder, "G_map.txt"),
                                    dtype=np.float32), device=device)
    noise = Noise(b=b_map, mu=G_map, G=G_map)

    em_rows = []
    print(f"\n{'M':>3}{'frames':>8}{'per-frame (ms)':>22}{'throughput (fps)':>20}")
    print('-' * 53)
    for M in EM_M_LIST:
        try:
            pf = time_em_gml(M, noise)              # seconds/frame, (EM_REPEATS,)
        except Exception as e:
            print(f"  M={M}: skipped ({str(e).splitlines()[0]})")
            continue
        ms  = pf * 1e3
        fps = 1.0 / pf
        print(f"{M:>3}{EM_N_TIME:>8}{ms.mean():>14.3f} +-{ms.std():>5.3f}"
              f"{fps.mean():>20.1f}")
        em_rows.append(dict(M=M, per_frame_ms_mean=float(ms.mean()),
                            per_frame_ms_std=float(ms.std()),
                            throughput_fps=float(fps.mean())))

    # ---- save CSV ----
    csv_path = os.path.join(OutDir, "inference_timing_em.csv")
    with open(csv_path, "w") as f:
        print("M,n_frames,K,n_iter,per_frame_ms_mean,per_frame_ms_std,"
              "throughput_fps", file=f)
        for r in em_rows:
            print(f"{r['M']},{EM_N_TIME},{EM_K},{EM_N_ITER},"
                  f"{r['per_frame_ms_mean']:.6g},{r['per_frame_ms_std']:.6g},"
                  f"{r['throughput_fps']:.6g}", file=f)
    print(f"\nSaved -> {csv_path}")

    # ---- speedup of each network over EM-GML ----
    if net_rows and em_rows:
        print(f"\n{'='*72}")
        print("Speedup of each network over EM-GML, i.e. EM-GML per-frame time "
              "divided by")
        print("the network per-frame time at a saturating batch")
        print(f"{'='*72}")
        print(f"{'M':>3}{'EM (ms)':>10}" + "".join(f"{n:>10}" for n in NAMES))
        print('-' * (13 + 10 * len(NAMES)))
        for r in em_rows:
            M = r['M']; em_ms = r['per_frame_ms_mean']
            cells = []
            for name in NAMES:
                us = _best_net_us(net_rows, name, M)
                cells.append(f"{em_ms * 1e3 / us:.0f}x" if us else "-")
            print(f"{M:>3}{em_ms:>10.3f}" + "".join(f"{c:>10}" for c in cells))


if __name__ == "__main__":
    import atexit
    os.makedirs(OutDir, exist_ok=True)
    _log_path = os.path.join(
        OutDir, f"inference_timing_log_{time.strftime('%Y%m%d_%H%M%S')}.txt")
    _logf = open(_log_path, "w", encoding="utf-8")
    _orig_stdout = sys.stdout
    while type(_orig_stdout).__name__ == "_Tee":
        _orig_stdout = _orig_stdout.streams[0]
    sys.stdout = _Tee(_orig_stdout, _logf)

    @atexit.register
    def _close_log(_o=_orig_stdout, _f=_logf):
        sys.stdout = _o
        _f.close()

    print(f"[Log] Writing run log -> {_log_path}")
    torch.set_float32_matmul_precision('high')
    if device.type == "cuda":
        torch.backends.cudnn.benchmark = True    # autotune conv kernels
    print_device_info()
    print(f"device: {device}, torch {torch.__version__}, "
          f"warmup {WARMUP}, repeats {REPEATS}, dtype float32")

    t0 = time.perf_counter()
    net_rows = run() if TIME_NETS else []
    if TIME_EM:
        run_em(net_rows)
    mins, sec = divmod(time.perf_counter() - t0, 60)
    print(f"\n[Timing] Infer-Timing: {int(mins)}m {sec:.1f}s")
