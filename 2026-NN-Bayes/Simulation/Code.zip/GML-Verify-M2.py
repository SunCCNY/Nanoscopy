"""
GML-Verify-M2.py

Verification that the multi-start EM benchmark EM-GML actually reaches the
global maximum of the likelihood, by comparison against an exhaustive grid
search over the full parameter space.

EM-GML is one of the two reference estimators in every table, so the claim
that it approximates the global maximum-likelihood estimate needs support. On
Dataset-Random with M = 2 the parameter space is four dimensional and can be
searched exhaustively, which gives a reference the multi-start can be measured
against.

Method
------
For every frame the exhaustive grid gives the best grid point, i.e. the
maximiser of the log-likelihood over all ordered pairs of grid positions. That
point is then refined by EM, which moves it off the grid to the exact local
maximum of the mode it sits in. The refined point is the reference,

    l_ref = l( EM( grid argmax ) )

Because the grid covers the whole parameter space, the mode containing the grid
argmax is the mode containing the global maximum unless the grid step is too
coarse to resolve a narrow competing peak, so l_ref is a tight lower bound on
the global maximum and in practice equals it.

The multi-start is then judged by

    l( theta_EM-GML )  >=  l_ref - tol

evaluated frame by frame, and the fraction of frames satisfying it is reported
as a function of the number of starts K. The running best over starts is used,
so a single pass of K_MAX starts yields the whole curve and the checkpoints are
nested, i.e. the K = 50 result is computed from the first 50 starts of the same
sequence that produces the K = 250 result. This removes the confound that
separate runs with different K would otherwise introduce through diverging
random number streams.

The effect of the EM iteration count is checked separately, since a flat
likelihood surface slows convergence and a start that is in the right basin may
still fail to arrive within a fixed iteration budget.

Comparison is on the log-likelihood rather than on position, because the
question is whether the multi-start finds the maximiser, and two configurations
far apart in position can be nearly tied in likelihood when the surface is flat.

Outputs
    Benchmark-Random/GML-Verify/gml_verify_m2.csv
    Benchmark-Random/GML-Verify/gml_verify_m2.png

Yi Sun
"""

import sys
import os
import time
import math
import numpy as np
import torch
import tifffile
import matplotlib.pyplot as plt

ROOT = r"K:\Research_KB"   # <- change to your actual path
sys.path.append(ROOT)


# ----------------------------------------------------------------------
# Console logging: duplicate all stdout to a log file in the Benchmark folder
# ----------------------------------------------------------------------
class _Tee:
    """Write everything printed to the console AND to a log file."""
    def __init__(self, *streams):
        self.streams = streams
    def write(self, data):
        for s in self.streams:
            try:
                s.write(data)
            except UnicodeEncodeError:
                s.write(data.encode("ascii", "replace").decode("ascii"))
            s.flush()
    def flush(self):
        for s in self.streams:
            s.flush()


from SMLM_Lib import (
    SystemConfig,
    EmitterData,
    Gaussian2DPSF,
    Camera,
    Noise,
    gauss2d_em_batch_torch,
    print_device_info,
)
from SMLM_Lib.Gauss2D import Qfunc_torch, gauss2d_loglike_batch_torch


# ============ configuration ============
M           = 2
N           = 1000
Data_folder = "Dataset-Random"
OutDir      = "Benchmark-Random/GML-Verify"

GRID_STEP = 5.0
A_CHUNK   = 32

K_MAX        = 250
CHECKPOINTS  = [1, 5, 10, 25, 50, 100, 150, 200, 250]
N_ITER       = 300          # iteration budget used by the reported EM-GML
N_ITER_REF   = 1000         # budget for refining the grid argmax
N_ITER_LONG  = 1000         # budget for the iteration-count check
K_LONG       = 100          # starts used in the iteration-count check
TOL          = 1e-3         # log-likelihood tolerance

NEAR_HALF_WIDE = 100.0
GN   = 'N'
SEED = 0

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

camera = Camera(Kx=7, Ky=7, Dx=100.0, Dy=100.0, Dt=0.01)
Kx, Ky = camera.Kx, camera.Ky
Dx, Dy, Dt = camera.Dx, camera.Dy, camera.Dt
DxDyDt = Dx * Dy * Dt

psf   = Gaussian2DPSF(sigma=108.81)
sigma = psf.sigma

b_map = torch.tensor(np.loadtxt(os.path.join(Data_folder, "b_map.txt"),
                                dtype=np.float32), device=device)
G_map = torch.tensor(np.loadtxt(os.path.join(Data_folder, "G_map.txt"),
                                dtype=np.float32), device=device)
noise = Noise(b=b_map, mu=G_map, G=G_map)

Im0 = 300000.0
MARGIN_PX = 2
LO = MARGIN_PX * Dx
HI = (Kx - MARGIN_PX) * Dx


# ============ grid search ============

def build_grid():
    g = torch.arange(LO, HI + 1e-6, GRID_STEP, dtype=torch.float32, device=device)
    G = g.numel()
    kx = torch.arange(Kx, dtype=torch.float32, device=device).view(1, Kx)
    ky = torch.arange(Ky, dtype=torch.float32, device=device).view(1, Ky)
    gx = g.view(G, 1)
    qx = (Qfunc_torch(-(Dx * (kx + 1) - gx) / sigma)
          - Qfunc_torch(-(Dx * kx - gx) / sigma))
    qy = (Qfunc_torch(-(Dy * (ky + 1) - gx) / sigma)
          - Qfunc_torch(-(Dy * ky - gx) / sigma))
    q = qy.view(G, 1, Ky, 1) * qx.view(1, G, 1, Kx)
    sig_map = (Dt * Im0 * q).reshape(G * G, Ky * Kx).contiguous()
    X = g.view(1, G).expand(G, G).reshape(-1)
    Y = g.view(G, 1).expand(G, G).reshape(-1)
    pos = torch.stack([X, Y], dim=1).contiguous()
    return pos, sig_map, G


def grid_argmax(U_corr, sig_map, bg):
    """Best grid pair for one frame, returned as the two position indices."""
    S = sig_map.shape[0]
    best_val = torch.tensor(float('-inf'), device=device)
    best_idx = 0
    for a0 in range(0, S, A_CHUNK):
        a1 = min(a0 + A_CHUNK, S)
        w = sig_map[a0:a1].unsqueeze(1) + sig_map.unsqueeze(0) + bg
        w = torch.clamp(w, min=1e-12)
        ll = (U_corr * torch.log(w) - w).sum(dim=-1)          # (A, S)
        v, i = ll.reshape(-1).max(dim=0)
        if v > best_val:
            best_val = v
            best_idx = a0 * S + int(i.item())
    return best_idx // S, best_idx % S


# ============ helpers ============

def load_frames():
    path = os.path.join(Data_folder, f"M={M}_Frames.tif")
    arr  = tifffile.imread(path).astype(np.float32)
    return torch.tensor(arr, dtype=torch.float32, device=device)


def load_xy_all():
    path = os.path.join(Data_folder, f"M={M}_xy.txt")
    arr  = np.loadtxt(path, dtype=np.float32, skiprows=1)
    return torch.tensor(arr, dtype=torch.float32, device=device).reshape(N, M, 2)


# ============ main ============

def run():
    os.makedirs(OutDir, exist_ok=True)

    pos, sig_map, G = build_grid()
    S = pos.shape[0]
    print(f"Exhaustive grid: step {GRID_STEP:.1f} nm, {G} points per axis, "
          f"{S} single-emitter positions, {S*S:,} ordered pairs per frame.\n")

    frames  = load_frames()
    xy_true = load_xy_all()

    bg   = (DxDyDt * (noise.b + noise.G)).reshape(-1)
    corr = (DxDyDt * (noise.G - noise.mu)).reshape(-1)

    Im_tensor = torch.full((1, M), Im0, dtype=torch.float32, device=device)
    emitter = EmitterData(xy=xy_true[0:1], Im=Im_tensor)
    system  = SystemConfig(emitter=emitter, psf=psf, camera=camera, noise=noise)

    # ---- reference: exhaustive grid argmax, then refined by EM -----------
    t0 = time.perf_counter()
    xy_grid = torch.empty(N, M, 2, device=device)
    for n in range(N):
        U_corr = torch.clamp(frames[n].reshape(-1) + corr, min=0.0)
        a, b = grid_argmax(U_corr, sig_map, bg)
        xy_grid[n, 0] = pos[a]
        xy_grid[n, 1] = pos[b]
        if (n + 1) % 200 == 0:
            print(f"  grid search {n+1}/{N} [{time.perf_counter()-t0:.0f}s]")
    with torch.no_grad():
        ll_grid = gauss2d_loglike_batch_torch(frames, xy_grid, system)
        xy_ref = gauss2d_em_batch_torch(frames, xy_grid, system,
                                        GN=GN, n_iter=N_ITER_REF)
        ll_ref = gauss2d_loglike_batch_torch(frames, xy_ref, system)
    gain = (ll_ref - ll_grid)
    print(f"  grid search done [{time.perf_counter()-t0:.0f}s]")
    print(f"  refining the grid argmax by EM raised the log-likelihood by "
          f"{gain.mean().item():.4f} on average, i.e. the off-grid correction\n")

    # ---- multi-start EM with nested checkpoints --------------------------
    def multistart(n_iter, k_max, checkpoints, seed):
        gen = torch.Generator(device=device).manual_seed(seed)
        best_ll = torch.full((N,), float('-inf'), device=device)
        out = {}
        for k in range(1, k_max + 1):
            xyi = xy_true + NEAR_HALF_WIDE * (
                2 * torch.rand(N, M, 2, device=device, generator=gen) - 1)
            with torch.no_grad():
                xy_k = gauss2d_em_batch_torch(frames, xyi, system,
                                              GN=GN, n_iter=n_iter)
                ll_k = gauss2d_loglike_batch_torch(frames, xy_k, system)
            best_ll = torch.maximum(best_ll, ll_k)
            if k in checkpoints:
                reached = (best_ll >= ll_ref - TOL)
                out[k] = (float(reached.float().mean().item()),
                          float((ll_ref - best_ll).clamp(min=0).mean().item()))
        return out

    print(f"Multi-start EM, n_iter = {N_ITER}, up to K = {K_MAX} starts")
    t0 = time.perf_counter()
    res = multistart(N_ITER, K_MAX, set(CHECKPOINTS), SEED)
    print(f"  done [{time.perf_counter()-t0:.0f}s]\n")

    print(f"{'='*70}")
    print("Fraction of frames on which multi-start EM reaches the global maximum")
    print(f"{'='*70}")
    print(f"{'K':>6}{'reached':>12}{'mean shortfall in logL':>26}")
    print('-' * 44)
    for k in CHECKPOINTS:
        f, s = res[k]
        print(f"{k:>6}{100*f:>11.1f}%{s:>26.5f}")

    # ---- iteration-count check -------------------------------------------
    print(f"\nIteration-count check, n_iter = {N_ITER_LONG}, K = {K_LONG}")
    t0 = time.perf_counter()
    res_long = multistart(N_ITER_LONG, K_LONG, {K_LONG}, SEED)
    f_l, s_l = res_long[K_LONG]
    f_s, s_s = res[K_LONG]
    print(f"  n_iter={N_ITER:<5} K={K_LONG}: reached {100*f_s:5.1f}%   "
          f"shortfall {s_s:.5f}")
    print(f"  n_iter={N_ITER_LONG:<5} K={K_LONG}: reached {100*f_l:5.1f}%   "
          f"shortfall {s_l:.5f}")
    print(f"  done [{time.perf_counter()-t0:.0f}s]")

    if f_l - f_s > 0.02:
        print("\n  A longer iteration budget helps materially, so n_iter = "
              f"{N_ITER} is not sufficient and the reported EM-GML is "
              "conservative.")
    else:
        print(f"\n  A longer iteration budget changes little, so n_iter = "
              f"{N_ITER} is sufficient.")

    # ---- verdict ---------------------------------------------------------
    f_max, s_max = res[K_MAX]
    print(f"\n{'='*70}")
    if f_max > 0.99:
        print(f"PASS: at K = {K_MAX} the multi-start reaches the global maximum on "
              f"{100*f_max:.1f}% of frames,")
        print("      so EM-GML is a sound global maximum-likelihood benchmark.")
    else:
        print(f"PARTIAL: at K = {K_MAX} the multi-start reaches the global maximum "
              f"on {100*f_max:.1f}% of frames.")
        print("      EM-GML therefore understates the global maximum on the")
        print("      remainder, i.e. it is a conservative benchmark. Report the")
        print("      fraction, or raise K until the curve saturates.")
    print(f"{'='*70}")

    # ---- save and plot ----------------------------------------------------
    csv_path = os.path.join(OutDir, "gml_verify_m2.csv")
    with open(csv_path, "w") as f:
        print("K,fraction_reached,mean_logL_shortfall", file=f)
        for k in CHECKPOINTS:
            fr, sh = res[k]
            print(f"{k},{fr:.6f},{sh:.8f}", file=f)
    print(f"\nSaved -> {csv_path}")

    fig, ax1 = plt.subplots(figsize=(6.4, 4.2))
    ks = CHECKPOINTS
    ax1.plot(ks, [100*res[k][0] for k in ks], 'o-', color='navy',
             label='frames reaching the global maximum')
    ax1.set_xlabel('number of starts  K')
    ax1.set_ylabel('frames reaching the global maximum  (%)', color='navy')
    ax1.set_xscale('log')
    ax1.tick_params(axis='y', labelcolor='navy')
    ax1.grid(True, which='both', alpha=0.3)
    ax2 = ax1.twinx()
    ax2.plot(ks, [res[k][1] for k in ks], 's--', color='crimson',
             label='mean shortfall')
    ax2.set_ylabel('mean log-likelihood shortfall', color='crimson')
    ax2.set_yscale('log')
    ax2.tick_params(axis='y', labelcolor='crimson')
    ax1.set_title(f'Multi-start EM against exhaustive grid search, M = {M}')
    fig.tight_layout()
    png = os.path.join(OutDir, "gml_verify_m2.png")
    fig.savefig(png, dpi=200)
    plt.close(fig)
    print(f"Saved -> {png}")


if __name__ == "__main__":
    import atexit
    os.makedirs("Benchmark-Random", exist_ok=True)
    _log_path = os.path.join(
        "Benchmark-Random",
        f"inference_log_GML-Verify_{time.strftime('%Y%m%d_%H%M%S')}.txt")
    _logf = open(_log_path, "w", encoding="utf-8")
    _orig_stdout = sys.stdout
    while type(_orig_stdout).__name__ == "_Tee":
        _orig_stdout = _orig_stdout.streams[0]
    sys.stdout = _Tee(_orig_stdout, _logf)

    @atexit.register
    def _close_log(_o=_orig_stdout, _f=_logf):
        sys.stdout = _o
        _f.close()

    print(f"[Log] Writing run log -> {_log_path}")
    torch.set_float32_matmul_precision('high')
    print_device_info()
    plt.close('all')

    t0 = time.perf_counter()
    run()
    mins, sec = divmod(time.perf_counter() - t0, 60)
    print(f"\n[Timing] GML-Verify-M2: {int(mins)}m {sec:.1f}s")
