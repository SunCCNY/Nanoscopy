"""
EM-GML-Fixed.py

The EM-GML benchmark on Dataset-Fixed, i.e. the multi-start expectation
maximization estimate of Eqs. (30) and (31), which approximates the global
maximum likelihood estimate.

A single EM run started at one point converges to a local maximum of the
likelihood rather than to the global maximizer, and the chance that it reaches
the global maximizer falls as the emitters overlap more severely, because the
Fisher information matrix becomes near singular and the log-likelihood is then
nearly flat about its maximizer. The estimate is therefore formed from K runs
started at K independent random points, of which the one attaining the largest
log-likelihood is kept.

Selection is by log-likelihood alone, which depends only on the estimated
positions and the observed frame, so the selection rule uses no knowledge of
the true positions and a larger K can only bring the estimate closer to the
global maximizer. The initial positions are drawn within +-NEAR_HALF_WIDE nm
of the true positions, so EM-GML is an oracle benchmark in the same sense as
UGIA-F, which keeps the search out of regions of negligible likelihood. Ref.
(Sun 2026) shows that in practice EM can be initialised by a successive
interference cancellation estimator at the cost of losing the guarantee.

The choice K = 250 is justified by two verifications reported elsewhere.
EM-GML-Test-Fixed.py compares the multi-start estimate with a single near-true
start, and GML-Verify-M2.py compares it with an exhaustive search over the
whole parameter space and finds that K = 250 attains the global maximizer on
99.7 percent of frames for M = 2, with the fraction saturating by K = 150.
This script performs neither verification and only produces the numbers and
the images reported in the paper.

The K starts are evaluated BATCH_STARTS at a time rather than one at a time.
A data frame here is 7 x 7 pixels and one (d, M) pair holds only N frames, so
a single start presents the graphics processor with a batch far below its
capacity and the run is dominated by kernel launch overhead. Stacking S starts
along the batch dimension presents S * N frames per call and leaves the result
unchanged, since the starts are independent and the selection of Eq. (30) is a
maximum over them.

Metric note. This paper estimates the emitter locations from a single data
frame, so every frame is an independent estimation problem with M estimates
and M emitters. The metric is therefore RMSMD-H, i.e. the error under the
Hungarian assignment, computed frame by frame and averaged over the frames
as ARMSMD-H. The N estimates of one emitter obtained from N frames are not
pooled into a reconstructed image, so the partition metrics RMSMD-P and
RMSE-P of Sun (2022), which are intended for a reconstruction in which one
emitter carries many estimates, are not used here.

Yi Sun
"""

import sys
import os
import time
import math
import numpy as np
import torch
import tifffile
import matplotlib.pyplot as plt

ROOT = r"K:\Research_KB"   # <- change to your actual path
sys.path.append(ROOT)


# ----------------------------------------------------------------------
# Console logging: duplicate all stdout to a log file in the Benchmark folder
# ----------------------------------------------------------------------
class _Tee:
    """Write everything printed to the console AND to a log file."""
    def __init__(self, *streams):
        self.streams = streams
    def write(self, data):
        for s in self.streams:
            try:
                s.write(data)
            except UnicodeEncodeError:
                s.write(data.encode("ascii", "replace").decode("ascii"))
            s.flush()
    def flush(self):
        for s in self.streams:
            s.flush()


from SMLM_Lib import (
    SystemConfig,
    EmitterData,
    Gaussian2DPSF,
    Camera,
    Noise,
    gauss2d_em_batch_torch,
    print_device_info,
)
from SMLM_Lib.Gauss2D import gauss2d_loglike_batch_torch
from SMLM_Lib.metrics import (rmsmd_per_frame, rmsmd_h_per_frame)


# ============ configuration ============
N           = 25
Data_folder = "Dataset-Fixed"
OutDir      = "Benchmark-Fixed/EM-GML"

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

camera = Camera(Kx=7, Ky=7, Dx=100.0, Dy=100.0, Dt=0.01)
Kx, Ky = camera.Kx, camera.Ky
Dx, Dy = camera.Dx, camera.Dy

psf = Gaussian2DPSF(sigma=108.81)

# Frozen non-uniform noise field saved with the dataset.
b_map = torch.tensor(np.loadtxt(os.path.join(Data_folder, "b_map.txt"),
                                dtype=np.float32), device=device)
G_map = torch.tensor(np.loadtxt(os.path.join(Data_folder, "G_map.txt"),
                                dtype=np.float32), device=device)
noise = Noise(b=b_map, mu=G_map, G=G_map)   # mu_k = G_k

Im0 = 300000.0   # photons / s

NEAR_HALF_WIDE = 100.0   # nm; half-width of the region the starts are drawn in
K              = 250     # number of random starts per frame
SEED           = 0       # reproducible starts
N_ITER         = 300     # EM outer iterations
GN             = 'N'     # Newton ascent; the gradient ascent of Ref. (Sun 2026)
                         # matches it to a few tenths of a nanometre and is
                         # three times slower, so only Newton is used here.

# Number of starts evaluated in one call. The batch presented to the graphics
# processor is BATCH_STARTS * N frames, so a larger value uses the device more
# fully at the cost of more memory. The result does not depend on it.
BATCH_STARTS = 25

D_LIST = [25, 50, 75, 100, 125, 150]

# Set to True to skip the expectation maximization entirely and regenerate the
# images from the estimated locations saved by a previous run, which is useful
# when only the appearance of a figure is being changed. The metric printed in
# the legend is recomputed from the saved locations, so it is exact.
PLOT_ONLY = False


# ============ helpers ============

def load_xy_file(path):
    arr = np.loadtxt(path, dtype=np.float32)
    if arr.ndim == 1:
        arr = arr.reshape(1, 2)
    return torch.tensor(arr, dtype=torch.float32, device=device)


def load_frames(path):
    arr = tifffile.imread(path).astype(np.float32)
    return torch.tensor(arr, dtype=torch.float32, device=device)


def armsmd_and_h(xy_est_all, xy_true, M):
    """ARMSMD and ARMSMD-H over the N frames of one (d, M) pair.

    Both are averaged on the squared values over the frames and the square
    root is taken once at the end.
    """
    true_all = xy_true.unsqueeze(0).expand(xy_est_all.shape[0], M, 2)
    _, D2_all  = rmsmd_per_frame(xy_est_all, true_all)
    _, D2h_all = rmsmd_h_per_frame(xy_est_all, true_all)
    return (math.sqrt(D2_all.mean().item()),
            math.sqrt(D2h_all.mean().item()))


def plot_estimates(xy_est_all, xy_true, alg_name, armsmd_h_value, outfile):
    """Plot the accumulated estimates of all frames against the true locations.

    The N*M estimates of the N frames are shown together so that the scatter of
    the estimator about the true locations is visible, whereas the value in the
    legend is ARMSMD-H, i.e. the metric computed frame by frame and averaged
    over the frames.
    """
    fig, ax = plt.subplots(figsize=(4, 4))
    ax.imshow(np.zeros((Ky, Kx), dtype=np.float32), cmap="gray", origin="upper")
    ax.set_xlim(-0.5, Kx - 0.5); ax.set_ylim(Ky - 0.5, -0.5)
    ax.set_aspect("equal"); ax.axis("off")
    xy_est_np  = xy_est_all.reshape(-1, 2).cpu().numpy()
    xy_true_np = xy_true.cpu().numpy()
    ax.scatter(xy_est_np[:, 0] / Dx - 0.5, xy_est_np[:, 1] / Dy - 0.5,
               c="white", s=10, zorder=5,
               label=f"{alg_name}  ARMSMD-H = {armsmd_h_value:.2f} nm")
    ax.scatter(xy_true_np[:, 0] / Dx - 0.5, xy_true_np[:, 1] / Dy - 0.5,
               c="red", s=10, zorder=5, label="Ground Truth")
    ax.legend(loc="upper left", framealpha=1.0, labelcolor="white",
              frameon=True, edgecolor="white", facecolor="none", fontsize=9)
    os.makedirs(os.path.dirname(outfile) or '.', exist_ok=True)
    fig.savefig(outfile, dpi=150, bbox_inches="tight")
    plt.show(block=False); plt.close(fig)


def multistart_em(frames_all, xy_all, system, M, gen):
    """The EM-GML estimate of Eqs. (30) and (31) for one (d, M) pair.

    K starts are drawn within +-NEAR_HALF_WIDE nm of the true positions and
    evaluated BATCH_STARTS at a time, and for every frame the run of largest
    log-likelihood is kept.

    Returns
    -------
    best_xy : (N, M, 2) estimated locations
    best_ll : (N,) log-likelihood attained
    """
    n = frames_all.shape[0]
    best_ll = torch.full((n,), float('-inf'), device=device)
    best_xy = torch.zeros(n, M, 2, device=device)

    done = 0
    while done < K:
        S = min(BATCH_STARTS, K - done)
        # S independent starts for every frame, stacked along the batch axis
        # so that entry s*n + i belongs to start s of frame i.
        jitter = NEAR_HALF_WIDE * (
            2 * torch.rand(S, n, M, 2, device=device, generator=gen) - 1)
        xyi = (xy_all.unsqueeze(0) + jitter).reshape(S * n, M, 2)
        frames_rep = frames_all.repeat(S, 1, 1)
        with torch.no_grad():
            xy_s = gauss2d_em_batch_torch(frames_rep, xyi, system,
                                          GN=GN, n_iter=N_ITER)
            ll_s = gauss2d_loglike_batch_torch(frames_rep, xy_s, system)
        ll_s = ll_s.reshape(S, n)
        xy_s = xy_s.reshape(S, n, M, 2)

        ll_max, idx = ll_s.max(dim=0)                     # (n,), (n,)
        xy_max = xy_s[idx, torch.arange(n, device=device)]
        better = ll_max > best_ll
        best_ll = torch.where(better, ll_max, best_ll)
        best_xy = torch.where(better.view(n, 1, 1), xy_max, best_xy)
        done += S

    return best_xy, best_ll


# ============ benchmark ============

def run_em_gml():
    print(f"\n=== EM-GML Benchmark (Fixed) ===")
    print(f"    K = {K} starts within +-{NEAR_HALF_WIDE:.0f} nm, "
          f"{BATCH_STARTS} starts per call, Newton ascent, {N_ITER} iterations")
    os.makedirs(OutDir, exist_ok=True)

    gen = torch.Generator(device=device).manual_seed(SEED)
    summary = []

    for d_nm in D_LIST:
        for M in range(1, 6):
            xy_path  = os.path.join(Data_folder, f"d={d_nm}_M={M}_xy.txt")
            tif_path = os.path.join(Data_folder, f"d={d_nm}_M={M}_Frames.tif")
            if not os.path.exists(xy_path) or not os.path.exists(tif_path):
                print(f"d={d_nm:3d}  M={M}  [skip - dataset not found]")
                continue

            xy_true  = load_xy_file(xy_path)        # (M, 2)
            est_path = os.path.join(OutDir, f"d={d_nm}_M={M}_xy_est.npy")
            outfile  = os.path.join(OutDir, f"d={d_nm}_M={M}_EM-GML.png")

            if PLOT_ONLY:
                if not os.path.exists(est_path):
                    print(f"d={d_nm:3d}  M={M}  [skip - no saved estimate]")
                    continue
                best_xy = torch.tensor(np.load(est_path),
                                       dtype=torch.float32, device=device)
                rm, rmh = armsmd_and_h(best_xy, xy_true, M)
                plot_estimates(best_xy, xy_true, "EM-GML", rmh, outfile)
                print(f"d={d_nm:3d}  M={M}  [plot only]  "
                      f"ARMSMD = {rm:7.2f} nm  ARMSMD-H = {rmh:7.2f} nm")
                summary.append((d_nm, M, rm, rmh))
                continue

            t0 = time.perf_counter()
            frames_all = load_frames(tif_path)      # (N, Ky, Kx)
            xy_all     = xy_true.unsqueeze(0).expand(N, M, 2).contiguous()

            Im_tensor = torch.full((1, M), Im0, dtype=torch.float32, device=device)
            emitter = EmitterData(xy=torch.zeros(1, M, 2, device=device), Im=Im_tensor)
            system  = SystemConfig(emitter=emitter, psf=psf, camera=camera, noise=noise)

            best_xy, best_ll = multistart_em(frames_all, xy_all, system, M, gen)
            rm, rmh = armsmd_and_h(best_xy, xy_true, M)

            np.save(est_path, best_xy.cpu().numpy())
            plot_estimates(best_xy, xy_true, "EM-GML", rmh, outfile)

            print(f"d={d_nm:3d}  M={M}  "
                  f"ARMSMD = {rm:7.2f} nm  ARMSMD-H = {rmh:7.2f} nm  "
                  f"mean logL = {best_ll.mean().item():10.2f}  "
                  f"[{time.perf_counter()-t0:.1f}s]")
            summary.append((d_nm, M, rm, rmh))

    # ---- summary table ----
    print(f"\n{'='*46}")
    print("Summary, ARMSMD and ARMSMD-H (nm)")
    print(f"{'='*46}")
    print(f"{'d':>6} {'M':>4} {'ARMSMD':>12} {'ARMSMD-H':>12}")
    print('-' * 46)
    for d_nm, M, rm, rmh in summary:
        print(f"{d_nm:>6} {M:>4} {rm:>12.2f} {rmh:>12.2f}")

    out_csv = os.path.join(OutDir, "summary_em_gml.csv")
    with open(out_csv, "w") as f:
        print("d_nm,M,armsmd_nm,armsmd_h_nm", file=f)
        for d_nm, M, rm, rmh in summary:
            print(f"{d_nm},{M},{rm:.6f},{rmh:.6f}", file=f)
    print(f"\nSaved -> {out_csv}")


# ======================================================================
# Main
# ======================================================================

if __name__ == "__main__":
    import atexit
    os.makedirs("Benchmark-Fixed", exist_ok=True)
    _log_path = os.path.join(
        "Benchmark-Fixed",
        f"inference_log_EM-GML_Fixed_{time.strftime('%Y%m%d_%H%M%S')}.txt")
    _logf = open(_log_path, "w", encoding="utf-8")
    _orig_stdout = sys.stdout
    while type(_orig_stdout).__name__ == "_Tee":
        _orig_stdout = _orig_stdout.streams[0]
    sys.stdout = _Tee(_orig_stdout, _logf)

    @atexit.register
    def _close_log(_o=_orig_stdout, _f=_logf):
        sys.stdout = _o
        _f.close()

    print(f"[Log] Writing run log -> {_log_path}")
    torch.manual_seed(SEED)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(SEED)
    torch.set_float32_matmul_precision('high')
    print_device_info()
    plt.close('all')

    t0 = time.perf_counter()
    run_em_gml()
    mins, sec = divmod(time.perf_counter() - t0, 60)
    print(f"\n[Timing] EM-GML (Fixed): {int(mins)}m {sec:.1f}s")
