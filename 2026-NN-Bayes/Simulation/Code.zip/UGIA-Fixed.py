"""
UGIA-Fixed.py
 
Benchmark the UGIA-F estimator on Dataset-Fixed over all (d, M).
 
Yi Sun
"""
 
import sys
import os
import time
import math
 
# ----------------------------------------------------------------------
# Console logging: duplicate all stdout to a log file in the Benchmark folder
# ----------------------------------------------------------------------
class _Tee:
    """Write everything printed to the console AND to a log file."""
    def __init__(self, *streams):
        self.streams = streams
    def write(self, data):
        for s in self.streams:
            try:
                s.write(data)
            except UnicodeEncodeError:
                s.write(data.encode("ascii", "replace").decode("ascii"))
            s.flush()
    def flush(self):
        for s in self.streams:
            s.flush()
 
import numpy as np
import torch
import tifffile
import matplotlib.pyplot as plt
import matplotlib.patches as patches
 
ROOT = r"K:\Research_KB"   # <- change to your actual path
sys.path.append(ROOT)
 
from SMLM_Lib import (
    SystemConfig,
    EmitterData,
    Gaussian2DPSF,
    Camera,
    Noise,
    gauss2d_ugia_f_batch_torch,
    gauss2d_em_batch_torch,
    print_device_info,
)
from SMLM_Lib.metrics import (rmsmd_per_frame, rmsmd_h_per_frame)
 
# ----------------------------------------------------------------------
# Metric note. This paper estimates the emitter locations from a single data
# frame, so every frame is an independent estimation problem with M estimates
# and M emitters. The metric is therefore RMSMD-H, i.e. the error under the
# Hungarian assignment, computed frame by frame and averaged over the frames
# as ARMSMD-H. The N estimates of one emitter obtained from N frames are not
# pooled into a reconstructed image, so the partition metrics RMSMD-P and
# RMSE-P of Sun (2022), which are intended for a reconstruction in which one
# emitter carries many estimates, are not used here.
# ----------------------------------------------------------------------
 
from SMLM_Lib.position import sample_emitters_batch
 
 
# ============ configuration ============
N           = 25
Data_folder = "Dataset-Fixed"
SEED        = 0     # global RNG seed; UGIA-F draws its Gaussian vector of
                    # Eq. (33) from the default generator, so this fixes the
                    # UGIA-F realisation and makes the run reproducible.
 
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
 
camera = Camera(Kx=7, Ky=7, Dx=100.0, Dy=100.0, Dt=0.01)
Kx, Ky = camera.Kx, camera.Ky
Dx, Dy = camera.Dx, camera.Dy
 
psf = Gaussian2DPSF(sigma=108.81)
 
# Load the frozen non-uniform noise field saved with the dataset, so the FIM
# and UGIA-F consume the identical b_k and G_k that generated the frames.
b_map = torch.tensor(np.loadtxt(os.path.join(Data_folder, "b_map.txt"),
                                dtype=np.float32), device=device)
G_map = torch.tensor(np.loadtxt(os.path.join(Data_folder, "G_map.txt"),
                                dtype=np.float32), device=device)
noise = Noise(b=b_map, mu=G_map, G=G_map)   # mu_k = G_k
 
Im0 = 300000.0   # photons / s
 
 
# ============ helpers ============
 
def load_xy_file(path):
    arr = np.loadtxt(path, dtype=np.float32)
    if arr.ndim == 1:
        arr = arr.reshape(1, 2)
    return torch.tensor(arr, dtype=torch.float32, device=device)
 
 
def load_frames(path):
    arr = tifffile.imread(path).astype(np.float32)
    return torch.tensor(arr, dtype=torch.float32, device=device)
 
 
def compute_and_plot(xy_est_all, xy_true, M, alg_name, outfile):
    """Score the N frames of one (d, M) pair and plot the accumulated estimates.
 
    xy_est_all : (N, M, 2) estimates, one set per frame
    xy_true    : (M, 2) true locations, common to all frames
 
    Both metrics are computed frame by frame and averaged on the squared
    values, so ARMSMD-H is the error under the Hungarian assignment averaged
    over the frames. The plot shows all N*M estimates so the scatter of the
    estimator about the true locations is visible.
    """
    true_all = xy_true.unsqueeze(0).expand(xy_est_all.shape[0], M, 2)
    _, D2_all  = rmsmd_per_frame(xy_est_all, true_all)
    _, D2h_all = rmsmd_h_per_frame(xy_est_all, true_all)
    D_rmsmd   = math.sqrt(D2_all.mean().item())
    D_rmsmd_h = math.sqrt(D2h_all.mean().item())
    xy_est = xy_est_all.reshape(-1, 2)
    print(f"  {alg_name}  ARMSMD = {D_rmsmd:.2f} nm  ARMSMD-H = {D_rmsmd_h:.2f} nm")
    fig, ax = plt.subplots(figsize=(4, 4))
    ax.imshow(np.zeros((Ky, Kx), dtype=np.float32), cmap="gray", origin="upper")
    ax.set_xlim(-0.5, Kx - 0.5); ax.set_ylim(Ky - 0.5, -0.5)
    ax.set_aspect("equal"); ax.axis("off")
    xy_est_np  = xy_est.cpu().numpy(); xy_true_np = xy_true.cpu().numpy()
    ax.scatter(xy_est_np[:, 0] / Dx - 0.5, xy_est_np[:, 1] / Dy - 0.5,
               c="white", s=10,
               label=f"{alg_name}  ARMSMD-H = {D_rmsmd_h:.2f} nm")
    ax.scatter(xy_true_np[:, 0] / Dx - 0.5, xy_true_np[:, 1] / Dy - 0.5,
               c="red", s=10, label="Ground Truth")
    ax.legend(loc="upper left", framealpha=1.0, labelcolor="white",
              frameon=True, edgecolor="white", facecolor="none", fontsize=9)
    os.makedirs(os.path.dirname(outfile) or '.', exist_ok=True)
    fig.savefig(outfile, dpi=150, bbox_inches="tight")
    plt.show(block=False); plt.close(fig)
    return D_rmsmd, D_rmsmd_h
 
 
# ============ benchmark ============
 
def run_ugia_f():
    print("\n=== UGIA-F Benchmark (Fixed) ===")
    outdir = "Benchmark-Fixed/UGIA-F"
    os.makedirs(outdir, exist_ok=True)
    for d_nm in [25, 50, 75, 100, 125, 150]:
        for M in range(1, 6):
            xy_path = os.path.join(Data_folder, f"d={d_nm}_M={M}_xy.txt")
            if not os.path.exists(xy_path):
                print(f"d={d_nm:3d}  M={M}  [skip - dataset not found]"); continue
            xy_true = load_xy_file(xy_path)
            xy_all  = xy_true.unsqueeze(0).expand(N, M, 2).contiguous()
            with torch.no_grad():
                xyF_all = gauss2d_ugia_f_batch_torch(xy_all, Im0, psf, camera, noise, ImType='KI')
            print(f"d={d_nm:3d}  M={M}  ", end="")
            outfile = os.path.join(outdir, f"d={d_nm}_M={M}_UGIA-F.png")
            compute_and_plot(xyF_all, xy_true, M, "UGIA-F", outfile)
 
 
# ======================================================================
# Main
# ======================================================================
 
if __name__ == "__main__":
    # ---- start run log (saved in the Benchmark folder) ----
    import atexit
    os.makedirs("Benchmark-Fixed", exist_ok=True)
    _log_path = os.path.join(
        "Benchmark-Fixed", f"inference_log_UGIA-F_Fixed_{time.strftime('%Y%m%d_%H%M%S')}.txt")
    _logf = open(_log_path, "w", encoding="utf-8")
    _orig_stdout = sys.stdout
    while type(_orig_stdout).__name__ == "_Tee":  # unwrap a leftover Tee
        _orig_stdout = _orig_stdout.streams[0]
    sys.stdout = _Tee(_orig_stdout, _logf)
 
    @atexit.register
    def _close_log(_o=_orig_stdout, _f=_logf):
        sys.stdout = _o
        _f.close()
 
    print(f"[Log] Writing run log -> {_log_path}")
    # Seed the global RNG so the UGIA-F Gaussian draw of Eq. (33) is reproducible.
    torch.manual_seed(SEED)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(SEED)
    torch.set_float32_matmul_precision('high')
    print_device_info()
    plt.close('all')
 
    def timed_run(fn, label, **kwargs):
        t0 = time.perf_counter()
        fn(**kwargs)
        t1 = time.perf_counter()
        mins, sec = divmod(t1 - t0, 60)
        print(f"[Timing] {label}: {int(mins)}m {sec:.1f}s")
 
    timed_run(run_ugia_f, "UGIA-F (Fixed)")
 

