# SMLM_Lib project: neural network estimators against the Bayes optimum

Scripts for the study of frame-trained neural network estimators in single
molecule localization microscopy, in which the networks are compared with the
matched Bayes estimator, the global maximum likelihood estimator EM-GML and the
unbiased Gaussian information achieving estimator UGIA-F.

All results are reproducible from the seeds set in the scripts.

---

## 1. Generate the datasets

Both generators must be run. Each writes its own copy of the frozen noise
field, i.e. `b_map.txt` and `G_map.txt`, into its own dataset folder, and every
later script reads the maps from the folder it works on. The two copies are
byte identical, since both generators call `build_frozen_noise` with the same
ranges and the same seeds, but both files must exist.

| script | writes to |
|---|---|
| `Generate-Dataset7x7-Random.py` | `Dataset-Random/` |
| `Generate-Dataset7x7.py` | `Dataset-Fixed/` |

`Generate-Dataset7x7-Random.py` also writes `Noise_MeanMaps.tif`, i.e. the
Poisson and Gaussian mean maps of the frozen field.

## 2. Train the networks

A separate network is trained for each emitter number M, all with the same
batch size, the same number of steps and therefore the same number of training
frames. Training reads the frozen noise field from `Dataset-Random/`, so
step 1 must be complete first.

Without a convolutional front end:

- `APL-Training.py`
- `KAN-Training.py`
- `ViT-Training.py`

With a convolutional front end:

- `CNNAPL-Training.py`
- `CNNKAN-Training.py`

## 3. Benchmark on the random dataset

Every frame is an independent estimation problem with M estimates and M
emitters, so the metric is ARMSMD-H, i.e. RMSMD-H computed frame by frame and
averaged over the frames.

- `UGIA-Random.py`
- `EM-GML-Random.py`
- `APL-CNNAPL-Random.py`
- `KAN-CNNKAN-Random.py`
- `ViT-Random.py`

## 4. Benchmark on the fixed dataset

- `UGIA-Fixed.py`
- `EM-GML-Fixed.py`
- `APL-CNNAPL-Fixed.py`
- `KAN-CNNKAN-Fixed.py`
- `ViT-Fixed.py`

## 5. Comparison with the Bayes optimum, M = 2

For two emitters the parameter space is four dimensional, so the posterior can
be integrated by quadrature and the two Bayes estimators can be computed
exactly. These scripts produce the central result of the study.

| script | purpose |
|---|---|
| `Sweep-M2-Separation.py` | ARMSMD-H of every estimator against the emitter separation |
| `Bayes-M2-Quadrature.py` | the labeled MMSE and matched Bayes estimators along the same sweep |
| `Bayes-M2-Validate.py` | verification that no estimator falls below the matched Bayes optimum, on frames drawn from the quadrature prior, and measurement of how closely each estimator agrees with it |

## 6. Stratified analysis

- `Stratified-Random.py` computes and saves the per-frame results of every
  estimator together with the per-frame minimum emitter separation.
- `Stratified-Analysis.py` bins those results by the minimum separation and
  plots the conditional ARMSMD-H of every estimator. Run it after the above.

## 7. Verification, not needed to reproduce the reported numbers

These scripts justify choices made in the benchmark scripts. With the
exception of `GML-Verify-M2.py`, whose result is reported as Fig. 5 through
`Fig.py`, they produce no numbers or images for the paper.

| script | verifies |
|---|---|
| `EM-GML-Test-Random.py` | that one near-true start is not enough and that K = 250 is enough, on the random dataset |
| `EM-GML-Test-Fixed.py` | the same on the fixed dataset |
| `GML-Verify-M2.py` | that multi-start EM attains the global maximizer, by comparison with an exhaustive search over the whole parameter space |
| `profile_vit_scaling.py` | where the training time of the vision transformer is spent |

## 8. Generate the figures for the paper

`Fig.py` draws every figure of the paper from the outputs of the steps above
and writes them to `Fig/`. Run it after steps 1 to 7, since it reads their
results. Only the example estimates of `Fig-3` and `Fig-4` are recomputed, i.e.
the network inference and the UGIA-F draw, whereas the EM-GML estimates are read
from the saved `.npy` files and the two curve figures are re-plotted from the
saved CSV files.

| figure | source |
|---|---|
| `Fig-1-training-frames.png` | six example frames drawn from the prior, generated on the fly |
| `Fig-2-Estimators-vs-Bayes.png` | `Benchmark-Random/Bayes-M2/bayes_m2.csv` from `Bayes-M2-Quadrature.py` |
| `Fig-3-Accuracy-Random.png` | one Dataset-Random frame, M = 5, from the trained networks and `Benchmark-Random/EM-GML/` |
| `Fig-4-Accuracy-Fixed.png` | the Dataset-Fixed circle, r = 125 nm and M = 5, pooled over N = 25 frames |
| `Fig-5-EM-GML-Verify-M2.png` | `Benchmark-Random/GML-Verify/gml_verify_m2.csv` from `GML-Verify-M2.py` |

## 9. Inference timing

`Infer-Timing.py` measures the per-frame inference time reported in Section 5.1
of the paper. It times the forward pass of the five networks with a discarded
warm-up and a device synchronization around every timed region, so the interval
is real device time and not an early return of an asynchronous call, and it
reports both the single-frame latency and the large-batch throughput. It then
times the multi-start EM that realizes EM-GML on a block of real Dataset-Random
frames and reports the EM-GML per-frame time and the speedup of each network
over it, on the same device. The network timing needs the trained networks of
step 2, and the EM timing also needs `Dataset-Random/`, so run it after those.

| output | contents |
|---|---|
| `Benchmark-Random/Timing/inference_timing.csv` | network latency and throughput per network, M and batch size |
| `Benchmark-Random/Timing/inference_timing_em.csv` | EM-GML per-frame time and throughput per M |

---

## Library

`SMLM_Lib` provides the frame model, the estimators and the quality metrics.
The modules used here are

| module | contents |
|---|---|
| `__init__.py` | package exports |
| `config.py` | camera, point spread function, noise and system configuration |
| `position.py` | emitter sampling and the smooth background field |
| `Gauss2D.py` | frame model, Fisher information, UGIA-F, EM and the log-likelihood |
| `metrics.py` | RMSMD, the partition metrics RMSMD-P and RMSE-P, and RMSMD-H |
| `train_utils.py` | on-the-fly batch generator and the Hungarian loss |
| `APL.py`, `KAN.py`, `ViT.py` | the network architectures |

### Quality metrics

`rmsmd_h` and `rmsmd_h_per_frame` compute the error under the Hungarian
assignment, i.e. under the correspondence between estimated and true locations
of maximum likelihood, and they require the two sets to be of equal size. They
are the metric of this study, in which the locations are estimated from a
single frame.

`rmsmd_p` with `partition_x` computes the error under the partition of Sun
(2022), which applies when the number of estimates differs from the number of
emitters, as in a reconstructed image in which the estimates of many frames are
pooled and one emitter carries many estimates. That case does not arise here.

---

## Notes on running

**Speed.** The multi-start EM of `EM-GML-*.py`, `Sweep-M2-Separation.py`,
`Stratified-Random.py` and `Bayes-M2-*.py` evaluates `BATCH_STARTS` starts in
one call rather than one at a time. A data frame is 7 x 7 pixels, so a single
start leaves the graphics processor far below its capacity and the run is
dominated by kernel launch overhead. Raising `BATCH_STARTS` uses the device
more fully at the cost of memory and does not change the result.

**Figures only.** `EM-GML-Random.py` and `EM-GML-Fixed.py` save the estimated
locations alongside the figures. Setting `PLOT_ONLY = True` at the top of
either script skips the expectation maximization entirely and redraws the
figures from the saved locations, with the metric in the legend recomputed so
that it remains exact.

**Logs.** Every benchmark script writes a timestamped log into its
`Benchmark-Random/` or `Benchmark-Fixed/` folder, so a rerun never overwrites
an earlier record. Use the newest timestamp per script.

**Path.** Each script sets `ROOT` to the directory containing `SMLM_Lib`.
Change it to match the installation.

---

## References

[1] Y. Sun, "Localization precision of stochastic optical localization
nanoscopy using single frames," J. Biomed. Optics, 18(11), 111418-14 (2013).

[2] Y. Sun, Y. Zeng, W. Yen, J. M. Tarbell and B. M. Fu, "Expectation
maximization can outperform Cramer-Rao lower bound in stochastic optical
localization nanoscopy," Quantitative Bioimaging Conf. (QBI2014) (2014).

[3] Y. Sun, "Root mean square minimum distance as a quality metric for
stochastic optical localization nanoscopy images," Sci. Reports, 8(1), 17211
(2018).

[4] Y. Sun and Y. Guan, "Effect of unknown emitter intensities on localization
accuracy in stochastic optical localization nanoscopy using single frames,"
JOSA A, 38(12), 1830-1840 (2021).

[5] Y. Sun, "Partition of estimated locations: an approach to accurate quality
metrics for stochastic optical localization nanoscopy," JOSA A, 39(12),
2307-2315 (2022).

[6] Y. Sun, "Markov chain models of emitter activations in single molecule
localization microscopy," Optics Express, 32(19), 33779-33794 (2024).

[7] Y. Sun, "Asymptotic efficiency of the global maximum-likelihood estimator
in multi-emitter localization microscopy," arXiv: 2607.28985 (2026).

## Contact

Yi Sun, Electrical Engineering Department, Nanoscopy Laboratory, The City
College of City University of New York, New York, NY 10031, USA.
E-mail: ysun@ccny.cuny.edu
