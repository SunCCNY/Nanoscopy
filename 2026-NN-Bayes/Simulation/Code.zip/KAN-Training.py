"""
KAN-Training.py

Training and evaluation of the TRUE KAN localizer
(Liu et al. 2024, B-spline edges) for SMLM
emitter position estimation.

Uses permutation-invariant Hungarian matching loss to eliminate
the emitter ordering ambiguity — fixes the blob artifact seen
when evaluating on fixed circle geometries.

Yi Sun
"""

import sys
import os
import numpy as np
import math
import time
import torch
import matplotlib.pyplot as plt

ROOT = r"K:\Research_KB"
sys.path.append(ROOT)

from SMLM_Lib import Camera, Gaussian2DPSF, Noise
from SMLM_Lib import show_frame_with_localizations, print_device_info
from SMLM_Lib.KAN import KANLocalizer
from SMLM_Lib.train_utils import generate_batch, hungarian_loss
from SMLM_Lib.metrics import rmsmd_per_frame
from SMLM_Lib.position import sample_emitters_batch


# ----------------------------------------------------------------------
# Console logging: duplicate all stdout to a log file in the model folder
# ----------------------------------------------------------------------
class _Tee:
    """Write everything printed to the console AND to a log file."""
    def __init__(self, *streams):
        self.streams = streams
    def write(self, data):
        for s in self.streams:
            try:
                s.write(data)
            except UnicodeEncodeError:
                s.write(data.encode("ascii", "replace").decode("ascii"))
            s.flush()
    def flush(self):
        for s in self.streams:
            s.flush()


# ======================================================================
# Global system configuration
# ======================================================================

camera = Camera(Kx=7, Ky=7, Dx=100.0, Dy=100.0, Dt=0.01)
psf    = Gaussian2DPSF(sigma=108.81)

# Load the frozen non-uniform noise field saved with the dataset so the
# network trains on the identical b_k and G_k that every estimator is
# scored against. Dataset-Fixed and Dataset-Random carry the same field.
Data_folder = "Dataset-Random"
b_map = torch.tensor(np.loadtxt(os.path.join(Data_folder, "b_map.txt"),
                                dtype=np.float32))
G_map = torch.tensor(np.loadtxt(os.path.join(Data_folder, "G_map.txt"),
                                dtype=np.float32))
noise = Noise(b=b_map, mu=G_map, G=G_map)   # mu_k = G_k

Im0 = 300000.0


# ======================================================================
# Training
# ======================================================================

def train_kan(M, num_steps=40000, batch_size=256, lr=1e-3, val_interval=500):
    """Train the KAN localizer for M emitters.

    Uses Hungarian matching loss — fully permutation-invariant.
    generate_batch returns y_nm of shape (B, M, 2) — unsorted.
    """
    device    = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model     = KANLocalizer(Kx=camera.Kx, Ky=camera.Ky, M=M).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=num_steps, eta_min=1e-5
    )

    x_val, y_val_nm = generate_batch(1024, M, camera, psf, noise, Im0)
    x_val    = x_val.to(device)
    y_val_nm = y_val_nm.to(device)          # (1024, M, 2)

    print(f"\n=== KAN Training  M={M} ===")

    prev_rmsmd = None
    prev_step  = 0
    history    = []

    for step in range(1, num_steps + 1):
        model.train()
        x, y_nm = generate_batch(batch_size, M, camera, psf, noise, Im0)
        x    = x.to(device)
        y_nm = y_nm.to(device)              # (B, M, 2)

        pred_nm = model(x)                  # (B, M, 2)
        loss    = hungarian_loss(pred_nm, y_nm)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        scheduler.step()

        if step % 200 == 0:
            lr_now = scheduler.get_last_lr()[0]
            print(f"  Step {step:5d}  Train Loss = {loss.item():.4f} nm²  "
                  f"lr = {lr_now:.2e}")

        if step % val_interval == 0:
            model.eval()
            with torch.no_grad():
                pred_val  = model(x_val)
                val_loss  = hungarian_loss(pred_val, y_val_nm)
                _, D2     = rmsmd_per_frame(pred_val, y_val_nm)
                rmsmd_ave = math.sqrt(D2.mean().item())
            if prev_rmsmd is not None:
                slope = (rmsmd_ave - prev_rmsmd) / (step - prev_step) * 1000.0
                slope_str = f"  (Δ = {slope:+.2f} nm/1k)"
            else:
                slope_str = ""
            prev_rmsmd, prev_step = rmsmd_ave, step
            history.append((step, val_loss.item(), rmsmd_ave,
                            scheduler.get_last_lr()[0]))
            print(f"  [Val] Step {step:5d}  Train Loss = {val_loss.item():.4f} nm²  "
                  f"ARMSMD = {rmsmd_ave:.2f} nm{slope_str}")

    return model, history


# ======================================================================
# Testing
# ======================================================================

def test_kan(model, M, num_samples=5000):
    device = next(model.parameters()).device
    model.eval()

    x_test, y_test = generate_batch(num_samples, M, camera, psf, noise, Im0)
    x_test = x_test.to(device)
    y_test = y_test.to(device)

    with torch.no_grad():
        pred_nm   = model(x_test)
        test_loss = hungarian_loss(pred_nm, y_test)
        _, D2     = rmsmd_per_frame(pred_nm, y_test)
        rmsmd_ave = math.sqrt(D2.mean().item())

    print(f"[Test] M={M}  Train Loss = {test_loss.item():.4f} nm²  ARMSMD = {rmsmd_ave:.2f} nm")
    return test_loss.item(), rmsmd_ave


# ======================================================================
# Main
# ======================================================================

if __name__ == "__main__":
    torch.manual_seed(0)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(0)

    # Enable TF32 for ~2x speedup on RTX 30xx/40xx GPUs
    torch.set_float32_matmul_precision('high')

    print("\n=== KAN Training Setup ===")
    print_device_info()

    out_dir = "KAN-Trained"
    os.makedirs(out_dir, exist_ok=True)

    _log_path = os.path.join(
        out_dir, f"training_log_{time.strftime('%Y%m%d_%H%M%S')}.txt")
    _logf = open(_log_path, "w", encoding="utf-8")
    _orig_stdout = sys.stdout
    while type(_orig_stdout).__name__ == "_Tee":  # unwrap a leftover Tee
        _orig_stdout = _orig_stdout.streams[0]
    sys.stdout = _Tee(_orig_stdout, _logf)
    print(f"[Log] Writing training log -> {_log_path}")

    train_times = {}

    for M in [1, 2, 3, 4, 5]:
        t_start = time.perf_counter()
        model, history = train_kan(M)
        t_end = time.perf_counter()

        elapsed   = t_end - t_start
        mins, sec = divmod(elapsed, 60)
        train_times[M] = elapsed
        print(f"[Timing] M={M}  Training time = {int(mins)}m {sec:.1f}s")

        test_kan(model, M)

        device     = next(model.parameters()).device
        true_xy_nm = sample_emitters_batch(1, M, camera, margin_px=2).squeeze(0)
        show_frame_with_localizations(model, M, camera, psf, noise, true_xy_nm, Im0)

        path = os.path.join(out_dir, f"kan_localizer_M={M}.pth")
        torch.save(model.state_dict(), path)
        print(f"Saved -> {path}")
        _curve = os.path.join(out_dir, f"training_curve_M={M}.csv")
        with open(_curve, "w") as _cf:
            print("step,train_loss_nm2,armsmd_nm,lr", file=_cf)
            for _s, _tl, _ar, _lr in history:
                print(f"{_s},{_tl:.6f},{_ar:.6f},{_lr:.3e}", file=_cf)
        print(f"Saved -> {_curve}")

    print("\n=== Training Time Summary (KAN) ===")
    print(f"  {'M':<6} {'Time':>10}")
    for M, t in train_times.items():
        mins, sec = divmod(t, 60)
        print(f"  M={M:<4} {int(mins)}m {sec:.1f}s")

    plt.close('all')
    sys.stdout = _orig_stdout
    _logf.close()

