"""
EM-LML-Random.py

EM from a single start drawn within +-NEAR_HALF nm of the true positions on
Dataset-Random. A single start in a wide region about the true positions
converges to a local maximum likelihood (LML) point rather than to the global
maximizer, so this is an LML estimator, not the global ML estimator EM-GML.
Both Newton and Gradient ascent are run.

Yi Sun
"""

import sys
import os
import time

# ----------------------------------------------------------------------
# Console logging: duplicate all stdout to a log file in the Benchmark folder
# ----------------------------------------------------------------------
class _Tee:
    """Write everything printed to the console AND to a log file."""
    def __init__(self, *streams):
        self.streams = streams
    def write(self, data):
        for s in self.streams:
            try:
                s.write(data)
            except UnicodeEncodeError:
                s.write(data.encode("ascii", "replace").decode("ascii"))
            s.flush()
    def flush(self):
        for s in self.streams:
            s.flush()

import numpy as np
import torch
import tifffile
import matplotlib.pyplot as plt
import matplotlib.patches as patches

ROOT = r"K:\Research_KB"   # <- change to your actual path
sys.path.append(ROOT)

from SMLM_Lib import (
    SystemConfig,
    EmitterData,
    Gaussian2DPSF,
    Camera,
    Noise,
    gauss2d_ugia_f_batch_torch,
    gauss2d_em_batch_torch,
    print_device_info,
)
from SMLM_Lib.metrics import rmsmd, partition_x, rmsmd_p
from SMLM_Lib.position import sample_emitters_batch


# ============ configuration ============
N           = 1000
Data_folder = "Dataset-Random"

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

camera = Camera(Kx=7, Ky=7, Dx=100.0, Dy=100.0, Dt=0.01)
Kx, Ky = camera.Kx, camera.Ky
Dx, Dy = camera.Dx, camera.Dy

psf = Gaussian2DPSF(sigma=108.81)

# Load the frozen non-uniform noise field saved with the dataset, so the FIM
# and EM-LML likelihood consume the identical b_k and G_k that generated the frames.
b_map = torch.tensor(np.loadtxt(os.path.join(Data_folder, "b_map.txt"),
                                dtype=np.float32), device=device)
G_map = torch.tensor(np.loadtxt(os.path.join(Data_folder, "G_map.txt"),
                                dtype=np.float32), device=device)
noise = Noise(b=b_map, mu=G_map, G=G_map)   # mu_k = G_k

Im0 = 300000.0   # photons / s


# ============ helpers ============

def load_frames(M):
    path = os.path.join(Data_folder, f"M={M}_Frames.tif")
    arr  = tifffile.imread(path).astype(np.float32)
    return torch.tensor(arr, dtype=torch.float32, device=device)


def load_xy_all(M):
    path = os.path.join(Data_folder, f"M={M}_xy.txt")
    arr  = np.loadtxt(path, dtype=np.float32, skiprows=1)
    return torch.tensor(arr, dtype=torch.float32, device=device).reshape(N, M, 2)


def armsmd(D2_sum, n_frames):
    return float(np.sqrt(D2_sum / n_frames))


def armsmd_p_val(D2p_sum, n_frames):
    return float(np.sqrt(D2p_sum / n_frames))


def per_frame_rmsmd_p(xy_est_n, xy_true_n, M):
    Kai = torch.ones(M, dtype=torch.long)
    Xp, Ki, _ = partition_x(xy_true_n.cpu(), xy_est_n.cpu(), Kai)
    _, D2p_n  = rmsmd_p(xy_true_n.cpu(), Xp, Ki)
    return D2p_n.item()


def show_frame1(xy_est_n, xy_true_n, label_est, armsmd_val, armsmd_p_value, outfile):
    fig, ax = plt.subplots(figsize=(4, 4))
    ax.imshow(np.zeros((Ky, Kx), dtype=np.float32), cmap="gray", origin="upper")
    ax.set_xlim(-0.5, Kx - 0.5); ax.set_ylim(Ky - 0.5, -0.5)
    ax.set_aspect("equal"); ax.axis("off")
    ax.scatter(xy_est_n[:, 0] / Dx - 0.5, xy_est_n[:, 1] / Dy - 0.5,
               c="white", s=10, zorder=5,
               label=f"{label_est}  ARMSMD-P = {armsmd_p_value:.2f} nm")
    ax.scatter(xy_true_n[:, 0] / Dx - 0.5, xy_true_n[:, 1] / Dy - 0.5,
               c="red", s=10, zorder=5, label="Ground Truth")
    ax.legend(loc="upper left", framealpha=1.0, labelcolor="white",
              frameon=True, edgecolor="white", facecolor="none", fontsize=9)
    os.makedirs(os.path.dirname(outfile) or '.', exist_ok=True)
    fig.savefig(outfile, dpi=150, bbox_inches="tight")
    plt.show(block=False); plt.close(fig)


# ============ benchmark ============

NEAR_HALF = 100.0   # nm; init within +-NEAR_HALF of the true position. A single
                    # start in this wide region converges to a local ML point.

def run_em_lml(GN='N'):
    """EM from a single wide start -> converges to a local ML (LML) point.

    A single start drawn within +-NEAR_HALF nm of the true positions converges
    to a local maximum of the likelihood rather than to the global maximizer,
    so this is an LML estimator, not the global ML estimator EM-GML.
    """
    method = 'Gradient' if GN == 'G' else 'Newton'
    tag    = 'G' if GN == 'G' else 'N'
    label  = f"EM-LML ({tag})"   # short label so the legend fits the figure
    print(f"\n=== EM-LML Benchmark (Random, {method} ascent, +-{NEAR_HALF:.0f} nm init) ===")
    outdir = "Benchmark-Random/EM-LML"
    os.makedirs(outdir, exist_ok=True)
    for M in range(1, 6):
        frames_all = load_frames(M)
        xy_all     = load_xy_all(M)
        Im_tensor  = torch.full((1, M), Im0, dtype=torch.float32, device=device)
        emitter = EmitterData(xy=xy_all[0:1], Im=Im_tensor)
        system  = SystemConfig(emitter=emitter, psf=psf, camera=camera, noise=noise)
        # single wide start: per-frame true positions + uniform jitter in +-NEAR_HALF nm
        xyi_all = xy_all.clone() + NEAR_HALF * (2 * torch.rand(N, M, 2, device=device) - 1)
        n_iter  = 300
        with torch.no_grad():
            xy_est_all = gauss2d_em_batch_torch(frames_all, xyi_all, system, GN=GN, n_iter=n_iter)
        D2_sum = 0.0; D2p_sum = 0.0
        for n in range(N):
            _, D2_n = rmsmd(xy_est_all[n], xy_all[n]); D2_sum += D2_n.item()
            D2p_sum += per_frame_rmsmd_p(xy_est_all[n], xy_all[n], M)
        armsmd_val = armsmd(D2_sum, N); armsmd_p_value = armsmd_p_val(D2p_sum, N)
        print(f"M={M}  EM-LML ({method})  ARMSMD = {armsmd_val:.2f} nm  ARMSMD-P = {armsmd_p_value:.2f} nm")
        outfile = os.path.join(outdir, f"M={M}_EM-LML_{tag}.png")
        show_frame1(xy_est_all[0].cpu().numpy(), xy_all[0].cpu().numpy(),
                    label, armsmd_val, armsmd_p_value, outfile)


# ======================================================================
# Main
# ======================================================================

if __name__ == "__main__":
    # ---- start run log (saved in the Benchmark folder) ----
    import atexit
    os.makedirs("Benchmark-Random", exist_ok=True)
    _log_path = os.path.join(
        "Benchmark-Random", f"inference_log_EM-LML_Random_{time.strftime('%Y%m%d_%H%M%S')}.txt")
    _logf = open(_log_path, "w", encoding="utf-8")
    _orig_stdout = sys.stdout
    while type(_orig_stdout).__name__ == "_Tee":  # unwrap a leftover Tee
        _orig_stdout = _orig_stdout.streams[0]
    sys.stdout = _Tee(_orig_stdout, _logf)

    @atexit.register
    def _close_log(_o=_orig_stdout, _f=_logf):
        sys.stdout = _o
        _f.close()

    print(f"[Log] Writing run log -> {_log_path}")
    torch.set_float32_matmul_precision('high')
    print_device_info()
    plt.close('all')

    def timed_run(fn, label, **kwargs):
        t0 = time.perf_counter()
        fn(**kwargs)
        t1 = time.perf_counter()
        mins, sec = divmod(t1 - t0, 60)
        print(f"[Timing] {label}: {int(mins)}m {sec:.1f}s")

    timed_run(run_em_lml, "EM-LML (Random, Newton)",   GN='N')
    timed_run(run_em_lml, "EM-LML (Random, Gradient)", GN='G')
