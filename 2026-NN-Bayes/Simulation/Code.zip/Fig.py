"""
Fig.py

Generate the figures for the NN-Bayes paper from the simulation results.

Run this script from the ``simulation`` folder. All figures are written to
``simulation/Fig/``. Frame generation uses SMLM_Lib, i.e. the same library
that produced the datasets, so the figures are consistent with the pipeline.

Figures
-------
Fig-1-training-frames.png
    A 2 x 3 panel of six example training frames, one for each emitter number
    M = 0, 1, 2 on the top row and M = 3, 4, 5 on the bottom row. M = 0 is a
    pure-noise frame that shows the frozen non-uniform noise field with no
    emitter. On the other frames the true emitter positions are shown as red
    dots. The emitters are drawn from the training prior, i.e. placed
    independently and uniformly in the central 3x3 pixel block. A single
    colorbar spans both rows.

Fig-2-Estimators-vs-Bayes.png
    ARMSMD-H of every estimator against the emitter separation d for M = 2,
    on log-log axes. Re-plotted from the saved sweep bayes_m2.csv produced by
    Bayes-M2-Quadrature.py, i.e. no benchmark is recomputed here. The Bayes
    optimum, EM-GML, UGIA-F and the five networks are shown. MMSE is dropped
    since it is degenerate and analysed separately in the paper. The in-figure
    title is omitted because the caption supplies it.

Fig-3-Accuracy-Random.png
    Example estimated positions on one Dataset-Random frame with M = 5, one
    panel per estimator in a 2 x 4 layout. Top row APL, CNN-APL, KAN, CNN-KAN;
    bottom row ViT, EM-GML, UGIA-F centered with a blank slot at each side. On
    each panel the white dots are the estimated positions with the estimator
    name and the per-frame RMSMD-H in the legend, and the red dots are the
    ground truth. The frame-0 estimates are recomputed from the trained models
    and the dataset, i.e. the network inference and the UGIA-F draw, while the
    EM-GML estimate is read from its saved M=5_xy_est.npy when present.

Fig-4-Accuracy-Fixed.png
    Example estimated positions on the Dataset-Fixed circle constellation with
    d = 125 nm and M = 5, one panel per estimator in the same 2 x 4 layout as
    Fig-3. All N = 25 estimates of the constellation are pooled, i.e. the white
    dots are the N*M = 125 estimated positions, with the estimator name and the
    ARMSMD-H over the 25 frames in the legend, and the red dots are the 5 circle
    positions common to all frames. Network and UGIA-F estimates are recomputed;
    the EM-GML estimate is read from its saved d=125_M=5_xy_est.npy when present.

Fig-5-EM-GML-Verify-M2.png
    Verification that the multi-start EM benchmark EM-GML reaches the global
    maximum of the likelihood for M = 2, re-plotted from the saved
    gml_verify_m2.csv produced by GML-Verify-M2.py, i.e. nothing is recomputed
    here. The left axis is the percentage of frames on which multi-start EM
    reaches the exhaustive grid-search reference against the number of starts K,
    and the right axis is the mean log-likelihood shortfall below that reference
    on a log scale. The in-figure title is omitted because the caption supplies
    it.

More figures will be added below as further panels are selected from the
simulation subfolders.
"""

import os
import sys
import csv

import numpy as np
import torch
import tifffile
import matplotlib.pyplot as plt

# SMLM_Lib location on the research workstation (same as the other scripts).
sys.path.append(r"K:\Research_KB")

from SMLM_Lib import (
    Camera,
    Gaussian2DPSF,
    Noise,
    EmitterData,
    SystemConfig,
    gauss2d_frame_torch,
    gauss2d_ugia_f_batch_torch,
    gauss2d_em_batch_torch,
)
from SMLM_Lib.position import sample_emitters_batch, background_cloud
from SMLM_Lib.Gauss2D import gauss2d_loglike_batch_torch
from SMLM_Lib.metrics import rmsmd_h_per_frame
from SMLM_Lib.APL import APLLocalizer, CNNAPLLocalizer
from SMLM_Lib.KAN import KANLocalizer, CNNKANLocalizer
from SMLM_Lib.ViT import ViTLocalizer


# ============================================================
# Output folder and physical configuration (matches the datasets)
# ============================================================

FIG_DIR = "Fig"

CAMERA = Camera(Kx=7, Ky=7, Dx=100.0, Dy=100.0, Dt=0.01)   # FOV 700 x 700 nm
PSF    = Gaussian2DPSF(sigma=108.81)                        # nm
IM0    = 300000.0                                           # photons/s per emitter


# ============================================================
# Frozen non-uniform noise field (same construction as
# Generate-Dataset7x7.build_frozen_noise, without saving to disk)
# ============================================================

def build_frozen_noise(camera, b_min=4.0, b_max=6.0, corr_px=2.0,
                       g_min=2.0, g_max=4.0, seed_b=0, seed_g=1, device=None):
    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    b_map = background_cloud(camera, b_min, b_max, corr_px=corr_px,
                             seed=seed_b, device=device, dtype=torch.float32)

    g_gen = torch.Generator(device="cpu").manual_seed(int(seed_g))
    g_unit = torch.rand(camera.Ky, camera.Kx, generator=g_gen, dtype=torch.float32)
    G_map = (g_min + (g_max - g_min) * g_unit).to(device=device)   # G_k = mu_k
    mu_map = G_map.clone()

    return Noise(b=b_map, mu=mu_map, G=G_map)


# ============================================================
# Shared frame-panel plotter
# ============================================================

def _plot_frame_panel(frames, xys, Ms, fname, save=True):
    """Plot a 2 x 3 panel of frames (M = 0..5) with emitter dots overlaid.

    The first frame is a pure-noise frame, i.e. M = 0, which shows the frozen
    non-uniform noise field with no emitter. A single colorbar spans both rows.
    """
    vmin = min(float(f.min()) for f in frames)
    vmax = max(float(f.max()) for f in frames)

    fig, axes = plt.subplots(2, 3, figsize=(7.4, 4.7),
                             gridspec_kw=dict(wspace=0.05, hspace=0.05))

    im = None
    for ax, frame, xy in zip(axes.ravel(), frames, xys):
        im = ax.imshow(frame, cmap="gray", origin="upper", vmin=vmin, vmax=vmax)
        if len(xy):   # M = 0 has no emitter, so no dot
            # nm -> pixel-centre coordinates for the overlay (ImageJ convention).
            x_pix = xy[:, 0] / CAMERA.Dx - 0.5
            y_pix = xy[:, 1] / CAMERA.Dy - 0.5
            ax.scatter(x_pix, y_pix, s=14, c="red", edgecolors="white", linewidths=0.4)
        ax.set_xticks([])
        ax.set_yticks([])

    # One colorbar spanning both rows of frames at the right.
    cbar = fig.colorbar(im, ax=axes, fraction=0.025, pad=0.02)
    cbar.set_label("Photon count", fontsize=9)

    if save:
        os.makedirs(FIG_DIR, exist_ok=True)
        path = os.path.join(FIG_DIR, fname)
        fig.savefig(path, dpi=300, bbox_inches="tight")
        print(f"  Saved figure -> {path}")
    plt.close(fig)


# ============================================================
# Fig. 1 — six example training frames, M = 0..5 (2 x 3 panel)
# ============================================================

def make_fig1_training_frames(seed=0, save=True):
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    noise = build_frozen_noise(CAMERA)
    Ms = [0, 1, 2, 3, 4, 5]          # M=0 is a pure-noise frame (no emitter)

    frames, xys = [], []
    for M in Ms:
        if M == 0:
            xy = torch.zeros(1, 0, 2)                                   # no emitter
        else:
            xy = sample_emitters_batch(1, M, CAMERA, margin_px=2)      # (1, M, 2) nm
        Im = torch.full((1, M), float(IM0), dtype=torch.float32, device=xy.device)
        system = SystemConfig(emitter=EmitterData(xy=xy, Im=Im),
                              psf=PSF, camera=CAMERA, noise=noise)
        with torch.no_grad():
            frame = gauss2d_frame_torch(system)[0].cpu().numpy()        # (Ky, Kx)
        frames.append(frame)
        xys.append(xy[0].cpu().numpy())

    _plot_frame_panel(frames, xys, Ms, "Fig-1-training-frames.png", save=save)


# ============================================================
# Fig. 2 — estimators versus the Bayes optimum, M = 2
# ============================================================

# Sweep produced by Bayes-M2-Quadrature.py (relative to the simulation folder).
FIG2_CSV = os.path.join("Benchmark-Random", "Bayes-M2", "bayes_m2.csv")

# Estimators drawn, in legend order. MMSE and EM-Near-1 are excluded from all
# paper figures.
FIG2_ESTIMATORS = ["Bayes-M", "EM-GML", "UGIA-F",
                   "APL", "CNN-APL", "KAN", "CNN-KAN", "ViT"]

# Curve styling, carried over from Bayes-M2-Quadrature.py so the figure matches
# the pipeline. Benchmarks are solid/dashed, the five networks are dotted.
FIG2_STYLE = {
    "UGIA-F":  dict(color="k",          ls="--", marker="s", lw=2.0),
    "EM-GML":  dict(color="crimson",    ls="-",  marker="o", lw=2.2),
    "Bayes-M": dict(color="navy",       ls="-",  marker="P", lw=2.6),
    "APL":     dict(color="tab:blue",   ls=":",  marker="^", lw=1.3),
    "CNN-APL": dict(color="tab:cyan",   ls=":",  marker="^", lw=1.3),
    "KAN":     dict(color="tab:green",  ls=":",  marker="D", lw=1.3),
    "CNN-KAN": dict(color="tab:olive",  ls=":",  marker="D", lw=1.3),
    "ViT":     dict(color="tab:purple", ls=":",  marker="*", lw=1.5),
}


def _read_csv_columns(path):
    """Read a headed numeric CSV into a dict of column name -> float array."""
    with open(path, newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        cols = {h: [] for h in header}
        for row in reader:
            for h, v in zip(header, row):
                cols[h].append(v)
    return {h: np.asarray(vals, dtype=float) for h, vals in cols.items()}


def make_fig2_estimators_vs_bayes(csv_path=FIG2_CSV, save=True):
    if not os.path.exists(csv_path):
        print(f"  [Fig 2] sweep not found -> {csv_path}\n"
              f"          run Bayes-M2-Quadrature.py first.")
        return

    cols = _read_csv_columns(csv_path)
    d = cols["d_nm"]

    fig, ax = plt.subplots(figsize=(7.2, 5.0))
    for e in FIG2_ESTIMATORS:
        ax.plot(d, cols[e], label=e, markersize=6, **FIG2_STYLE[e])
    ax.set_xlabel("Emitter separation  $d$  (nm)")
    ax.set_ylabel("ARMSMD-H  (nm)")
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.grid(True, which="both", alpha=0.3)
    ax.legend(fontsize=8, ncol=2)          # no title, the caption supplies it
    fig.tight_layout()

    if save:
        os.makedirs(FIG_DIR, exist_ok=True)
        path = os.path.join(FIG_DIR, "Fig-2-Estimators-vs-Bayes.png")
        fig.savefig(path, dpi=300, bbox_inches="tight")
        print(f"  Saved figure -> {path}")
    plt.close(fig)


# ============================================================
# Fig. 3 — example estimated positions, Dataset-Random, M = 5
# ============================================================

FIG3_M      = 5
FIG3_FRAME  = 2                        # which Dataset-Random frame to display
FIG3_DATA   = "Dataset-Random"
FIG3_EMGML_NPY = os.path.join("Benchmark-Random", "EM-GML", f"M={FIG3_M}_xy_est.npy")
FIG3_DOT_SIZE = 14                     # same as Fig-1

# name -> (weights folder, filename pattern, localizer class)
FIG3_NETS = {
    "APL":     ("APL-Trained",     "apl_localizer_M={}.pth",    APLLocalizer),
    "CNN-APL": ("CNN-APL-Trained", "cnnapl_localizer_M={}.pth", CNNAPLLocalizer),
    "KAN":     ("KAN-Trained",     "kan_localizer_M={}.pth",    KANLocalizer),
    "CNN-KAN": ("CNN-KAN-Trained", "cnnkan_localizer_M={}.pth", CNNKANLocalizer),
    "ViT":     ("ViT-Trained",     "vit_localizer_M={}.pth",    ViTLocalizer),
}
# EM-GML multi-start settings, matching EM-GML-Random.py.
FIG3_EM = dict(K=250, WIDE=100.0, N_ITER=300, GN="N", BATCH_STARTS=5, SEED=0)

# Panel order: top row then bottom row (shared by Fig-3 and Fig-4).
FIG3_ORDER = ["APL", "CNN-APL", "KAN", "CNN-KAN", "ViT", "UGIA-F", "EM-GML"]


def _fig3_load_noise(device):
    b = torch.tensor(np.loadtxt(os.path.join(FIG3_DATA, "b_map.txt"),
                                dtype=np.float32), device=device)
    G = torch.tensor(np.loadtxt(os.path.join(FIG3_DATA, "G_map.txt"),
                                dtype=np.float32), device=device)
    return Noise(b=b, mu=G, G=G)       # mu_k = G_k


def _em_gml_multistart(frames, centers, noise, device, M):
    """Multi-start EM-GML over `frames` (N, Ky, Kx), jitter drawn around
    `centers` (N, M, 2). Returns (N, M, 2). Matches EM-GML-Random/Fixed.py."""
    N = frames.shape[0]
    gen = torch.Generator(device=device).manual_seed(FIG3_EM["SEED"])
    Im = torch.full((1, M), float(IM0), dtype=torch.float32, device=device)
    system = SystemConfig(emitter=EmitterData(xy=torch.zeros(1, M, 2, device=device), Im=Im),
                          psf=PSF, camera=CAMERA, noise=noise)
    best_ll = torch.full((N,), float("-inf"), device=device)
    best_xy = torch.zeros(N, M, 2, device=device)
    done = 0
    while done < FIG3_EM["K"]:
        S = min(FIG3_EM["BATCH_STARTS"], FIG3_EM["K"] - done)
        jitter = FIG3_EM["WIDE"] * (2 * torch.rand(S, N, M, 2, device=device, generator=gen) - 1)
        xyi = (centers.unsqueeze(0) + jitter).reshape(S * N, M, 2)
        frep = frames.repeat(S, 1, 1)
        with torch.no_grad():
            xy_s = gauss2d_em_batch_torch(frep, xyi, system,
                                          GN=FIG3_EM["GN"], n_iter=FIG3_EM["N_ITER"])
            ll_s = gauss2d_loglike_batch_torch(frep, xy_s, system)
        ll_s = ll_s.reshape(S, N)
        xy_s = xy_s.reshape(S, N, M, 2)
        ll_max, idx = ll_s.max(dim=0)
        xy_max = xy_s[idx, torch.arange(N, device=device)]
        better = ll_max > best_ll
        best_ll = torch.where(better, ll_max, best_ll)
        best_xy = torch.where(better.view(N, 1, 1), xy_max, best_xy)
        done += S
    return best_xy


def _fig3_gather():
    """Compute the frame-FIG3_FRAME estimate of every estimator for M = FIG3_M.

    Returns
    -------
    results  : dict name -> (est_xy (M,2) numpy, per-frame RMSMD-H)
    true_xy  : (M,2) numpy ground truth of the displayed frame
    """
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    M = FIG3_M

    frames = torch.tensor(
        tifffile.imread(os.path.join(FIG3_DATA, f"M={M}_Frames.tif")).astype(np.float32),
        device=device)                                             # (N, Ky, Kx)
    xy_all = torch.tensor(
        np.loadtxt(os.path.join(FIG3_DATA, f"M={M}_xy.txt"), dtype=np.float32, skiprows=1),
        device=device).reshape(-1, M, 2)                           # (N, M, 2)
    N = xy_all.shape[0]
    noise = _fig3_load_noise(device)

    true = xy_all[FIG3_FRAME]                                      # (M, 2)
    frame0 = frames[FIG3_FRAME:FIG3_FRAME + 1]                     # (1, Ky, Kx)

    def rmsmdh(est):
        D, _ = rmsmd_h_per_frame(est.view(1, M, 2), true.view(1, M, 2))
        return float(D[0].item())

    results = {}

    # --- networks (deterministic inference on the displayed frame) ---
    x0 = frame0.view(1, -1)
    x0 = x0 / (x0.amax(dim=1, keepdim=True) + 1e-8)
    for name, (folder, pat, cls) in FIG3_NETS.items():
        model = cls(Kx=CAMERA.Kx, Ky=CAMERA.Ky, M=M).to(device)
        model.load_state_dict(
            torch.load(os.path.join(folder, pat.format(M)), map_location=device))
        model.eval()
        with torch.no_grad():
            est = model(x0).view(M, 2)
        results[name] = (est.cpu().numpy(), rmsmdh(est))
        del model

    # --- UGIA-F (seeded Gaussian draw of Eq. (33)) ---
    torch.manual_seed(FIG3_EM["SEED"])
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(FIG3_EM["SEED"])
    with torch.no_grad():
        xyF = gauss2d_ugia_f_batch_torch(xy_all, IM0, PSF, CAMERA, noise, ImType="KI")
    estF = xyF[FIG3_FRAME]
    results["UGIA-F"] = (estF.cpu().numpy(), rmsmdh(estF))

    # --- EM-GML (read the saved estimate if present, else recompute) ---
    if os.path.exists(FIG3_EMGML_NPY):
        emxy = torch.tensor(np.load(FIG3_EMGML_NPY), dtype=torch.float32,
                            device=device).reshape(N, M, 2)
        estE = emxy[FIG3_FRAME]
    else:
        print(f"  [Fig 3] {FIG3_EMGML_NPY} not found -> recomputing EM-GML for the frame.")
        estE = _em_gml_multistart(frame0, true.view(1, M, 2), noise, device, M)[0]
    results["EM-GML"] = (estE.cpu().numpy(), rmsmdh(estE))

    return results, true.cpu().numpy()


def _plot_estimate_panel(ordered, true_xy, fname, metric_label="RMSMD-H", save=True):
    """2 x 4 panel of estimated positions. ordered = list of (name, est_xy, metric);
    first four fill the top row, the next three are centered on the bottom row.
    `metric_label` names the legend metric (RMSMD-H for one frame, ARMSMD-H pooled)."""
    top, bot = ordered[:4], ordered[4:7]
    Kx, Ky, Dx, Dy = CAMERA.Kx, CAMERA.Ky, CAMERA.Dx, CAMERA.Dy

    fig = plt.figure(figsize=(12.6, 6.3))
    gs = fig.add_gridspec(2, 8, wspace=0.10, hspace=0.10)
    top_slices = [slice(0, 2), slice(2, 4), slice(4, 6), slice(6, 8)]
    bot_slices = [slice(1, 3), slice(3, 5), slice(5, 7)]   # centered under the 4

    def draw(ax, name, est_xy, rm):
        ax.imshow(np.zeros((Ky, Kx), dtype=np.float32),
                  cmap="gray", origin="upper", vmin=0.0, vmax=1.0)
        ax.set_xlim(-0.5, Kx - 0.5)
        ax.set_ylim(Ky - 0.5, -0.5)
        ax.set_aspect("equal")
        ax.axis("off")
        ax.scatter(est_xy[:, 0] / Dx - 0.5, est_xy[:, 1] / Dy - 0.5,
                   c="white", s=FIG3_DOT_SIZE, zorder=5,
                   label=f"{name}  {metric_label} = {rm:.1f} nm")
        ax.scatter(true_xy[:, 0] / Dx - 0.5, true_xy[:, 1] / Dy - 0.5,
                   c="red", s=FIG3_DOT_SIZE, zorder=6, label="Ground Truth")
        ax.legend(loc="upper left", labelcolor="white", frameon=True,
                  edgecolor="white", facecolor="none", framealpha=1.0,
                  fontsize=9, handletextpad=0.3, borderpad=0.3,
                  labelspacing=0.25, handlelength=1.0, borderaxespad=0.3)

    for sl, item in zip(top_slices, top):
        draw(fig.add_subplot(gs[0, sl]), *item)
    for sl, item in zip(bot_slices, bot):
        draw(fig.add_subplot(gs[1, sl]), *item)

    if save:
        os.makedirs(FIG_DIR, exist_ok=True)
        path = os.path.join(FIG_DIR, fname)
        fig.savefig(path, dpi=300, bbox_inches="tight")
        print(f"  Saved figure -> {path}")
    plt.close(fig)


def make_fig3_accuracy_random(save=True):
    if not os.path.isdir(FIG3_DATA):
        print(f"  [Fig 3] dataset folder not found -> {FIG3_DATA}\n"
              f"          run the Dataset-Random generator and benchmarks first.")
        return
    results, true_xy = _fig3_gather()
    ordered = [(name, *results[name]) for name in FIG3_ORDER]
    _plot_estimate_panel(ordered, true_xy, "Fig-3-Accuracy-Random.png", save=save)


# ============================================================
# Fig. 4 — example estimated positions, Dataset-Fixed, d = 125 nm, M = 5
# ============================================================

FIG4_D    = 125                        # circle radius in nm
FIG4_M    = 5
FIG4_DATA = "Dataset-Fixed"
FIG4_UGIA_SEED = 3                     # <-- change this to reseed the UGIA-F draw
FIG4_EMGML_NPY = os.path.join("Benchmark-Fixed", "EM-GML",
                              f"d={FIG4_D}_M={FIG4_M}_xy_est.npy")


def _fig4_load_noise(device):
    b = torch.tensor(np.loadtxt(os.path.join(FIG4_DATA, "b_map.txt"),
                                dtype=np.float32), device=device)
    G = torch.tensor(np.loadtxt(os.path.join(FIG4_DATA, "G_map.txt"),
                                dtype=np.float32), device=device)
    return Noise(b=b, mu=G, G=G)


def _fig4_gather():
    """Pool the N estimates of every estimator for the (d, M) circle constellation.

    Returns
    -------
    results  : dict name -> (est_xy (N*M, 2) numpy pooled over the N frames,
                             ARMSMD-H over the N frames)
    true_xy  : (M, 2) numpy circle positions, common to all N frames
    """
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    d, M = FIG4_D, FIG4_M

    xy_np = np.loadtxt(os.path.join(FIG4_DATA, f"d={d}_M={M}_xy.txt"), dtype=np.float32)
    if xy_np.ndim == 1:
        xy_np = xy_np.reshape(1, 2)
    true = torch.tensor(xy_np, dtype=torch.float32, device=device)             # (M, 2)
    frames = torch.tensor(
        tifffile.imread(os.path.join(FIG4_DATA, f"d={d}_M={M}_Frames.tif")).astype(np.float32),
        device=device)                                                          # (N, Ky, Kx)
    N = frames.shape[0]
    noise = _fig4_load_noise(device)
    true_all = true.unsqueeze(0).expand(N, M, 2)

    def armsmdh(est_all):
        _, D2h = rmsmd_h_per_frame(est_all, true_all)                           # (N,)
        return float(D2h.mean().item()) ** 0.5

    results = {}

    # --- networks (deterministic inference over all N frames) ---
    x = frames.view(N, -1)
    x = x / (x.amax(dim=1, keepdim=True) + 1e-8)
    for name, (folder, pat, cls) in FIG3_NETS.items():
        model = cls(Kx=CAMERA.Kx, Ky=CAMERA.Ky, M=M).to(device)
        model.load_state_dict(
            torch.load(os.path.join(folder, pat.format(M)), map_location=device))
        model.eval()
        with torch.no_grad():
            est_all = model(x).view(N, M, 2)
        results[name] = (est_all.reshape(-1, 2).cpu().numpy(), armsmdh(est_all))
        del model

    # --- UGIA-F (seeded Gaussian draw of Eq. (33), one per frame) ---
    torch.manual_seed(FIG4_UGIA_SEED)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(FIG4_UGIA_SEED)
    xy_all = true.unsqueeze(0).expand(N, M, 2).contiguous()
    with torch.no_grad():
        xyF = gauss2d_ugia_f_batch_torch(xy_all, IM0, PSF, CAMERA, noise, ImType="KI")
    results["UGIA-F"] = (xyF.reshape(-1, 2).cpu().numpy(), armsmdh(xyF))

    # --- EM-GML (read the saved estimate if present, else recompute) ---
    if os.path.exists(FIG4_EMGML_NPY):
        emxy = torch.tensor(np.load(FIG4_EMGML_NPY), dtype=torch.float32,
                            device=device).reshape(N, M, 2)
    else:
        print(f"  [Fig 4] {FIG4_EMGML_NPY} not found -> recomputing EM-GML.")
        emxy = _em_gml_multistart(frames, xy_all, noise, device, M)
    results["EM-GML"] = (emxy.reshape(-1, 2).cpu().numpy(), armsmdh(emxy))

    return results, true.cpu().numpy()


def make_fig4_accuracy_fixed(save=True):
    xy_path = os.path.join(FIG4_DATA, f"d={FIG4_D}_M={FIG4_M}_xy.txt")
    if not os.path.exists(xy_path):
        print(f"  [Fig 4] dataset not found -> {xy_path}\n"
              f"          run the Dataset-Fixed generator and benchmarks first.")
        return
    results, true_xy = _fig4_gather()
    ordered = [(name, *results[name]) for name in FIG3_ORDER]
    _plot_estimate_panel(ordered, true_xy, "Fig-4-Accuracy-Fixed.png",
                         metric_label="ARMSMD-H", save=save)


# ============================================================
# Fig. 5 — EM-GML verification against exhaustive grid search, M = 2
# ============================================================

# Verification produced by GML-Verify-M2.py (relative to the simulation folder).
FIG5_CSV = os.path.join("Benchmark-Random", "GML-Verify", "gml_verify_m2.csv")


def make_fig5_gml_verify(csv_path=FIG5_CSV, save=True):
    if not os.path.exists(csv_path):
        print(f"  [Fig 5] verification not found -> {csv_path}\n"
              f"          run GML-Verify-M2.py first.")
        return

    cols = _read_csv_columns(csv_path)
    K     = cols["K"]
    frac  = 100.0 * cols["fraction_reached"]
    short = cols["mean_logL_shortfall"]

    fig, ax1 = plt.subplots(figsize=(7.0, 4.6))
    ax1.plot(K, frac, "o-", color="navy", lw=2.0, markersize=6)
    ax1.set_xlabel("Number of starts  $K$")
    ax1.set_ylabel("Frames reaching the global maximum  (%)", color="navy")
    ax1.set_xscale("log")
    ax1.tick_params(axis="y", labelcolor="navy")
    ax1.grid(True, which="both", alpha=0.3)

    ax2 = ax1.twinx()
    ax2.plot(K, short, "s--", color="crimson", lw=1.8, markersize=6)
    ax2.set_ylabel("Mean log-likelihood shortfall", color="crimson")
    ax2.set_yscale("log")
    ax2.tick_params(axis="y", labelcolor="crimson")

    fig.tight_layout()          # no in-figure title, the caption supplies it

    if save:
        os.makedirs(FIG_DIR, exist_ok=True)
        path = os.path.join(FIG_DIR, "Fig-5-EM-GML-Verify-M2.png")
        fig.savefig(path, dpi=300, bbox_inches="tight")
        print(f"  Saved figure -> {path}")
    plt.close(fig)


# ============================================================
# Main
# ============================================================

if __name__ == "__main__":
    make_fig1_training_frames(seed=0)
    make_fig2_estimators_vs_bayes()
    make_fig3_accuracy_random()
    make_fig4_accuracy_fixed()
    make_fig5_gml_verify()
    print("Done.")
