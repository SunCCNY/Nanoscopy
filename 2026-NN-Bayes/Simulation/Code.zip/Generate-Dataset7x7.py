import os
import sys
import time
import torch
import numpy as np
import tifffile
import matplotlib.pyplot as plt

sys.path.append(r"K:\Research_KB")

from SMLM_Lib import (
    SystemConfig,
    EmitterData,
    Gaussian2DPSF,
    Camera,
    Noise,
    gauss2d_frame_torch,
    print_device_info,
)
from SMLM_Lib.position import circle_emitters, background_cloud


# ============================================================
# Non-uniform frozen noise field
# ============================================================

def build_frozen_noise(
    camera,
    b_min=4.0, b_max=6.0, corr_px=2.0,
    g_min=2.0, g_max=4.0,
    folder=".",
    seed_b=0, seed_g=1,
    device=None,
):
    """Build one non-uniform noise field, frozen for the whole dataset.

    The Poisson background b_k is a smooth spatial cloud on [b_min, b_max]
    with correlation length corr_px pixels, i.e. autofluorescence that
    varies slowly across the frame. The Gaussian readout G_k = mu_k is
    drawn i.i.d. uniform per pixel on [g_min, g_max], i.e. the pixel-variant
    readout of an sCMOS camera, with the mean set equal to the variance so
    the Poisson approximation applies. Both maps are (Ky, Kx) and are shared
    by every d and M and every frame of the dataset. They are saved to disk
    so the UGIA-F, EM-GML, and network estimators all consume the identical
    field that generated the frames.

    Returns
    -------
    noise : Noise built from the frozen b_k and G_k maps.
    """
    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    b_map = background_cloud(camera, b_min, b_max, corr_px=corr_px,
                             seed=seed_b, device=device, dtype=torch.float32)

    g_gen = torch.Generator(device="cpu").manual_seed(int(seed_g))
    g_unit = torch.rand(camera.Ky, camera.Kx, generator=g_gen, dtype=torch.float32)
    G_map = (g_min + (g_max - g_min) * g_unit).to(device=device)   # mu_k = G_k
    mu_map = G_map.clone()

    os.makedirs(folder, exist_ok=True)
    np.savetxt(os.path.join(folder, "b_map.txt"),
               b_map.cpu().numpy(), fmt="%.6f")
    np.savetxt(os.path.join(folder, "G_map.txt"),
               G_map.cpu().numpy(), fmt="%.6f")
    print(f"  Saved noise maps -> {folder}/b_map.txt, {folder}/G_map.txt")
    print(f"  b_k in [{b_map.min():.3f}, {b_map.max():.3f}]  "
          f"G_k=mu_k in [{G_map.min():.3f}, {G_map.max():.3f}]  "
          f"(corr_px={corr_px})")

    return Noise(b=b_map, mu=mu_map, G=G_map)


# ============================================================
# Visualization
# ============================================================

def show_and_save_one_frame(frame, xy_nm, camera, imagej_coords=True, save_path=None):
    xy_pix = xy_nm / np.array([camera.Dx, camera.Dy], dtype=np.float32) - 0.5
    origin = 'upper' if imagej_coords else 'lower'

    fig = plt.figure(figsize=(4, 4))
    plt.imshow(frame, cmap='gray', origin=origin)
    plt.scatter(xy_pix[:, 0], xy_pix[:, 1], c='red', s=40)
    plt.title(f"Example Frame with True Emitter Locations")
    plt.tight_layout()

    if save_path is not None:
        fig.savefig(save_path, format='tiff', dpi=300, bbox_inches='tight')
        print(f"  Saved figure     -> {save_path}")

    plt.show()
    plt.close(fig)


# ============================================================
# Dataset generation
# ============================================================

def generate_dataset(
    M,
    d_nm,
    N_frames,
    camera,
    psf,
    noise,
    Dataset_folder,
    Im0=300000.0,
    save_fig=True,
):
    """Generate N_frames for M emitters on a circle of radius d_nm.

    The noise field carried by ``noise`` is the frozen non-uniform field
    shared by every (d, M) of the dataset; only the Poisson and Gaussian
    samples vary frame to frame.

    All output files are saved directly into Dataset_folder (no subfolders):
        d=<d>_M=<M>_xy.txt          -- (M, 2) emitter positions in nm
        d=<d>_M=<M>_Frames.tif      -- (N_frames, Ky, Kx) uint16 multi-page TIFF
        d=<d>_M=<M>_ShownFigure.tif -- frame 1 with emitter locations overlaid
    """
    os.makedirs(Dataset_folder, exist_ok=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print(f"\n--- d={d_nm}  M={M}  ({N_frames} frames) ---")

    # ----------------------------------------------------------
    # 1. Generate emitter positions (nm) on circle of radius d_nm
    # ----------------------------------------------------------
    xy_nm = circle_emitters(M, d_nm, camera)     # (M, 2) numpy array

    xy_path = os.path.join(Dataset_folder, f"d={d_nm}_M={M}_xy.txt")
    np.savetxt(xy_path, xy_nm, fmt="%.6f")
    print(f"  Saved xy         -> {xy_path}")

    # ----------------------------------------------------------
    # 2. Build SystemConfig with N_frames copies of the same positions
    #    so gauss2d_frame_torch generates all frames in one batched call
    # ----------------------------------------------------------
    xy_tensor = torch.tensor(xy_nm, dtype=torch.float32, device=device)
    xy_tensor = xy_tensor.unsqueeze(0).expand(N_frames, M, 2).contiguous()  # (N, M, 2)
    Im_tensor = torch.full((N_frames, M), float(Im0), dtype=torch.float32, device=device)

    emitter = EmitterData(xy=xy_tensor, Im=Im_tensor)
    system  = SystemConfig(
        emitter = emitter,
        psf     = psf,
        camera  = camera,
        noise   = noise,
    )

    # ----------------------------------------------------------
    # 3. Generate all N_frames in one batched GPU call
    # ----------------------------------------------------------
    t0 = time.perf_counter()
    with torch.no_grad():
        frames_torch = gauss2d_frame_torch(system)   # (N_frames, Ky, Kx)
    t1 = time.perf_counter()
    frames_np = frames_torch.cpu().numpy().astype(np.float32)
    print(f"  Generated {N_frames} frames in {t1-t0:.3f}s")

    # ----------------------------------------------------------
    # 4. Save multi-page TIFF (uint16)
    # ----------------------------------------------------------
    tif_path = os.path.join(Dataset_folder, f"d={d_nm}_M={M}_Frames.tif")
    tifffile.imwrite(tif_path, frames_np.astype(np.uint16), photometric='minisblack')
    print(f"  Saved frames     -> {tif_path}")

    # ----------------------------------------------------------
    # 5. Show frame 1 with true emitter locations
    # ----------------------------------------------------------
    fig_path = (
        os.path.join(Dataset_folder, f"d={d_nm}_M={M}_ShownFigure.tif")
        if save_fig else None
    )
    show_and_save_one_frame(
        frames_np[0],
        xy_nm,
        camera,
        imagej_coords=True,
        save_path=fig_path,
    )


# ============================================================
# Main
# ============================================================

if __name__ == "__main__":
    torch.manual_seed(0)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(0)

    torch.set_float32_matmul_precision('high')
    print("\n=== Generate-Dataset7x7 (Fixed, non-uniform noise) ===")
    print_device_info()

    camera = Camera(Kx=7, Ky=7, Dx=100.0, Dy=100.0, Dt=0.01)
    psf    = Gaussian2DPSF(sigma=108.81)

    N_frames       = 25
    Im0            = 300000.0
    Dataset_folder = "Dataset-Fixed"

    # One frozen non-uniform noise field for the whole dataset (all d, M).
    noise = build_frozen_noise(
        camera,
        b_min=4.0, b_max=6.0, corr_px=2.0,
        g_min=2.0, g_max=4.0,
        folder=Dataset_folder,
        seed_b=0, seed_g=1,
    )

    t_total = time.perf_counter()
    for d_nm in [25, 50, 75, 100, 125, 150]:
        for M in [1, 2, 3, 4, 5]:
            generate_dataset(
                M              = M,
                d_nm           = d_nm,
                N_frames       = N_frames,
                camera         = camera,
                psf            = psf,
                noise          = noise,
                Dataset_folder = Dataset_folder,
                Im0            = Im0,
                save_fig       = True,
            )
    t_end = time.perf_counter()
    mins, sec = divmod(t_end - t_total, 60)
    print(f"\n[Timing] Total: {int(mins)}m {sec:.1f}s")

    print("\nDataset-Fixed generation complete.")
    print(f"Output structure:")
    print(f"  {Dataset_folder}/")
    print(f"    b_map.txt               (Ky x Kx background density map)")
    print(f"    G_map.txt               (Ky x Kx readout density map)")
    for d_nm in [25, 50, 75, 100, 125, 150]:
        for M in [1, 2, 3, 4, 5]:
            print(f"    d={d_nm}_M={M}_Frames.tif")
            print(f"    d={d_nm}_M={M}_xy.txt")
            print(f"    d={d_nm}_M={M}_ShownFigure.tif")
