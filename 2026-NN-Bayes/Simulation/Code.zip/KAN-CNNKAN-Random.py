"""
KAN-CNNKAN-Random.py

Evaluate trained KAN and CNN-KAN models on Dataset-Random.
For each M, N=1000 frames are processed and per-frame RMSMD
values are accumulated into ARMSMD — same metric as
UGIA-EM-Random.py.

Trained models are loaded from:
    KAN-Trained/kan_localizer_M=<M>.pth
    CNN-KAN-Trained/cnnkan_localizer_M=<M>.pth

Yi Sun
"""

import sys
import os
import time

# ----------------------------------------------------------------------
# Console logging: duplicate all stdout to a log file in the Benchmark folder
# ----------------------------------------------------------------------
class _Tee:
    """Write everything printed to the console AND to a log file."""
    def __init__(self, *streams):
        self.streams = streams
    def write(self, data):
        for s in self.streams:
            try:
                s.write(data)
            except UnicodeEncodeError:
                s.write(data.encode("ascii", "replace").decode("ascii"))
            s.flush()
    def flush(self):
        for s in self.streams:
            s.flush()

import math
import numpy as np
import torch
import tifffile
import matplotlib.pyplot as plt
import matplotlib.patches as patches

ROOT = r"K:\Research_KB"
sys.path.append(ROOT)

from SMLM_Lib import (
    Camera,
    print_device_info,
)
from SMLM_Lib.KAN import KANLocalizer, CNNKANLocalizer
from SMLM_Lib.metrics import rmsmd, rmsmd_h, rmsmd_h_per_frame


# ======================================================================
# Global configuration  (must match Generate-Dataset7x7-Random.py)
# ======================================================================

N             = 1000
Data_folder   = "Dataset-Random"
KAN_folder    = "KAN-Trained"
CNNKAN_folder = "CNN-KAN-Trained"

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

camera = Camera(Kx=7, Ky=7, Dx=100.0, Dy=100.0, Dt=0.01)
Kx, Ky = camera.Kx, camera.Ky
Dx, Dy = camera.Dx, camera.Dy



# ======================================================================
# Helpers
# ======================================================================

def load_frames(M: int) -> torch.Tensor:
    """Load all N frames for emitter count M. Returns (N, Ky, Kx)."""
    path = os.path.join(Data_folder, f"M={M}_Frames.tif")
    arr  = tifffile.imread(path).astype(np.float32)
    return torch.tensor(arr, dtype=torch.float32, device=device)


def load_xy_all(M: int) -> torch.Tensor:
    """Load all N*M emitter locations. Returns (N, M, 2)."""
    path = os.path.join(Data_folder, f"M={M}_xy.txt")
    arr  = np.loadtxt(path, dtype=np.float32, skiprows=1)
    return torch.tensor(arr, dtype=torch.float32, device=device).reshape(N, M, 2)


def load_kan(M: int) -> KANLocalizer:
    model = KANLocalizer(Kx=camera.Kx, Ky=camera.Ky, M=M).to(device)
    path  = os.path.join(KAN_folder, f"kan_localizer_M={M}.pth")
    model.load_state_dict(torch.load(path, map_location=device))
    model.eval()
    return model


def load_cnnkan(M: int) -> CNNKANLocalizer:
    model = CNNKANLocalizer(Kx=camera.Kx, Ky=camera.Ky, M=M).to(device)
    path  = os.path.join(CNNKAN_folder, f"cnnkan_localizer_M={M}.pth")
    model.load_state_dict(torch.load(path, map_location=device))
    model.eval()
    return model


def prepare_input(frames: torch.Tensor) -> torch.Tensor:
    """Normalise (N, Ky, Kx) frames → (N, Kx*Ky) model input."""
    x = frames.view(frames.shape[0], -1)
    x = x / (x.amax(dim=1, keepdim=True) + 1e-8)
    return x


def compute_armsmd_and_h(xy_est_all, xy_all, M):
    """ARMSMD and ARMSMD-H over N frames, both fully batched.

    ARMSMD   is the root mean square minimum distance of Sun (2018).
    ARMSMD-H is the metric under the Hungarian assignment, i.e. the
             correspondence of maximum likelihood between the estimates and
             the emitters, which is the quantity the matched Bayes estimator
             minimises and the training loss evaluates.
    """
    from SMLM_Lib.metrics import rmsmd_per_frame

    _, D2_all = rmsmd_per_frame(xy_est_all, xy_all)      # (N,)
    armsmd_val = math.sqrt(D2_all.mean().item())

    _, D2h_all = rmsmd_h_per_frame(xy_est_all, xy_all)   # (N,)
    return armsmd_val, math.sqrt(D2h_all.mean().item())


def show_frame1(xy_est_n, xy_true_n, alg_name, armsmd_val, armsmd_h_value, outfile):
    """Show frame-1 estimated vs true locations with ARMSMD-H in legend."""
    fig, ax = plt.subplots(figsize=(4, 4))
    ax.imshow(
        np.zeros((Ky, Kx), dtype=np.float32),
        cmap="gray", origin="upper",
    )
    ax.set_xlim(-0.5, Kx - 0.5)
    ax.set_ylim(Ky - 0.5, -0.5)
    ax.set_aspect("equal")
    ax.axis("off")


    ax.scatter(
        xy_est_n[:, 0] / Dx - 0.5,
        xy_est_n[:, 1] / Dy - 0.5,
        c="white", s=10, zorder=5,
        label=f"{alg_name}  ARMSMD-H = {armsmd_h_value:.2f} nm",
    )
    ax.scatter(
        xy_true_n[:, 0] / Dx - 0.5,
        xy_true_n[:, 1] / Dy - 0.5,
        c="red", s=10, zorder=5,
        label="Ground Truth",
    )
    ax.legend(
        loc="upper left", framealpha=1.0, labelcolor="white",
        frameon=True, edgecolor="white", facecolor="none", fontsize=9,
    )

    os.makedirs(os.path.dirname(outfile) or '.', exist_ok=True)
    fig.savefig(outfile, dpi=150, bbox_inches="tight")
    plt.show(block=False)
    plt.close(fig)


def run_model_random(alg_name, outdir):
    """Evaluate a model on all M values in Dataset-Random.

    Parameters
    ----------
    alg_name : str  — 'KAN' or 'CNN-KAN'
    outdir   : str  — output folder for images
    """
    os.makedirs(outdir, exist_ok=True)

    for M in range(1, 6):

        frames_all = load_frames(M)      # (N, Ky, Kx)
        xy_all     = load_xy_all(M)      # (N, M, 2)

        # Load model for this M
        if alg_name == 'KAN':
            model = load_kan(M)
        else:
            model = load_cnnkan(M)

        # Prepare all N frames as model input
        x = prepare_input(frames_all)    # (N, Kx*Ky)

        # Run inference — all N frames in one batch
        t_inf0 = time.perf_counter()
        with torch.no_grad():
            pred_nm = model(x)           # (N, 2*M)
        t_inf1 = time.perf_counter()

        xy_est_all = pred_nm.view(N, M, 2)   # (N, M, 2)

        # ARMSMD and ARMSMD-H over all N frames
        t_met0 = time.perf_counter()
        armsmd_val, armsmd_h_value = compute_armsmd_and_h(xy_est_all, xy_all, M)
        t_met1 = time.perf_counter()

        print(f"M={M}  {alg_name}  ARMSMD = {armsmd_val:.2f} nm  "
              f"ARMSMD-H = {armsmd_h_value:.2f} nm  "
              f"[inf={t_inf1-t_inf0:.2f}s  metrics={t_met1-t_met0:.2f}s]")

        outfile = os.path.join(outdir, f"M={M}_{alg_name}.png")
        show_frame1(
            xy_est_all[0].cpu().numpy(),
            xy_all[0].cpu().numpy(),
            alg_name,
            armsmd_val,
            armsmd_h_value,
            outfile,
        )


# ======================================================================
# Main
# ======================================================================

if __name__ == "__main__":
    # ---- start run log (saved in the Benchmark folder) ----
    import atexit
    os.makedirs("Benchmark-Random", exist_ok=True)
    _log_path = os.path.join(
        "Benchmark-Random", f"inference_log_KAN-CNNKAN_Random_{time.strftime('%Y%m%d_%H%M%S')}.txt")
    _logf = open(_log_path, "w", encoding="utf-8")
    _orig_stdout = sys.stdout
    while type(_orig_stdout).__name__ == "_Tee":  # unwrap a leftover Tee
        _orig_stdout = _orig_stdout.streams[0]
    sys.stdout = _Tee(_orig_stdout, _logf)

    @atexit.register
    def _close_log(_o=_orig_stdout, _f=_logf):
        sys.stdout = _o
        _f.close()

    print(f"[Log] Writing run log -> {_log_path}")
    torch.set_float32_matmul_precision('high')
    print_device_info()
    plt.close('all')

    def timed_run(fn, label, *args, **kwargs):
        t0 = time.perf_counter()
        fn(*args, **kwargs)
        t1 = time.perf_counter()
        mins, sec = divmod(t1 - t0, 60)
        print(f"[Timing] {label}: {int(mins)}m {sec:.1f}s")

    print("\n=== KAN Benchmark (Random) ===")
    timed_run(run_model_random, "KAN     (Random)", 'KAN',     "Benchmark-Random/KAN")

    print("\n=== CNN-KAN Benchmark (Random) ===")
    timed_run(run_model_random, "CNN-KAN (Random)", 'CNN-KAN', "Benchmark-Random/CNN-KAN")
