"""
Bayes-M2-Quadrature.py

Direct numerical computation of the two Bayes estimators for M = 2, by
quadrature over the full four dimensional parameter space, together with the
networks and EM-GML on the same frames, so all curves in the resulting figure
come from identical data.

Two estimators are computed exactly, up to the quadrature grid.

  Labelled MMSE
      theta_MMSE = E[theta | U]
  which minimises the labelled squared error. Because the likelihood and the
  prior are both invariant under permutation of the emitter index, the
  posterior is exchangeable and every marginal is identical, so all M estimates
  of theta_MMSE coincide at the common posterior mean. The estimator is
  therefore degenerate for M >= 2. The script verifies this numerically and
  reports the residual separation, which should be zero to machine precision.

  Matched Bayes
      theta_B = arg min_y E[ min_pi sum_m || y_m - theta_pi(m) ||^2 | U ]
  which minimises the permutation matched squared error, i.e. the quantity
  RMSMD-H measures when the number of estimates equals the number of emitters.
  This is the estimator the networks approximate, since it is the minimiser of
  the Hungarian matched loss used in training. It has no closed form and is
  obtained here by a Lloyd type iteration on the posterior, started from the
  maximum a posteriori pair and from several random pairs, keeping the best
  objective.

The prior is uniform on the central 3x3 pixel block, i.e. the region the
networks were trained on, so the posterior on the grid is proportional to the
likelihood and no prior factor is needed.

theta_B is a lower bound on the achievable matched squared error, so no
estimator should fall below it. A network scoring below theta_B would indicate
an error rather than a discovery, which makes this the strongest available
validation of the whole pipeline.

Outputs
    Benchmark-Random/Bayes-M2/bayes_m2.csv      ARMSMD-H vs d, all estimators
    Benchmark-Random/Bayes-M2/bayes_m2.png      the corresponding curves

Yi Sun
"""

import sys
import os
import time
import math
import numpy as np
import torch
import matplotlib.pyplot as plt

ROOT = r"K:\Research_KB"   # <- change to your actual path
sys.path.append(ROOT)


# ----------------------------------------------------------------------
# Console logging: duplicate all stdout to a log file in the Benchmark folder
# ----------------------------------------------------------------------
class _Tee:
    """Write everything printed to the console AND to a log file."""
    def __init__(self, *streams):
        self.streams = streams
    def write(self, data):
        for s in self.streams:
            try:
                s.write(data)
            except UnicodeEncodeError:
                s.write(data.encode("ascii", "replace").decode("ascii"))
            s.flush()
    def flush(self):
        for s in self.streams:
            s.flush()


from SMLM_Lib import (
    SystemConfig,
    EmitterData,
    Gaussian2DPSF,
    Camera,
    Noise,
    gauss2d_frame_torch,
    gauss2d_ugia_f_batch_torch,
    gauss2d_em_batch_torch,
    print_device_info,
)
from SMLM_Lib.Gauss2D import Qfunc_torch, gauss2d_loglike_batch_torch
from SMLM_Lib.metrics import rmsmd_h_per_frame
from SMLM_Lib.APL import APLLocalizer, CNNAPLLocalizer
from SMLM_Lib.KAN import KANLocalizer, CNNKANLocalizer
from SMLM_Lib.ViT import ViTLocalizer


# ============ configuration ============
M          = 2
Noise_src  = "Dataset-Random"
OutDir     = "Benchmark-Random/Bayes-M2"

# Quadrature is O(G^4) per frame, so fewer frames and separations than the
# 1000 frame sweep. N_Q = 200 gives a relative standard error near 5 percent.
N_Q        = 200
D_LIST     = [10, 20, 30, 50, 75, 100, 150, 250]
GRID_STEP  = 6.0        # nm, quadrature step; error scales as GRID_STEP^2
A_CHUNK    = 32         # rows of the pair grid evaluated at once
N_LLOYD    = 30         # Lloyd iterations for theta_B
N_RESTART  = 4          # random restarts in addition to the MAP start

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

camera = Camera(Kx=7, Ky=7, Dx=100.0, Dy=100.0, Dt=0.01)
Kx, Ky = camera.Kx, camera.Ky
Dx, Dy, Dt = camera.Dx, camera.Dy, camera.Dt
DxDyDt = Dx * Dy * Dt

psf   = Gaussian2DPSF(sigma=108.81)
sigma = psf.sigma

b_map = torch.tensor(np.loadtxt(os.path.join(Noise_src, "b_map.txt"),
                                dtype=np.float32), device=device)
G_map = torch.tensor(np.loadtxt(os.path.join(Noise_src, "G_map.txt"),
                                dtype=np.float32), device=device)
noise = Noise(b=b_map, mu=G_map, G=G_map)

Im0 = 300000.0

MARGIN_PX = 2
LO = MARGIN_PX * Dx
HI = (Kx - MARGIN_PX) * Dx

NEAR_HALF_NEAR = 10.0
NEAR_HALF_WIDE = 100.0
K_EM           = 250

# Number of starts evaluated in one call. The batch presented to the
# graphics processor is BATCH_STARTS times the number of frames, so a
# larger value uses the device more fully at the cost of more memory.
# The result does not depend on it.
BATCH_STARTS   = 5
N_ITER         = 300
GN             = 'N'
SEED           = 20260719

NET_FOLDERS = {
    'APL':     ("APL-Trained",     "apl_localizer_M={}.pth"),
    'CNN-APL': ("CNN-APL-Trained", "cnnapl_localizer_M={}.pth"),
    'KAN':     ("KAN-Trained",     "kan_localizer_M={}.pth"),
    'CNN-KAN': ("CNN-KAN-Trained", "cnnkan_localizer_M={}.pth"),
    'ViT':     ("ViT-Trained",     "vit_localizer_M={}.pth"),
}
NETWORKS   = ['APL', 'CNN-APL', 'KAN', 'CNN-KAN', 'ViT']
ESTIMATORS = ['UGIA-F', 'EM-GML', 'MMSE', 'Bayes-M'] + NETWORKS

STYLE = {
    'UGIA-F':   dict(color='k',         ls='--', marker='s', lw=2.0),
    'EM-GML':   dict(color='crimson',   ls='-',  marker='o', lw=2.2),
    'MMSE':     dict(color='darkorange',ls='-.', marker='x', lw=2.0),
    'Bayes-M':  dict(color='navy',      ls='-',  marker='P', lw=2.6),
    'APL':      dict(color='tab:blue',   ls=':', marker='^', lw=1.3),
    'CNN-APL':  dict(color='tab:cyan',   ls=':', marker='^', lw=1.3),
    'KAN':      dict(color='tab:green',  ls=':', marker='D', lw=1.3),
    'CNN-KAN':  dict(color='tab:olive',  ls=':', marker='D', lw=1.3),
    'ViT':      dict(color='tab:purple', ls=':', marker='*', lw=1.5),
}


# ============ quadrature grid ============

def build_grid():
    """Single emitter grid over the prior support and its pixel-integrated PSF.

    Returns
    -------
    pos : (S, 2) grid positions in nm, S = G*G
    sig_map : (S, Kx*Ky) mean photon contribution of one emitter at each grid
              position, i.e. Dt * Im0 * q_k
    """
    g = torch.arange(LO, HI + 1e-6, GRID_STEP, dtype=torch.float32, device=device)
    G = g.numel()

    kx = torch.arange(Kx, dtype=torch.float32, device=device).view(1, Kx)
    ky = torch.arange(Ky, dtype=torch.float32, device=device).view(1, Ky)

    gx = g.view(G, 1)
    qx = (Qfunc_torch(-(Dx * (kx + 1) - gx) / sigma)
          - Qfunc_torch(-(Dx * kx - gx) / sigma))          # (G, Kx)
    qy = (Qfunc_torch(-(Dy * (ky + 1) - gx) / sigma)
          - Qfunc_torch(-(Dy * ky - gx) / sigma))          # (G, Ky)

    # position index s = j*G + i  ->  (x, y) = (g[i], g[j])
    q = qy.view(G, 1, Ky, 1) * qx.view(1, G, 1, Kx)         # (Gy, Gx, Ky, Kx)
    sig_map = (Dt * Im0 * q).reshape(G * G, Ky * Kx).contiguous()

    X = g.view(1, G).expand(G, G).reshape(-1)
    Y = g.view(G, 1).expand(G, G).reshape(-1)
    pos = torch.stack([X, Y], dim=1).contiguous()           # (S, 2)
    return pos, sig_map, G


def log_posterior_pairs(U_corr, sig_map, bg):
    """Log posterior over ordered grid pairs for one frame, up to a constant.

    The prior is uniform on the grid so the posterior is proportional to the
    likelihood. Returns an (S, S) tensor of log values.
    """
    S = sig_map.shape[0]
    out = torch.empty(S, S, device=device, dtype=torch.float32)
    for a0 in range(0, S, A_CHUNK):
        a1 = min(a0 + A_CHUNK, S)
        w = sig_map[a0:a1].unsqueeze(1) + sig_map.unsqueeze(0) + bg   # (A,S,P)
        w = torch.clamp(w, min=1e-12)
        out[a0:a1] = (U_corr * torch.log(w) - w).sum(dim=-1)
    return out


def bayes_estimates(logP, pos, gen):
    """Labelled MMSE and matched Bayes estimates from the pair log posterior.

    Returns
    -------
    xy_mmse  : (2, 2) both rows equal, the common posterior mean
    xy_bayes : (2, 2) minimiser of the permutation matched squared error
    """
    S = pos.shape[0]
    flat = logP.reshape(-1)
    P = torch.softmax(flat, dim=0).reshape(S, S)            # (S, S), sums to 1

    # ---- labelled MMSE: marginals of each index -------------------------
    Pa = P.sum(dim=1)                                        # (S,)
    Pb = P.sum(dim=0)                                        # (S,)
    m1 = (Pa.unsqueeze(1) * pos).sum(dim=0)
    m2 = (Pb.unsqueeze(1) * pos).sum(dim=0)
    xy_mmse = torch.stack([m1, m2], dim=0)                   # (2, 2)

    # ---- matched Bayes: Lloyd iterations on the posterior ---------------
    # cost of the identity matching and of the swap, for a candidate (y1, y2)
    def objective(y1, y2):
        d1a = ((pos - y1) ** 2).sum(1)                       # (S,)
        d2b = ((pos - y2) ** 2).sum(1)
        c_id = d1a.unsqueeze(1) + d2b.unsqueeze(0)           # (S,S)
        c_sw = d2b.unsqueeze(1) + d1a.unsqueeze(0)
        return (P * torch.minimum(c_id, c_sw)).sum()

    def lloyd(y1, y2):
        for _ in range(N_LLOYD):
            d1a = ((pos - y1) ** 2).sum(1)
            d2b = ((pos - y2) ** 2).sum(1)
            c_id = d1a.unsqueeze(1) + d2b.unsqueeze(0)
            c_sw = d2b.unsqueeze(1) + d1a.unsqueeze(0)
            ident = (c_id <= c_sw)
            Pi = P * ident
            Ps = P - Pi
            # y1 takes the first element under identity, the second under swap
            w1a = Pi.sum(dim=1)          # weight on pos[a] for y1
            w1b = Ps.sum(dim=0)          # weight on pos[b] for y1
            w2b = Pi.sum(dim=0)          # weight on pos[b] for y2
            w2a = Ps.sum(dim=1)          # weight on pos[a] for y2
            t1 = w1a.sum() + w1b.sum()
            t2 = w2b.sum() + w2a.sum()
            y1n = ((w1a.unsqueeze(1) * pos).sum(0)
                   + (w1b.unsqueeze(1) * pos).sum(0)) / torch.clamp(t1, min=1e-12)
            y2n = ((w2b.unsqueeze(1) * pos).sum(0)
                   + (w2a.unsqueeze(1) * pos).sum(0)) / torch.clamp(t2, min=1e-12)
            if torch.allclose(y1n, y1, atol=1e-4) and torch.allclose(y2n, y2, atol=1e-4):
                y1, y2 = y1n, y2n
                break
            y1, y2 = y1n, y2n
        return y1, y2

    # start from the maximum a posteriori pair
    idx = int(torch.argmax(flat).item())
    a_star, b_star = idx // S, idx % S
    starts = [(pos[a_star].clone(), pos[b_star].clone())]
    for _ in range(N_RESTART):
        ia = int(torch.randint(0, S, (1,), device=device, generator=gen).item())
        ib = int(torch.randint(0, S, (1,), device=device, generator=gen).item())
        starts.append((pos[ia].clone(), pos[ib].clone()))

    best, best_obj = None, None
    for y1, y2 in starts:
        y1, y2 = lloyd(y1, y2)
        o = objective(y1, y2)
        if best_obj is None or o < best_obj:
            best_obj, best = o, (y1, y2)
    xy_bayes = torch.stack([best[0], best[1]], dim=0)        # (2, 2)
    return xy_mmse, xy_bayes


# ============ shared helpers ============

def sample_pairs(d_nm, n_frames, gen):
    got, tried, accepted = [], 0, 0
    half = 0.5 * float(d_nm)
    while sum(x.shape[0] for x in got) < n_frames:
        B = 4 * n_frames
        mid = LO + (HI - LO) * torch.rand(B, 2, device=device, generator=gen)
        th  = 2.0 * math.pi * torch.rand(B, device=device, generator=gen)
        off = torch.stack([half * torch.cos(th), half * torch.sin(th)], dim=1)
        p1, p2 = mid + off, mid - off
        ok = ((p1 >= LO) & (p1 < HI) & (p2 >= LO) & (p2 < HI)).all(dim=1)
        tried += B
        accepted += int(ok.sum().item())
        if ok.any():
            got.append(torch.stack([p1[ok], p2[ok]], dim=1))
    return torch.cat(got, dim=0)[:n_frames].contiguous(), accepted / float(tried)


def make_frames(xy):
    B = xy.shape[0]
    Im = torch.full((B, M), Im0, dtype=torch.float32, device=device)
    emitter = EmitterData(xy=xy, Im=Im)
    system  = SystemConfig(emitter=emitter, psf=psf, camera=camera, noise=noise)
    with torch.no_grad():
        return gauss2d_frame_torch(system)


def load_net(name):
    folder, pat = NET_FOLDERS[name]
    cls = {'APL': APLLocalizer, 'CNN-APL': CNNAPLLocalizer,
           'KAN': KANLocalizer, 'CNN-KAN': CNNKANLocalizer,
           'ViT': ViTLocalizer}[name]
    model = cls(Kx=Kx, Ky=Ky, M=M).to(device)
    model.load_state_dict(
        torch.load(os.path.join(folder, pat.format(M)), map_location=device))
    model.eval()
    return model


def prepare_input(frames):
    x = frames.view(frames.shape[0], -1)
    return x / (x.amax(dim=1, keepdim=True) + 1e-8)


def per_frame_D2h(xy_est, xy_ref):
    """(N,) squared RMSMD-H per frame, i.e. under the Hungarian assignment.

    The number of estimates equals the number of emitters, so the
    correspondence of maximum likelihood is the assignment minimising the
    total squared distance. A stratum or sweep value is obtained as
    sqrt(mean(D2h)), i.e. the squared distances are averaged and the square
    root taken once at the end.
    """
    _, D2 = rmsmd_h_per_frame(xy_est, xy_ref)
    return D2.cpu().numpy().astype(np.float64)


def armsmd_h(D2h):
    return float(np.sqrt(np.mean(D2h)))


# ============ main ============

def run():
    os.makedirs(OutDir, exist_ok=True)

    pos, sig_map, G = build_grid()
    S = pos.shape[0]
    print(f"Quadrature grid: step {GRID_STEP:.1f} nm, {G} points per axis, "
          f"{S} single-emitter positions, {S*S:,} ordered pairs per frame.")
    print(f"Grid quantisation standard deviation = {GRID_STEP/math.sqrt(12):.2f} nm.\n")

    bg = (DxDyDt * (noise.b + noise.G)).reshape(-1)          # (P,)
    corr = (DxDyDt * (noise.G - noise.mu)).reshape(-1)       # (P,)

    nets = {n: load_net(n) for n in NETWORKS}
    results = {e: [] for e in ESTIMATORS}
    mmse_split = []

    for d_nm in D_LIST:
        t_d = time.perf_counter()
        gen = torch.Generator(device=device).manual_seed(SEED + int(d_nm))

        xy_true, acc = sample_pairs(d_nm, N_Q, gen)
        frames = make_frames(xy_true)

        Im_tensor = torch.full((1, M), Im0, dtype=torch.float32, device=device)
        emitter = EmitterData(xy=xy_true[0:1], Im=Im_tensor)
        system  = SystemConfig(emitter=emitter, psf=psf, camera=camera, noise=noise)

        D2h = {}

        # ---- UGIA-F ---------------------------------------------------
        with torch.no_grad():
            xyF = gauss2d_ugia_f_batch_torch(xy_true, Im0, psf, camera, noise,
                                             ImType='KI')
        D2h['UGIA-F'] = per_frame_D2h(xyF, xy_true)

        # ---- EM-GML ---------------------------------------------------
        xyi = xy_true + NEAR_HALF_NEAR * (
            2 * torch.rand(N_Q, M, 2, device=device, generator=gen) - 1)
        with torch.no_grad():
            xy_b = gauss2d_em_batch_torch(frames, xyi, system, GN=GN, n_iter=N_ITER)
            ll_b = gauss2d_loglike_batch_torch(frames, xy_b, system)
        # The K starts are evaluated BATCH_STARTS at a time. Stacking the
        # starts along the batch dimension presents the graphics processor
        # with S * N_Q frames per call instead of N_Q, which is much faster for
        # frames of this size, and leaves the result unchanged since the
        # starts are independent and the selection is a maximum over them.
        done = 0
        while done < K_EM:
            S = min(BATCH_STARTS, K_EM - done)
            jitter = NEAR_HALF_WIDE * (
                2 * torch.rand(S, N_Q, M, 2, device=device, generator=gen) - 1)
            xyi_s = (xy_true.unsqueeze(0) + jitter).reshape(S * N_Q, M, 2)
            frames_rep = frames.repeat(S, 1, 1)
            with torch.no_grad():
                xy_s = gauss2d_em_batch_torch(frames_rep, xyi_s, system,
                                              GN=GN, n_iter=N_ITER)
                ll_s = gauss2d_loglike_batch_torch(frames_rep, xy_s, system)
            ll_s = ll_s.reshape(S, N_Q)
            xy_s = xy_s.reshape(S, N_Q, M, 2)
            ll_max, idx = ll_s.max(dim=0)
            xy_max = xy_s[idx, torch.arange(N_Q, device=device)]
            better = ll_max > ll_b
            ll_b = torch.where(better, ll_max, ll_b)
            xy_b = torch.where(better.view(N_Q, 1, 1), xy_max, xy_b)
            done += S
        D2h['EM-GML'] = per_frame_D2h(xy_b, xy_true)

        # ---- quadrature Bayes estimators ------------------------------
        xy_mmse = torch.empty(N_Q, M, 2, device=device)
        xy_bay  = torch.empty(N_Q, M, 2, device=device)
        t_q = time.perf_counter()
        for n in range(N_Q):
            U_corr = frames[n].reshape(-1) + corr
            U_corr = torch.clamp(U_corr, min=0.0)
            logP = log_posterior_pairs(U_corr, sig_map, bg)
            e_mmse, e_bay = bayes_estimates(logP, pos, gen)
            xy_mmse[n], xy_bay[n] = e_mmse, e_bay
        t_q = time.perf_counter() - t_q
        D2h['MMSE']    = per_frame_D2h(xy_mmse, xy_true)
        D2h['Bayes-M'] = per_frame_D2h(xy_bay,  xy_true)

        # degeneracy check: separation between the two MMSE estimates
        split = (xy_mmse[:, 0] - xy_mmse[:, 1]).norm(dim=1)
        mmse_split.append(float(split.max().item()))

        # ---- networks -------------------------------------------------
        x_in = prepare_input(frames)
        for name in NETWORKS:
            with torch.no_grad():
                pred = nets[name](x_in).view(N_Q, M, 2)
            D2h[name] = per_frame_D2h(pred, xy_true)

        for e in ESTIMATORS:
            results[e].append(armsmd_h(D2h[e]))

        print(f"d={d_nm:4d} nm  " +
              "  ".join(f"{e}={armsmd_h(D2h[e]):7.2f}" for e in ESTIMATORS))
        print(f"           max separation of the two MMSE estimates = "
              f"{mmse_split[-1]:.3e} nm   [quadrature {t_q:.1f}s, "
              f"total {time.perf_counter()-t_d:.1f}s]")

    # ---- summary -------------------------------------------------------
    print(f"\n{'='*104}")
    print(f"ARMSMD-H (nm) versus separation, M = 2, N = {N_Q} frames per point, "
          f"quadrature step {GRID_STEP:.1f} nm")
    print(f"{'='*104}")
    hdr = f"{'d (nm)':>8}" + "".join(f"{e:>11}" for e in ESTIMATORS)
    print(hdr)
    print('-' * len(hdr))
    for i, d_nm in enumerate(D_LIST):
        print(f"{d_nm:>8}" + "".join(f"{results[e][i]:>11.2f}" for e in ESTIMATORS))

    print("\nValidation, i.e. no estimator should fall below the matched Bayes optimum:")
    for i, d_nm in enumerate(D_LIST):
        below = [e for e in ESTIMATORS
                 if e != 'Bayes-M' and results[e][i] < results['Bayes-M'][i]]
        flag = "OK" if not below else "VIOLATION by " + ", ".join(below)
        print(f"  d={d_nm:>4} nm  Bayes-M={results['Bayes-M'][i]:7.2f} nm   {flag}")

    csv_path = os.path.join(OutDir, "bayes_m2.csv")
    with open(csv_path, "w") as f:
        print("d_nm," + ",".join(ESTIMATORS) + ",mmse_max_split_nm", file=f)
        for i, d_nm in enumerate(D_LIST):
            print(f"{d_nm}," + ",".join(f"{results[e][i]:.6f}" for e in ESTIMATORS)
                  + f",{mmse_split[i]:.6e}", file=f)
    print(f"\nSaved -> {csv_path}")

    fig, ax = plt.subplots(figsize=(7.2, 5.0))
    for e in ESTIMATORS:
        ax.plot(D_LIST, results[e], label=e, markersize=6, **STYLE[e])
    ax.set_xlabel('emitter separation  d  (nm)')
    ax.set_ylabel('ARMSMD-H  (nm)')
    ax.set_xscale('log')
    ax.set_yscale('log')
    ax.set_title('Estimators versus the Bayes optimum, M = 2')
    ax.grid(True, which='both', alpha=0.3)
    ax.legend(fontsize=8, ncol=2)
    fig.tight_layout()
    png = os.path.join(OutDir, "bayes_m2.png")
    fig.savefig(png, dpi=200)
    plt.close(fig)
    print(f"Saved -> {png}")


if __name__ == "__main__":
    import atexit
    os.makedirs("Benchmark-Random", exist_ok=True)
    _log_path = os.path.join(
        "Benchmark-Random",
        f"inference_log_Bayes-M2_{time.strftime('%Y%m%d_%H%M%S')}.txt")
    _logf = open(_log_path, "w", encoding="utf-8")
    _orig_stdout = sys.stdout
    while type(_orig_stdout).__name__ == "_Tee":
        _orig_stdout = _orig_stdout.streams[0]
    sys.stdout = _Tee(_orig_stdout, _logf)

    @atexit.register
    def _close_log(_o=_orig_stdout, _f=_logf):
        sys.stdout = _o
        _f.close()

    print(f"[Log] Writing run log -> {_log_path}")
    torch.set_float32_matmul_precision('high')
    print_device_info()
    plt.close('all')

    t0 = time.perf_counter()
    run()
    mins, sec = divmod(time.perf_counter() - t0, 60)
    print(f"\n[Timing] Bayes-M2-Quadrature: {int(mins)}m {sec:.1f}s")
